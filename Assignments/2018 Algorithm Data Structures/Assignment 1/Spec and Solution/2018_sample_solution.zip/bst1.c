/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the implementation details for a binary search tree.
*/
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "bst1.h"
#include "dataItem.h"
#include "linkedList.h"

struct bst1 {
  struct bst1 *left;
  struct bst1 *right;
  char *key;
  struct dataItem *data;
};

struct bst1 *makeBstDict(){
  return NULL;
}

struct bst1 *insertBstDict(struct bst1 *dictionary, char *key,
  struct dataItem *data){

  struct bst1 **insertLocation = &dictionary;

  /* Insert iteratively. */
  while(*insertLocation){
    int comparisonResult = strcmp(key, (*insertLocation)->key);

    if(comparisonResult <= 0){
      insertLocation = &((*insertLocation)->left);
    } else {
      insertLocation = &((*insertLocation)->right);
    }
  }

  struct bst1 *newNode = (struct bst1 *) malloc(sizeof(struct bst1));
  assert(newNode);
  newNode->left = NULL;
  newNode->right = NULL;
  newNode->key = key;
  newNode->data = data;
  *insertLocation = newNode;

  return dictionary;
}

struct linkedList *searchBstDict(struct bst1 *dictionary, char *key,
  int *comparisons){
  struct bst1 *current = dictionary;
  struct linkedList *resultList = makeList();

  /* Iterative tree traversal */
  while(current){
    int comparisonResult = strcmp(key, current->key);
    (*comparisons)++;
    if(comparisonResult < 0){
      current = current->left;
    } else if(comparisonResult == 0){
      /* Add the found result. */
      resultList = prepend(resultList, current->data);
      /* Keep searching for any extra results. */
      current = current->left;
    } else {
      current = current->right;
    }
  }

  return resultList;
}

/* Post-order traversal free */
void freeBstTree(struct bst1 *dictionary){
  if(! dictionary) return;
  freeBstTree(dictionary->left);
  freeBstTree(dictionary->right);
  freeItem(dictionary->data);
  free(dictionary->key);
  free(dictionary);
  return;
}
