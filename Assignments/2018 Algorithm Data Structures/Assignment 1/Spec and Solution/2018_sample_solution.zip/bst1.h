/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the function prototypes and declarations for a binary search tree.
*/
#include "dataItem.h"

struct bst1;

/* Returns an empty dictionary. */
struct bst1 *makeBstDict();

/*
  Inserts a given set of data with the given key into the given dictionary.
  The key may be freed if multiple keys with the same name exist. Returns the
    updated tree.
*/
struct bst1 *insertBstDict(struct bst1 *dictionary, char *key,
  struct dataItem *data);

/*
  Searches the given dictionary for the given key, and returns a list of all
  results that match that key. The number of key comparisons used in the
  operation are stored at the location of the given pointer (if it is not NULL).
*/
struct linkedList *searchBstDict(struct bst1 *dictionary, char *key,
  int *comparisons);

/*
  Frees the given dictionary.
*/
void freeBstTree(struct bst1 *dictionary);
