/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the implementation details for a binary search tree using a linked
    list for duplicates.
*/
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "bst2.h"
#include "dataItem.h"
#include "linkedList.h"

struct bst2 {
  struct bst2 *left;
  struct bst2 *right;
  char *key;
  struct linkedList *data;
};

struct bst2 *makeBstDict(){
  return NULL;
}

struct bst2 *insertBstDict(struct bst2 *dictionary, char *key,
  struct dataItem *data){
  struct bst2 *newNode;

  struct bst2 **insertLocation = &dictionary;

  /* Insert iteratively. */
  while(*insertLocation){
    int comparisonResult = strcmp(key, (*insertLocation)->key);

    if(comparisonResult < 0){
      insertLocation = &((*insertLocation)->left);
    } else if (comparisonResult == 0){
      break;
    } else {
      insertLocation = &((*insertLocation)->right);
    }
  }

  if(! (*insertLocation)){
      newNode = (struct bst2 *) malloc(sizeof(struct bst2));
      assert(newNode);
      newNode->left = NULL;
      newNode->right = NULL;
      newNode->key = key;
      newNode->data = makeList();

      *insertLocation = newNode;
  } else {
    free(key);
  }

  (*insertLocation)->data = prepend((*insertLocation)->data, data);

  return dictionary;
}

struct linkedList *searchBstDict(struct bst2 *dictionary, char *key,
  int *comparisons){
  struct bst2 *current = dictionary;
  struct linkedList *resultList = makeList();

  struct linkedList *currentNode;

  /* Iterative tree traversal */
  while(current){
    int comparisonResult = strcmp(key, current->key);
    (*comparisons)++;
    if(comparisonResult < 0){
      current = current->left;
    } else if(comparisonResult == 0){
      /* Return all results */
      currentNode = current->data;
      while(! emptyList(currentNode)){
        resultList = prepend(resultList, getData(currentNode));
        currentNode = getNext(currentNode);
      }
      break;
    } else {
      current = current->right;
    }
  }

  return resultList;
}

/* Post-order traversal free */
void freeBstTree(struct bst2 *dictionary){
  if(! dictionary) return;
  freeBstTree(dictionary->left);
  freeBstTree(dictionary->right);
  struct dataItem *currentDataItem;
  while(!emptyList(dictionary->data)){
    currentDataItem = pop(&(dictionary->data));
    freeItem(currentDataItem);
  }
  free(dictionary->key);
  free(dictionary);
  return;
}
