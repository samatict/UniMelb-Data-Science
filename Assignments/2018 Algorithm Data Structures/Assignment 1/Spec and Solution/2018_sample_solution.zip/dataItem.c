/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the function prototypes and declarations for an abstract dictionary.
*/
#include "dataItem.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

/*
  Creates a dataItem from the given array of pointers, putting the second
  pointer into the space pointed to by the given key location pointer. Assumes
  n fields are present in the given array and that the key is at the given key
  index.
*/
struct dataItem *createItem(char **dataList, int n, int keyIndex,
  char **keyLoc){
  struct dataItem *item;
  if(!dataList || !keyLoc) return NULL;
  item = (struct dataItem *) malloc(sizeof(struct dataItem));
  assert(item);
  int i, j;

  *keyLoc = dataList[keyIndex];

  item->count = n - 1;
  item->fields = (char **) malloc(sizeof(char *)*(item->count));
  if(item->count > 0){
    assert(item->fields);
  }
  i = 0; j = 0;
  for(i = 0; i < n; i++){
    if(i != keyIndex){
      (item->fields)[j] = dataList[i];
      j++;
    }
  }

  free(dataList);

  return item;
}

void printItem(struct dataItem *currentItem, FILE *fp){

  int i;

  void tryPrintField(char *format){
    if(i < currentItem->count){
      fprintf(fp, format, (currentItem->fields)[i]);
      i++;
    }
  }

  if(!currentItem){
    return;
  }

  fprintf(fp," --> ");
  i = 0;
  tryPrintField("ID: %s ");
  tryPrintField("Sex: %s || ");
  tryPrintField("Age: %s || ");
  tryPrintField("Height: %s || ");
  tryPrintField("Weight: %s || ");
  tryPrintField("Team: %s || ");
  tryPrintField("NOC: %s || ");
  tryPrintField("Games: %s || ");
  tryPrintField("Year: %s || ");
  tryPrintField("Season: %s || ");
  tryPrintField("City: %s || ");
  tryPrintField("Sport: %s || ");
  tryPrintField("Event: %s || ");
  tryPrintField("Medal: %s || ");
  fprintf(fp,"\n");

}

void freeItem(struct dataItem *item){
  if(! item ) return;
  int i;
  for(i = 0; i < item->count; i++){
    if((item->fields)[i]){
      free((item->fields)[i]);
    }
  }
  free(item->fields);
  free(item);
}
