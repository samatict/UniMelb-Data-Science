/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the function prototypes and declarations for an abstract dictionary.
*/
#include <stdio.h>

#ifndef DATAITEM
#define DATAITEM
struct dataItem {
  char **fields;
  int count;
};
#endif

/*
  Creates a dataItem from the given array of pointers, putting the second
  pointer into the space pointed to by the given key location pointer. Assumes
  n fields are present in the given array and that the key is at the given key
  index.
*/
struct dataItem *createItem(char **dataList, int n, int keyIndex,
  char **keyLoc);

/*
  Prints out the given item in the format specified by the assignment
  specification to the given file pointer.
*/
void printItem(struct dataItem *currentItem, FILE *fp);

/*
  Frees the given item and all the fields within it.
*/
void freeItem(struct dataItem *item);
