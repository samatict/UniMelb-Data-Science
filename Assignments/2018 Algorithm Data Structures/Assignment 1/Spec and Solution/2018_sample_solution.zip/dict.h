/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the function prototypes and declarations for an abstract dictionary.
*/

#include "dataItem.h"

struct dict;

/* Returns an empty dictionary. */
struct dict *makeDict();

/*
  Inserts a given set of data with the given key into the given dictionary.
  The key may be freed if multiple keys with the same name exist.
*/
void insertDict(struct dict *dictionary, char *key, struct dataItem *data);

/*
  Searches the given dictionary for the given key, and returns a list of all
  results that match that key. The number of key comparisons used in the
  operation are stored at the location of the given pointer (if it is not NULL).
*/
struct linkedList *searchDict(struct dict *dictionary, char *key,
  int *comparisons);

/*
  Frees the given dictionary.
*/
void freeDict(struct dict *dictionary);
