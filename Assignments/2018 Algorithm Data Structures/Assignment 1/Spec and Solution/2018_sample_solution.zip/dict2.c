/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the implementation details for an abstract dictionary implementing
    the dictionary using the concrete bst2.
*/
#include <stdlib.h>
#include <assert.h>
#include "dict.h"
#include "bst2.h"

struct dict {
  struct bst2 *bst;
};

struct dict *makeDict(){
  struct dict *returnVal = (struct dict *) malloc(sizeof(struct dict));
  assert(returnVal);
  returnVal->bst = makeBstDict();
  return returnVal;
}

void insertDict(struct dict *dictionary, char *key, struct dataItem *data){
  dictionary->bst = insertBstDict(dictionary->bst, key, data);
}

struct linkedList *searchDict(struct dict *dictionary, char *key,
  int *comparisons){
  return searchBstDict(dictionary->bst, key, comparisons);
}

void freeDict(struct dict *dictionary){
  freeBstTree(dictionary->bst);
  free(dictionary);
  return;
}
