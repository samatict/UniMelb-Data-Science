/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the implementation details for handling csv input.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "input.h"

#define DEFAULTLENGTH 15

char **readAndSplit(FILE *fp){
  if(!fp){
    return NULL;
  }
  char *line = NULL;
  size_t lineUsed = 0;
  ssize_t getLineReturn;
  int arrayAllocated = DEFAULTLENGTH;
  int arrayUsed = 0;

  char **returnSet = NULL;

  int length;

  int startString;
  int i;
  int inQuotes;

  getLineReturn = getline(&line, &lineUsed, fp);

  if(getLineReturn > 0){

    returnSet = (char **) malloc(sizeof(char *)*arrayAllocated);
    assert(returnSet);

    length = strlen(line);
    if(length > 0 && line[length - 1] == '\n'){
      line[length - 1] = '\0';
      length--;
    }

    startString = 0;
    i = 0;
    inQuotes = 0;
    for(i = 0; i < length; i++){
      if(line[i] == '"'){
        inQuotes = ! inQuotes;
      } else if(line[i] == ',' && !inQuotes) {
        line[i] = '\0';
        if(arrayUsed + 1 >= arrayAllocated){
          returnSet = (char **)
            realloc(returnSet, sizeof(char *)*(arrayAllocated + 1));
          assert(returnSet);
        }
        returnSet[arrayUsed] = strdup(&(line[startString]));
        arrayUsed++;
        startString = i + 1;
      }
    }

    if(startString < length){
      if(arrayUsed + 1 >= arrayAllocated){
        returnSet = (char **)
          realloc(returnSet, sizeof(char *)*(arrayAllocated + 1));
        assert(returnSet);
      }
      returnSet[arrayUsed] = strdup(&(line[startString]));
      arrayUsed++;
    }

    free(line);

    return returnSet;
  }

  if(line){
    free(line);
  }

  return NULL;
}

char *readKey(FILE *fp){
  char ** result = readAndSplit(fp);
  char *returnVal = NULL;
  if(result){
    returnVal = result[0];
    free(result);
  }
  return returnVal;
}
