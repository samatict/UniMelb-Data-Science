/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the function prototypes and declarations for handling csv input.
*/

/*
  Reads the next line from a file, and returns the array of each string, broken
  up by comma. Commas which occur inside unmatched quotes are considered part of
  the same field. All quotes from the original string are preserved.

  Each string (and the array) is allocated individually and must be freed by the
  calling function.
*/
char **readAndSplit(FILE *fp);

/*
  Reads the next line from a file, removes the end of line character if
  appropriate.

  Each string (and the array) is allocated and must be freed by the calling
  function.
*/
char *readKey(FILE *fp);
