/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the implementation details for a linked list.
*/

#include <stdlib.h>
#include <assert.h>
#include "dataItem.h"
#include "linkedList.h"

struct linkedList {
  struct dataItem *data;
  struct linkedList *next;
};

struct linkedList *makeList(){
  return NULL;
}

struct linkedList *prepend(struct linkedList *list, struct dataItem *data){
  struct linkedList *newHead = (struct linkedList *)
    malloc(sizeof(struct linkedList));
  assert(newHead);

  newHead->next = list;
  newHead->data = data;

  return newHead;
}

struct dataItem *pop(struct linkedList **list){
  if(! list || ! *list) return NULL;
  struct dataItem *returnItem = (*list)->data;
  struct linkedList *nextItem = (*list)->next;
  free(*list);

  *list = nextItem;

  return returnItem;
}

int emptyList(struct linkedList *list){
  if(list){
    return 0;
  } else {
    return 1;
  }
}

struct linkedList *getNext(struct linkedList *list){
  return list->next;
}

struct dataItem *getData(struct linkedList *list){
  return list->data;
}

void freeList(struct linkedList *list){
  struct linkedList *next;
  while(list){
    next = list->next;
    free(list);
    list = next;
  }
}
