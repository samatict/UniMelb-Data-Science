/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Contains the function prototypes and declarations for a linked list.
*/
#include "dataItem.h"

struct linkedList;

/* Returns an empty linkedList. */
struct linkedList *makeList();

/*
  Adds the given dataItem to the start of the list.
*/
struct linkedList *prepend(struct linkedList *list, struct dataItem *data);

/*
  Returns the first item from the list, and frees the associated data structure
  for that node. The list is moved forward one item.
*/
struct dataItem *pop(struct linkedList **list);

/*
  Returns 1 if the given list is empty.
*/
int emptyList(struct linkedList *list);

/*
  Non-destructively return the next node in the linked list.
*/
struct linkedList *getNext(struct linkedList *list);

/*
  Non-destructively return the item in a given linked list.
*/
struct dataItem *getData(struct linkedList *list);

/*
  Free the memory for each linked list node (not the data contained within).
*/
void freeList(struct linkedList *list);
