/*
  Written by Grady Fitzpatrick for Algorithms and Data Structures ( COMP20003 )

  Driver for dictionary which searches athletes.

  run using
    dict1 infile outfile < keyfile
  where infile is a csv-formatted file with 15 fields per line, where the second
    field is the key for that record. Each line in the input file should have no
    more than 512 characters, and each field in the input file should have no
    more than 128 characters.
  where outfile is the location that all results found for each key will be
    printed to.
  where keyfile (or stdin) is the list of keys to search for, one per line.
    These should match the relevant field in the csv, all quotes exactly as
    original.

  The program will print the number of comparisons for each key searched to
    stdout, and input will finish when the infile ends.
*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "input.h"
#include "dataItem.h"
#include "linkedList.h"
#include "dict.h"

#define FIELDS 15
#define KEYINDEX 1
#define NOTFOUND "NOTFOUND"

int main(int argc, char **argv){
  if(argc < 3){
    fprintf(stderr, "Incorrect number of arguments, run in the form\n");
    fprintf(stderr, "%s infile outfile < keyfile\n",argv[0]);
    return EXIT_FAILURE;
  }

  FILE *input;
  FILE *output;

  char **inputItem;
  char *key;

  struct dataItem *currentItem;

  struct dict *dictionary = makeDict();

  struct linkedList *searchResults;
  int comparisons;

  input = fopen(argv[1],"r");
  assert(input);
  output = fopen(argv[2],"w");
  assert(output);

  while((inputItem = readAndSplit(input))){
    currentItem = createItem(inputItem, FIELDS, KEYINDEX, &key);
    insertDict(dictionary, key, currentItem);
  };

  while((key = readKey(stdin))){
    comparisons = 0;
    searchResults = searchDict(dictionary, key, &comparisons);

    printf("%s --> %d\n", key, comparisons);

    if(emptyList(searchResults)){
      fprintf(output,"%s --> %s\n", key, NOTFOUND);
    }

    while(! emptyList(searchResults)){
      fprintf(output, "%s",key);
      printItem(pop(&searchResults), output);
    }
    free(key);
  }

  freeDict(dictionary);

  fclose(input);
  fclose(output);

  return EXIT_SUCCESS;
}
