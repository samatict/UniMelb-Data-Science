/* 
	Categorisation Program
	Written by Grady Fitzpatrick (Student ID: 575753, Staff ID: 110064) for   
	COMP20003 - Algorithms and Data Structures as part of the testing framework
	for the first assignment.
	
	Run in the form
		catProg
	
	A list of files are taken in through standard input, these are sorted into
	three sets of files, 
	the set which appears to be shared, which are output to	_guessShared,
	the set which appears to be for the first file, which are output to _guess1
	and the set which appears to be for the second file, which are output to 
		_guess2.
	
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#define DEFAULTLISTSIZE 256

/* Add the given currentLine to the list, adjusting allocated space for 	  */
/* fileList, and number of items in the list.								  */
void addToList(char ***fileList, int *numAllocated, int *numUsed, 
	char *currentLine);

/* If the filename mostly matches apart from the very end, then the first     */
/* file ending in 2 will cause the function to return a 2, the converse will  */
/* cause the function to return a 1, and in the event that neither is the     */
/* case, the function will return a 0.										  */
int comparefile(char *file1, char *file2);

int main(int argc, char **argv){
	FILE *sharedOutputFile = NULL;
	FILE *guessOutputFile1 = NULL;
	FILE *guessOutputFile2 = NULL;
	
	char **fileList = NULL;
	char **list1 = NULL;
	char **list2 = NULL;
	char **sharedList = NULL;
	int numAllocated = 0;
	int numUsed = 0;
	int list1Used = 0;
	int list2Used = 0;
	int sharedListUsed = 0;
	
	char *currentLine = NULL;
	size_t length = 0;
	
	int comp;
	
	int i, j;
	
	/* Read in all files from standard input.								  */
	while(getline(&currentLine, &length, stdin) != -1){
		// Delete newlines and carriage returns.
		for(i = 0; i < strlen(currentLine); i++){
			if(currentLine[i] == '\n' || currentLine[i] == '\r'){
				for (j = i; j < strlen(currentLine); j++){
					currentLine[j] = currentLine[j + 1];
				}
				/* next iteration will push forward pointer, which will skip  */
				/* a character, move back to compensate.					  */
				i--;
			}
		}
		addToList(&fileList, &numAllocated, &numUsed, currentLine);
		currentLine = NULL;
	}
	
	sharedList = (char **) malloc(sizeof(char *)*numUsed);
	assert(sharedList);
	list1 = (char **) malloc(sizeof(char *)*numUsed);
	assert(list1);
	list2 = (char **) malloc(sizeof(char *)*numUsed);
	assert(list2);
	
	for(i = 0; i < numUsed; i++){
		/* Check against all other files, add into appropriate bucket.	  */
		for(j = 0; j < numUsed; j++){
			if (i == j){
				/* Special case when i == numUsed, as this would otherwise be */
				/* dropped, since comp == 0 path leads here assuming it'll be */
				/* caught at j == numUsed - 1								  */
				if (i == (numUsed - 1)){
					addToList(&sharedList, &numAllocated, &sharedListUsed, 
						fileList[i]);
				}
				continue;
			}
			if ((comp = comparefile(fileList[i],fileList[j])) == 0){
				/* Files probably independent, move to shared files.		  */
				if (j == (numUsed - 1))
					addToList(&sharedList, &numAllocated, &sharedListUsed, 
						fileList[i]);
			} else if (comp == 1){
				/* File probably belongs in list 1. */
				addToList(&list1, &numAllocated, &list1Used, fileList[i]);
				break;
			} else {
				/* Probably belongs in list 2. */
				addToList(&list2, &numAllocated, &list2Used, fileList[i]);
				break;
			}
		}
	}
	
	printf("Shared list:\n");
	for(i = 0; i < sharedListUsed; i++){
		printf("%s\n",sharedList[i]);
	}
	printf("First Executable list:\n");
	for(i = 0; i < list1Used; i++){
		printf("%s\n",list1[i]);
	}
	printf("Second Executable list:\n");
	for(i = 0; i < list2Used; i++){
		printf("%s\n",list2[i]);
	}
	
	/* Process shared files list to check for function similarity to identify */
	/* files which belong in only one list.									  */
	for(i = 0; i < sharedListUsed; i++){
		
	}
	
	/* Open _guessShared													  */
	sharedOutputFile = fopen("_guessShared","w");
	assert(sharedOutputFile);
	for(i = 0; i < sharedListUsed; i++){
		fprintf(sharedOutputFile, "%s\n", sharedList[i]);
	}
	
	/* Open _guess1															  */
	guessOutputFile1 = fopen("_guess1","w");
	assert(guessOutputFile1);
	for(i = 0; i < list1Used; i++){
		fprintf(guessOutputFile1, "%s\n", list1[i]);
	}
	
	/* Open _guess2															  */
	if(list2Used > 0){
		guessOutputFile2 = fopen("_guess2","w");
		assert(guessOutputFile2);
		for(i = 0; i < list2Used; i++){
			fprintf(guessOutputFile2, "%s\n", list2[i]);
		}
	}
	
	return 0;
}

void addToList(char ***fileList, int *numAllocated, int *numUsed, 
	char *currentLine){
	if(*fileList == NULL){
		*fileList = (char **) malloc(sizeof(char *)*DEFAULTLISTSIZE);
		assert(*fileList);
		*numAllocated = DEFAULTLISTSIZE;
	}
	if (*numUsed + 1 > *numAllocated){
		*fileList = (char **) realloc(*fileList,
			sizeof(char *)*(*numAllocated)*2);
		assert(*fileList);
		*numAllocated *= 2;
	}
	(*fileList)[*numUsed] = currentLine;
	(*numUsed)++;
}

int comparefile(char *file1, char *file2){
	/* Flags for whether either filename contains a 2.						  */
	int firstFilename2 = 0;
	int secondFilename2 = 0;
	
	int i = 0;
	
	if (strcmp(file1, file2) == 0){
		/* Latter logic assumes filename format "*.c", but will still fail on */
		/* equality comparisons.											  */
		fprintf(stderr, "ERROR: File compare function was sent %s and %s\n",
			file1, file2);
		return 0;
	}
	
	for(i = 0; i < strlen(file1); i++){
		if (file1[i] == '2')
			firstFilename2++;
	}
	for(i = 0; i < strlen(file2); i++){
		if (file2[i] == '2')
			secondFilename2++;
	}
	
	/* If no twos in either filename, assume independence.					  */
	if ( ! firstFilename2 && ! secondFilename2)
		return 0;
	
	if ( firstFilename2 || secondFilename2 ){
		if (strlen(file1) < strlen(file2) && firstFilename2 >= secondFilename2){
			/* As second filename longer than first and has more or the same  */
			/* number of twos (ie x2stage2.c x2stagex2.c), assume 			  */
			/* independence.												  */
			return 0;
		}
		if (strlen(file2) < strlen(file1) && secondFilename2 >= firstFilename2){
			/* As first filename longer than second and has more or the same  */
			/* number of twos (ie x2stage2.c x2stagex2.c), assume 			  */
			/* independence.												  */
			return 0;
		}
		/* Assumes that both files follow the format "*.c", will continue     */
		/* until hitting the .c, this means xxxx.c and xxxxyyyy2.c will match */
		/* but this is intentional behaviour to catch x.c - xstage2.c files   */
		/* as well without having to do language comprehension.				  */
		for (i = 0; i < strlen(file2); i++){
			if (file1[i] != file2[i]){
				/* Check if the difference is a difference in being either a  */
				/* 1 or a 2.												  */
				if (file1[i] == '1' && file2[i] == '2'){
					/* Assume same file with different stage number.		  */
					return 1;
				} else if (file1[i] == '2' && file2[i] == '1'){
					/* Assume converse of above.							  */
					return 2;
				} else if (file1[i] == '.' && secondFilename2 > firstFilename2){
					/* Second filename has more 2s and reached the end of	  */
					/* the pre-extension filename, so assume second file      */
					/* belongs to the second executable and first file to the */
					/* first.												  */
					return 1;
				} else if (file2[i] == '.' && firstFilename2 > secondFilename2){
					/* Assume converse of above.							  */
					return 2;
				} else {
					return 0;
					break;
				}
			}
		}
	}
	fprintf(stderr,"ERROR: Reached end of comparison function with %s - %s", 
		file1, file2);
	return 0;
}
