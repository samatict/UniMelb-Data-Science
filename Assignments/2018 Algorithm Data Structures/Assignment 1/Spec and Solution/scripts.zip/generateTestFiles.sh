function constructAlternatives
{
	# Construct SECOND data set.
	echo "outGen $TESTINGDIR$1.data $SECOND_TEST_DIR$1.data d < $TESTINGDIR$1.keys > $SECOND_TEST_DIR$1.keys"
	outGen $TESTINGDIR$1.data $SECOND_TEST_DIR$1.data d < $TESTINGDIR$1.keys > $SECOND_TEST_DIR$1.keys
	
	# Construct THIRD data set.
	echo "outGen $TESTINGDIR$1.data $THIRD_TEST_DIR$1.data d < $TESTINGDIR$1.keys > $THIRD_TEST_DIR$1.keys"
	outGen $TESTINGDIR$1.data $THIRD_TEST_DIR$1.data c < $TESTINGDIR$1.keys > $THIRD_TEST_DIR$1.keys
	
	# Construct FOURTH data set.
	echo "outGen $SECOND_TEST_DIR$1.data $FOURTH_TEST_DIR$1.data c < $SECOND_TEST_DIR$1.keys > $FOURTH_TEST_DIR$1.keys"
	outGen $SECOND_TEST_DIR$1.data $FOURTH_TEST_DIR$1.data c < $SECOND_TEST_DIR$1.keys > $FOURTH_TEST_DIR$1.keys
	
	# Construct FIFTH data set.
	echo "cp $SECOND_TEST_DIR$1.data $FIFTH_TEST_DIR$1.data"
	cp $SECOND_TEST_DIR$1.data $FIFTH_TEST_DIR$1.data
	echo "cp $FOURTH_TEST_DIR$1.keys $FIFTH_TEST_DIR$1.keys"
	cp $FOURTH_TEST_DIR$1.keys $FIFTH_TEST_DIR$1.keys
}

function generateOutput
{
	VALGRIND=
	echo "$VALGRIND $FILEOUTGEN $1.data $1.out a 1 < $1.keys > $SAMPLEOUT$1.stdout.l.1"
	echo "=================================================================="
	$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out a 1 < $TESTINGDIR$1.keys > $SAMPLEOUT$1.stdout.l.1
	cat $SAMPLEOUT$1.stdout.l.1
	echo
	echo "Expected output file (order doesn't matter):"
	echo "============================================"
	cat $SAMPLEOUT$1.out
	echo "============================================"
	
	echo "$VALGRIND $FILEOUTGEN $1.data $1.out b 1 < $1.keys > $SAMPLEOUT$1.stdout.r.1"
	echo "=================================================================="
	$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out b 1 < $TESTINGDIR$1.keys > $SAMPLEOUT$1.stdout.r.1
	cat $SAMPLEOUT$1.stdout.r.1
	echo
	echo "=================================================================="
	echo "$VALGRIND $FILEOUTGEN $1.data $1.out a 2 < $1.keys > $SAMPLEOUT$1.stdout.l.2"
	$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out a 2 < $TESTINGDIR$1.keys > $SAMPLEOUT$1.stdout.l.2
	cat $SAMPLEOUT$1.stdout.l.2
	echo
	echo "=================================================================="
	echo "$VALGRIND $FILEOUTGEN $1.data $1.out b 2 < $1.keys > $SAMPLEOUT$1.stdout.r.2"
	$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out b 2 < $TESTINGDIR$1.keys > $SAMPLEOUT$1.stdout.r.2
	cat $SAMPLEOUT$1.stdout.r.2
	echo
	echo "=================================================================="
}

function testOutput
{
	VALGRIND=
	echo "========================================================================================================="
	echo "$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out e $SAMPLEOUT$1.stdout.l.1 1 < $TESTINGDIR$1.keys"
	echo "==========================================================="
	$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out e $SAMPLEOUT$1.stdout.l.1 1 < $TESTINGDIR$1.keys
	echo "==========================================================="
	echo "valgrind $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out e $SAMPLEOUT$1.stdout.r.1 1 < $TESTINGDIR$1.keys"
	$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out e $SAMPLEOUT$1.stdout.r.1 1 < $TESTINGDIR$1.keys
	echo "==========================================================="
	echo "valgrind $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out e $SAMPLEOUT$1.stdout.l.2 2 < $TESTINGDIR$1.keys"
	$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out e $SAMPLEOUT$1.stdout.l.2 2 < $TESTINGDIR$1.keys
	echo "==========================================================="
	echo "valgrind $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out e $SAMPLEOUT$1.stdout.r.2 2 < $TESTINGDIR$1.keys"
	$VALGRIND $FILEOUTGEN $TESTINGDIR$1.data $SAMPLEOUT$1.out e $SAMPLEOUT$1.stdout.r.2 2 < $TESTINGDIR$1.keys
	echo "========================================================================================================="
}

# Program to generate sets from data.
FILEOUTGEN=~/testing/outGen/outGen

# Location of original set of inputs.
TESTINGDIR=~/testing/

# Target locations.
SECOND_TEST_DIR=~/testing2/
THIRD_TEST_DIR=~/testing3/
FOURTH_TEST_DIR=~/testing4/
FIFTH_TEST_DIR=~/testing5/

# Sample output folder
SAMPLEOUT=~/testing/sampleOut/

# Descriptions for testing outputs.
DESCRIPTION="# This dataset is the basic dataset, it involves a few parts which shouldn't \
# cause issues if students are matching the full extent of what is expected \
# based on the specification. \
"
DESCRIPTION2="# This dataset is the initial dataset with an additional newline added at the  \
# end of the file. Such practice is generally recommended, however not necessary,  \
# hence to handle the widest range of reasonable possible input, if the buffer  \
# has content in it when the stream ends, the data should be entered into the   \
# database.  \
# Common errors seen which lead to requiring this file:  \
#  - Looking for ""\n"" to end input, dropping the line entirely if this character  \
#    is not present.  \
"
DESCRIPTION3="# This dataset is the initial dataset instead using an additional carriage  \
# return to mark the end of a line. This is consistent with some csv standards \
# which exist on the web, however, no official standard exists, so assuming this \
# is the case is an error, as the sample data provided does not follow this  \
# standard. Assuming the standard follows \n convention instead of \r\n  \
# convention allows lookup to proceed successfully in addition, so dealing with \
# the \r is only a necessity for visual clarity. \
# Common Errors which lead to requiring this file: \
#  - Deleting final character of input regardless of what it is, causing single \
#    character additions to be ignored. \
#  - Not testing the provided files. \
"
DESCRIPTION4="# This dataset is the third dataset (using \r\n) instead using an additional  \
# carriage return and new line at the end of the file. \
# Common Errors which lead to requiring this file: \
#  - Deleting final character of input regardless of what it is, causing single \
#    character additions to be ignored and losing the last character of all other \
#    inputs. \
#  - Not testing the provided files. \
#  - Looking for ""\n"" to end input, dropping the line entirely if this character \
#    is not present. \
"
DESCRIPTION5="# This dataset is the second dataset (newline at end of file) using the queries  \
# from the fourth dataset (\r\n line endings). This is generally the result of \
# pulling the data files and adjusting so testing works on Windows. This is the \
# most erroneous as the data cannot be retrieved in the same way it is entered. \
#  \
# Common Errors which lead to requiring this file: \
#  - Deleting final character of input regardless of what it is, causing single \
#    character additions to be ignored and losing the last character of all other \
#    inputs. \
#  - Not testing the provided files on the server instead of Windows. \
#  - Looking for ""\n"" to end input, dropping the line entirely if this character \
#    is not present. \
#  - Using standard input (keyboard at runtime) instead of writing test cases to \
#    test with \
"

echo "Generating Descriptions in folders."
echo $DESCRIPTION > $TESTINGDIR/description.txt
echo $DESCRIPTION2 > $SECOND_TEST_DIR/description.txt
echo $DESCRIPTION3 > $THIRD_TEST_DIR/description.txt
echo $DESCRIPTION4 > $FOURTH_TEST_DIR/description.txt
echo $DESCRIPTION5 > $FIFTH_TEST_DIR/description.txt

echo "Constructing alternative datasets."
constructAlternatives 1-vistest
constructAlternatives 2-vistest
constructAlternatives 3-2node
constructAlternatives 4-3node
constructAlternatives 5-3node-reversed
constructAlternatives 6-multichar
constructAlternatives 7-leftlean
constructAlternatives 8-rightlean
constructAlternatives 9-notfound
constructAlternatives 10-rlsearch
constructAlternatives 11-tricky-rlr
constructAlternatives 12-tricky-lrl
constructAlternatives 13-rstick
constructAlternatives 14-balanced
constructAlternatives 15-multi-word
constructAlternatives 16-127-key
constructAlternatives 17-128-key
constructAlternatives 18-memory-50
constructAlternatives 19-memory-100
constructAlternatives 20-llrl-dup
constructAlternatives 21-rrlr-dup
constructAlternatives 22-dup1
constructAlternatives 22-dup2
constructAlternatives 22-dup1000
constructAlternatives 23-511-line
constructAlternatives 24-512-line
constructAlternatives 25-big-data
constructAlternatives 26-big-key

echo "Building expected output."
generateOutput 1-vistest
generateOutput 2-vistest
generateOutput 3-2node
generateOutput 4-3node
generateOutput 5-3node-reversed
generateOutput 6-multichar
generateOutput 7-leftlean
generateOutput 8-rightlean
generateOutput 9-notfound
generateOutput 10-rlsearch
generateOutput 11-tricky-rlr
generateOutput 12-tricky-lrl
generateOutput 13-rstick
generateOutput 14-balanced
generateOutput 15-multi-word
generateOutput 16-127-key
generateOutput 17-128-key
generateOutput 18-memory-50
generateOutput 19-memory-100
generateOutput 20-llrl-dup
generateOutput 21-rrlr-dup
generateOutput 22-dup1
generateOutput 22-dup2
generateOutput 22-dup1000
generateOutput 23-511-line
generateOutput 24-512-line
generateOutput 25-big-data
generateOutput 26-big-key

echo "Self-testing accuracy of results & outGen checking."
testOutput 1-vistest
testOutput 2-vistest
testOutput 3-2node
testOutput 4-3node
testOutput 5-3node-reversed
testOutput 6-multichar
testOutput 7-leftlean
testOutput 8-rightlean
testOutput 9-notfound
testOutput 10-rlsearch
testOutput 11-tricky-rlr
testOutput 12-tricky-lrl
testOutput 13-rstick
testOutput 14-balanced
testOutput 15-multi-word
testOutput 16-127-key
testOutput 17-128-key
testOutput 18-memory-50
testOutput 19-memory-100
testOutput 20-llrl-dup
testOutput 21-rrlr-dup
testOutput 22-dup1
testOutput 22-dup2
testOutput 22-dup1000
testOutput 23-511-line
testOutput 24-512-line
testOutput 25-big-data
testOutput 26-big-key

