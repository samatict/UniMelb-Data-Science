/*
	Contains implementation details for a binary search tree,
	which inserts according to a given comparison function.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "bst.h"
#include "querySet.h"
#include "resultSet.h"

#define DEFAULTALLOCSIZE 2

struct bst {
	struct bstInner *head;
	enum treeType type;
	int (*compare)(void *, void *);
	void (*freeData)(void *);
	void (*symlinkData)(void *);
	void *(*createItem)(void *);
	void *(*insertItem)(void *, void *);
	void *(*createNoResultItem)();
};

struct bstInner {
	struct bstInner *left;
	struct bstInner *right;
	void *data;
};

struct bst *createBST(int (*compare)(void *, void *), void (*freeData)(void *),
	void (*symlinkData)(void *), void *(*createItem)(void *key), 
	void *(*insertItem)(void *, void *), void *(*createNoResultItem)(),
	enum treeType type){
	struct bst *bst = (struct bst *) malloc(sizeof(struct bst));
	
	bst->head = NULL;
	bst->type = type;
	bst->compare = compare;
	bst->freeData = freeData;
	bst->symlinkData = symlinkData;
	bst->createItem = createItem;
	bst->insertItem = insertItem;
	bst->createNoResultItem = createNoResultItem;
	
	return bst;
}

struct bst *bstInsert(struct bst *bst, void *item){
	struct bstInner **insertLocation = &(bst->head);
	int comparison;
    while(*insertLocation){
		comparison = bst->compare(item, (*insertLocation)->data);
        if(comparison < 0){
            insertLocation = &((*insertLocation)->left);
        } else if(comparison > 0) {
            insertLocation = &((*insertLocation)->right);
        } else {
			if(bst->type == LTETREE){
				/* Same as else branch. */
				insertLocation = &((*insertLocation)->right);
			} else {
				/* Insert here. */
				(*insertLocation)->data = 
					bst->insertItem(item, (*insertLocation)->data);
				break;
			}
		}
    }
	
	if (! *insertLocation){
		*insertLocation = (struct bstInner *) malloc(sizeof(struct bstInner));
		assert(*insertLocation);

		(*insertLocation)->left = NULL;
		(*insertLocation)->right = NULL;
		(*insertLocation)->data = bst->createItem(item);
		(*insertLocation)->data = 
			bst->insertItem(item, (*insertLocation)->data);
		bst->symlinkData(item);
	}
	
    return bst;
}

void queryTree(struct bst *bst, struct query *query, 
	struct resultSet *resultSet){
	struct bstInner **findLocation = &(bst->head);
	int comparison;
	int comparisons = 0;
	
	/* Most recent result found. */
	struct result *tempResult;
	/* Array of results. */
	void **resultsList = NULL;
	int resultCount = 0;
	int allocatedCount = 0;
	
	tempResult = (struct result *) malloc(sizeof(struct result));
	assert(tempResult);
	
    while(*findLocation){
		comparison = bst->compare(getQueryData(query), (*findLocation)->data);
		comparisons++;
        if(comparison < 0){
            findLocation = &((*findLocation)->left);
        } else if(comparison > 0) {
            findLocation = &((*findLocation)->right);
        } else {
			if(bst->type == LTETREE){
				/* Add data item to results list. */
				if((resultCount + 1) > allocatedCount){
					if(! resultsList){
						allocatedCount = DEFAULTALLOCSIZE;
						resultsList = (void **) 
							malloc(sizeof(void *)*allocatedCount);
						assert(resultsList);
					} else {
						allocatedCount *= 2;
						resultsList = (void **)	realloc(resultsList,
							sizeof(void *)*allocatedCount);
						assert(resultsList);
					}
				}
				resultsList[resultCount] = (*findLocation)->data;
				resultCount++;
				/* Same as else branch. */
				findLocation = &((*findLocation)->right);
			} else {
				/* Malloced for simplicity. */
				resultsList = (void **) malloc(sizeof(void *));
				assert(resultsList);
				*(resultsList) = (*findLocation)->data;
				resultCount = 1;
				allocatedCount = 1;
				break;
			}
		}
    }
	/* Comparison reached NULL, meaning all present have been found. */
	tempResult->comparisons = comparisons;
	tempResult->query = query;
	if(resultCount < 1){
		resultsList = bst->createNoResultItem();
		resultCount = 1;
	}
	tempResult->returnedData = resultsList;
	tempResult->returnCount = resultCount;
	tempResult->type = FRESH;
	tempResult->sourceFileStdin = NULL;
	tempResult->sourceFileOutfile = NULL;
	
	addResult(resultSet, tempResult);
}

void freeTree(struct bst **bst){
	/* Recursively free/unlink all items in BST. */
	void freeBSTInner(struct bstInner *bstInner){
		if(! bstInner) return;
		freeBSTInner(bstInner->left);
		freeBSTInner(bstInner->right);
		(*bst)->freeData(bstInner->data);
		free(bstInner);
	}
	freeBSTInner((*bst)->head);
	free(*bst);
	*bst = NULL;
}


