/*
	Contains prototypes and definitions for a binary search tree,
	which inserts according to a given comparison function.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

struct bst;

#include "querySet.h"
#include "resultSet.h"


#ifndef TREETYPE
#define TREETYPE 1
enum treeType {
	LTETREE,
	LGETERNARY
};
#endif

/* 
	Creates an empty bst with a comparison function which compares two values 
	and a free data function which is run on each data item and is intended to 
	handle freeing all its associated data. Each freshly inserted item will have
	the symlinkData function run if it is inserted into a fresh node of its own.
	If tree is of type LTE, equal items will be stored in the same way as less 
	than items, according to the given comparison function. If the tree is of 
	type LGETERNARY, equal items are stored in a linked list in each node. The
	createItem function is used to create a fresh data item list and itemInsert 
	is used to insert a data item.
*/
struct bst *createBST(int (*compare)(void *, void *), void (*freeData)(void *),
	void (*symlinkData)(void *), void *(*createItem)(void *key), 
	void *(*insertItem)(void *, void *), void *(*createNoResultItem)(),
	enum treeType type);

/* Inserts a given value into a given BST */
struct bst *bstInsert(struct bst *bst, void *item);

/* Runs a given query on the given tree and adds all matched results to the 
	given result set. */
void queryTree(struct bst *bst, struct query *query, 
	struct resultSet *resultSet);

/* Frees the tree and all data within it. */
void freeTree(struct bst **bst);
