/*
	Contains implementation details for creating and manipulating an object
	which checks the accuracy of a given set of outputs.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "testResultSet.h"
#include "resultSet.h"
#include "checkResult.h"
#include "errorSet.h"
#include "querySet.h"

/* Taken from resultSet.c */
#include "resultSetStruct.c"

enum bestMatch {
	LE,
	ME,
	BOTH
};

struct checkResult {
	enum bestMatch bestMatch;
	struct errorSet *leErrors;
	struct errorSet *meErrors;
	struct errorSet *parseErrorsStdout;
	struct errorSet *parseErrorsData;
};

/* Create an empty set to hold results of check. */
struct checkResult *createCheckResult();

/* 
	Returns 0 if leResults has a different number of comparisons for any of 
	its results than meResults.
*/
int evaluateComparisons(struct resultSet *leResults, 
	struct resultSet *meResults);

struct checkResult *createCheckResult(){
	struct checkResult *returnCheckResult;
	
	returnCheckResult = (struct checkResult *) 
		malloc(sizeof(struct checkResult));
	assert(returnCheckResult);
	
	returnCheckResult->bestMatch = LE;
	returnCheckResult->leErrors = NULL;
	returnCheckResult->meErrors = NULL;
	returnCheckResult->parseErrorsStdout = NULL;
	returnCheckResult->parseErrorsData = NULL;
	
	return returnCheckResult;
}

struct checkResult *checkResults(struct resultSet *leResults, 
	struct resultSet *meResults, struct testResultSet *testingResults){
	/* Check if both results sets are the same. */
	int bothMode = evaluateComparisons(leResults, meResults);
	int leMatches = 0;
	int meMatches = 0;
	int matchResult = 0;
	int i;
	struct checkResult *checkReturn = createCheckResult();
	
	/* If both are the same, set to both match. */
	if(bothMode){
		checkReturn->bestMatch = BOTH;
		checkReturn->leErrors = createErrorSet();
	} else {
		checkReturn->leErrors = createErrorSet();
		checkReturn->meErrors = createErrorSet();
	}
	
	/* Initialise testingResults to be ready to check through. */
	resetProgress(testingResults);
	
	/* Loop through all results  */
	for(i = 0; i < leResults->used && i < meResults->used; i++){
		matchResult = checkResult(leResults->results[i], meResults->results[i], 
			checkReturn->leErrors, checkReturn->meErrors, 
			&(checkReturn->parseErrorsStdout), 
			&(checkReturn->parseErrorsData), testingResults);
		if(matchResult <= 0){
			leMatches++;
		}
		if(matchResult >= 0){
			meMatches++;
		}
	}
	
	/* Set best match. */
	if(leMatches == meMatches){
		checkReturn->bestMatch = BOTH;
	} else if(leMatches > meMatches){
		checkReturn->bestMatch = LE;
	} else {
		checkReturn->bestMatch = ME;
	}
	
	/* Add errors to relevant section. */
	if(checkReturn->bestMatch == ME){
		addMissingErrors(testingResults, checkReturn->meErrors);
	} else {
		addMissingErrors(testingResults, checkReturn->leErrors);
	}
	
	return checkReturn;
}

int evaluateComparisons(struct resultSet *leResults, 
	struct resultSet *meResults){
	/* Check comparison counts of leResults and meResults, any mismatch is 
		returns 0, 1 is returned otherwise. */
	int i;
	for(i = 0; i < leResults->used; i++){
		if(((meResults->results)[i])->comparisons != 
			((leResults->results)[i])->comparisons){
			return 0;	
		}
	}
	return 1;
}

void printCheckResult(struct checkResult *checkResult){
	int errorFieldPrintCount = 0;
	int errorTypeCount = 0;
	struct errorSet *printSet;
	/* 
		Print the error result and increase error field print count if any 
		errors of the given type occured. error given should have exactly one
		field for the error count.
	*/
	void printIfError(struct errorSet *set, enum errorType errorType, 
		char *errorText){
		int errorCountRes;
		if((errorCountRes = errorCount(set, errorType))){
			printf(errorText,errorCountRes);
			
			printErrors(set, errorType);
			
			errorFieldPrintCount++;
		}
	}
	
	void incIfError(enum errorType type){
		if(errorCount(printSet, type) > 0){
			errorTypeCount++;
		}
	}
	
	/* Print each set of errors. */
	if(checkResult->bestMatch == ME){
		printSet = checkResult->meErrors;
	} else {
		printSet = checkResult->leErrors;
	}
	
	switch(checkResult->bestMatch){
		case LE:
			printf("%s best matching set.\n","LE");
			break;
		case ME:
			printf("%s best matching set.\n","ME");
			break;
		case BOTH:
			printf("%s best matching set.\n","BOTH");
			break;
	}
	
	incIfError(MISSINGQUERYERROR);
	if(!errorTypeCount){
		incIfError(MISSINGDATAERROR);
	}
	incIfError(EXTRAERROR);
	incIfError(COMPARISONERROR);
	
	if(errorTypeCount < 2){
		if(errorCount(printSet, MISSINGQUERYERROR) 
			|| errorCount(printSet, MISSINGDATAERROR)){
			printf("missing\n");
		}
		if(errorCount(printSet, EXTRAERROR)){
			printf("extra\n");
		}
		if(errorCount(printSet, COMPARISONERROR)){
			printf("count\n");
		}
	} else {
		if(errorCount(printSet, MISSINGQUERYERROR) 
			|| errorCount(printSet, MISSINGDATAERROR)){
			printf("m");
		}
		if(errorCount(printSet, EXTRAERROR)){
			printf("e");
		}
		if(errorCount(printSet, COMPARISONERROR)){
			printf("c");
		}
		printf("\n");
	}
	
	printIfError(checkResult->parseErrorsStdout, LEXERROR, 
		"[RESULTS BEYOND MAY BE UNSTABLE] [Stdout] Lexing errors (%d):\n");
	printIfError(checkResult->parseErrorsStdout, PARSEERROR, 
		"[RESULTS BEYOND MAY BE UNSTABLE] [Stdout] Parsing errors (%d):\n");
	printIfError(checkResult->parseErrorsData, LEXERROR, 
		"[RESULTS BEYOND MAY BE UNSTABLE] [Outfile] Lexing errors (%d):\n");
	printIfError(checkResult->parseErrorsData, PARSEERROR, 
		"[RESULTS BEYOND MAY BE UNSTABLE] [Outfile] Parsing errors (%d):\n");
	printIfError(printSet, WRONGFILEQUERY, 
		"Queries only found in wrong file (%d):\n");
	printIfError(printSet, WRONGFILEDATA, 
		"Data only found in wrong file (%d):\n");
	printIfError(printSet, MISSINGQUERYERROR, "Missing Queries (%d):\n");
	printIfError(printSet, MISSINGDATAERROR, "Missing Data Errors (%d):\n");
	printIfError(printSet, EXTRAERROR, "Extra Results Included Errors (%d)\n");
	printIfError(printSet, COMPARISONERROR, "Comparison Count Errors (%d)\n");
	
	if(errorFieldPrintCount == 0){
		printf("No errors detected.\n");
	}
}

void freeCheckResult(struct checkResult **checkResult){
	/* TO BE IMPLEMENTED - MAYBE. */
	return;
}
