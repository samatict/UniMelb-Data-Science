/*
	Contains prototypes and definitions for creating and manipulating an object
	which checks the accuracy of a given set of outputs.
	
	Note: This is currently tightly coupled with a few other things, this is not 
	necessary, but saves a bit of time now. Splitting this a bit more should be
	useful for making this script more reusable.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include "testResultSet.h"
#include "resultSet.h"
#include "errorSet.h"

struct checkResult;

/* 
	Compares the given le results and me results to the given testing results.
	Parse errors are added to the structure and discrepencies are dealt with. 
	
	Note: Only the best match erros includes all errors encountered for that 
	test mode.
*/
struct checkResult *checkResults(struct resultSet *leResults, 
	struct resultSet *meResults, struct testResultSet *testingResults);

/* Prints the results of checking the results given. */
void printCheckResult(struct checkResult *checkResult);

/*
	Frees all memory handled by results checking return structure.
*/
void freeCheckResult(struct checkResult **checkResult);
