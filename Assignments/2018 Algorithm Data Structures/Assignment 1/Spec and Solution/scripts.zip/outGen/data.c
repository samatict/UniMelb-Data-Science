/*
	Contains implementation details for creating and manipulating a data 
	item.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "data.h"

/* Which field (indexed from 0) the key should be taken from. */
#define KEYFIELD 1
/* String for result when no results found for given query. */
#define NOITEMFOUNDSTRING "NOTFOUND"

#include "dataStruct.c"

int dataCompare(struct data *left, struct data *right){
	if(!left &&  right) return -1;
	if(!left && !right) return  0;
	if(!right         ) return  1;
	return strcmp(left->key, right->key);
}

struct dataItem *createDataItem(char **list, int number){
	struct dataItem *returnItem = (struct dataItem *) 
		malloc(sizeof(struct dataItem));
	assert(returnItem);
	returnItem->fields = list;
	/* TODO: Store line context. */
	returnItem->linkCount = 0;
	returnItem->fieldCount = number;
	return returnItem;
}

struct data *createEmptyData(){
	struct data *returnData = (struct data *) malloc(sizeof(struct data));
	assert(returnData);
	returnData->items = NULL;
	returnData->count = 0;
	returnData->key = NULL;
	return returnData;
}

struct data *createKeyOnlyData(char *key){
	struct data *returnData = (struct data *) malloc(sizeof(struct data));
	assert(returnData);
	returnData->items = NULL;
	returnData->count = 0;
	returnData->key = strdup(key);
	return returnData;
}

struct data *mergeLists(struct data *list1, struct data *list2){
	int newSize;
	int i;
	
	if(!list2) return list1;
	if(!list1) return list2;
	newSize = list1->count + list2->count;
	list2->items = (struct dataItem **) realloc(list2->items, 
		sizeof(struct dataItem *)*newSize);
	assert(list2->items);
	
	for(i = 0; i < list1->count; i++){
		list2->items[i + list2->count] = list1->items[i];
	}
	
	list2->count = newSize;
	
	/* Don't free these for now because the dependence hierarchy is complex.
		Should check if the item is linked elsewhere, but using a quick 
		approach for now. */
	/*free(list1->items);
	free(list1);*/
	
	return list2;
}

struct data *nonDestructiveMergeLists(struct data *list1, struct data *list2){
	int i;
	
	assert(list2);
	if(!list1) return list2;
	int newSize = list1->count + list2->count;
	list2->items = (struct dataItem **) realloc(list2->items, 
		sizeof(struct dataItem *)*newSize);
	assert(list2->items);
	
	for(i = 0; i < list1->count; i++){
		list2->items[i + list2->count] = list1->items[i];
	}
	
	list2->count = newSize;
	
	dataLink(list1);
	
	return list2;
}

void printData(struct query *query, void *data, FILE *outfile){
	struct data *queryKey = (struct data *) getQueryData(query);
	struct data *dataP = (struct data *) data;
	int i, j;
	
	if(! outfile) return;
	
	void printNextField(const char formatString[]){
		if(j == 0){
			/* If 0th field is NOTFOUND, we just print it. */
			if(strcmp((dataP->items[i])->fields[j], NOITEMFOUNDSTRING) == 0){
				fprintf(outfile, "%s",(dataP->items[i])->fields[j]);
				j++;
				return;
			}
		}
		if(j == KEYFIELD){
			j++;
		}
		if((dataP->items[i])->fieldCount > j){
			fprintf(outfile,formatString,(dataP->items[i])->fields[j]);
			j++;
		}
	}

	for(i = 0; i < dataP->count; i++){
		fprintf(outfile,"%s --> ", queryKey->key);
		j = 0;
		/* 
			Optional TODO: refactor to nested function taking format string as
			argument.
		*/
		
		printNextField("ID: %s "       );
		printNextField("Sex: %s || "   );
		printNextField("Age: %s || "   );
		printNextField("Height: %s || ");
		printNextField("Weight: %s || ");
		printNextField("Team: %s || "  );
		printNextField("NOC: %s || "   );
		printNextField("Games: %s || " );
		printNextField("Year: %s || "  );
		printNextField("Season: %s || ");
		printNextField("City: %s || "  );
		printNextField("Event: %s || " );
		printNextField("Sport: %s || " );
		printNextField("Medal: %s || " );
		
		fprintf(outfile, "\n");
	}
}

void addDataItem(struct dataItem *item, struct data *dataSet){
	/* Check we have space to insert item. */	
	dataSet->items = (struct dataItem **) realloc(dataSet->items, 
		sizeof(struct dataItem *)*(dataSet->count + 1));
	assert(dataSet->items);
	(dataSet->items)[dataSet->count] = item;
	dataSet->count++;
}

char *getDataKey(struct data *data){
	return data->key;
}

void setDataKey(struct data *data, char **fieldList, int fieldCount){
	if(fieldCount > KEYFIELD){
		data->key = fieldList[KEYFIELD];
	}
}

void dataUnlink(void *data){
	int i;
	if(! data) return;
	struct data *dataCast = (struct data *) data;
	
	for(i = 0; i < dataCast->count; i++){
		if((dataCast->items)[i]){
			(((dataCast->items)[i])->linkCount)--;
			if(((dataCast->items)[i])->linkCount <= 0){
				free((dataCast->items)[i]);
				((dataCast->items)[i]) = NULL;
			}
		}
	}
}

void dataLink(void *data){
	int i;
	if(! data) return;
	struct data *dataCast = (struct data *) data;
	
	for(i = 0; i < dataCast->count; i++){
		if((dataCast->items)[i]){
			(((dataCast->items)[i])->linkCount)++;
		}
	}
}

struct data **createNoResultItem(){
	struct data **returnDataList = (struct data **) 
		malloc(sizeof(struct data *));
	assert(returnDataList);
	
	struct data *returnData = createEmptyData();
	struct dataItem *noItemData = (struct dataItem *) 
		malloc(sizeof(struct dataItem));
	assert(noItemData);
	noItemData->fields = (char **) malloc(sizeof(char *));
	assert(noItemData->fields);
	(noItemData->fields)[0] = NOITEMFOUNDSTRING;
	noItemData->linkCount = 0;
	noItemData->fieldCount = 1;
	
	addDataItem(noItemData, returnData);
	
	*returnDataList = returnData;
	
	return returnDataList;
}

