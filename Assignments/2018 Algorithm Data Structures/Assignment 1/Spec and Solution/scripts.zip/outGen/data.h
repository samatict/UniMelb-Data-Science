/*
	Contains prototypes and definitions for creating and manipulating a data 
	item.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include "querySet.h"

struct dataItem;

/* 
	A collection of data items, contains a single key and one or more data 
	items.
*/
struct data;

/*
	Compares the keys of two data items.
	Returns -1 if left < right, 0 if equal, 1 if left > right
*/
int dataCompare(struct data *left, struct data *right);

/* 
	Creates a data item from the given list of a certain number of values.
	The list should have 14 data fields.
*/
struct dataItem *createDataItem(char **list, int number);

/* 
	Creates an empty data set.
*/
struct data *createEmptyData();

/*
	Creates a data item with only the given key. Duplicates string.
*/
struct data *createKeyOnlyData(char *key);

/* 
	Adds all items in the first given list into the second list. Assumes that
	no shared data is present. The returned list is the second list. If list2 is
	non-NULL, list1 will be freed and list2 will remain at the same address.
*/
struct data *mergeLists(struct data *list1, struct data *list2);

/*
	Adds the items in the first list to the second list without modifying the
	first list.
*/
struct data *nonDestructiveMergeLists(struct data *list1, struct data *list2);

/*
	Prints an item to the specified file with the assignment format.
*/
void printData(struct query *query, void *data, FILE *outfile);

/*
	Adds a single data item to a given data set.
*/
void addDataItem(struct dataItem *item, struct data *dataSet);

/*
	Returns the address of the key stored in the data item given.
*/
char *getDataKey(struct data *data);

/*
	Set the key of the given data set.
*/
void setDataKey(struct data *data, char **fieldList, int fieldCount);

/*
	Unlinks all data item set.
*/
void dataUnlink(void *data);

/*
	Links data item set, marking that an additional reference to it is present
	in the program.
*/
void dataLink(void *data);

/*
	Creates a data item which symbolises that no data items were found in the
	given query.
*/
struct data **createNoResultItem();
