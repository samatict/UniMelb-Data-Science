/*
	Contains implementation details for creating and manipulating a file to
	read csv files into a set of data items and a key.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "dataProg.h"
#include "data.h"

struct dataProg {
	FILE *file;
};

struct dataProg *createDataProg(){
	struct dataProg *returnDataProg = (struct dataProg *) 
		malloc(sizeof(struct dataProg));
	returnDataProg->file = NULL;
	assert(returnDataProg);
	return returnDataProg;
}

void loadDataProg(struct dataProg **dataProg, char *inputFile){
	if (! dataProg || ! inputFile) return;
	if(! *dataProg){
		*dataProg = createDataProg();
	}
	(*dataProg)->file = fopen(inputFile,"r");
	assert((*dataProg)->file);
}

struct data *getNextData(struct dataProg *dataProg){
	char **fieldList = NULL;
	int fieldCount = 0;
	size_t lineSize = 0;
	char *line = NULL;
	int lineProgS = 0;
	int lineProgI;
	int lineProgE;
	int inQuote = 0;
	char *tempString;
	int i;
	int stringSize;
	
	struct dataItem *dataItem = NULL;
	struct data *data = NULL;
	
	void addString(){
		fieldList = (char **) realloc(fieldList, 
			sizeof(char *)*(fieldCount + 1));
		assert(fieldList);
		stringSize = lineProgE - lineProgS + 1;
		tempString = (char *) malloc(sizeof(char)*(stringSize + 1));
		assert(tempString);
		for(i = 0; i < stringSize; i++){
			tempString[i] = line[lineProgS + i];
		}
		tempString[i] = '\0';
		fieldList[fieldCount] = tempString;
		fieldCount++;
		lineProgS = lineProgI;
	}
	
	/* Read line. */
	if(getline(&line, &lineSize, dataProg->file) == -1){
		/* Line finished, cleanup file. */
		fclose(dataProg->file);
		dataProg->file = NULL;
		free(line);
		return NULL;
	}
	
	if(line){
		/* Remove newline at end of line if present. */
		if(line[strlen(line) - 1] == '\n' || line[strlen(line) - 1] == '\r'){
			line[strlen(line) - 1] = '\0';
		}
		/* Remove carriage return at end of line if present. */
		if(line[strlen(line) - 1] == '\n' || line[strlen(line) - 1] == '\r'){
			line[strlen(line) - 1] = '\0';
		}
		/* Split each at comma and store field in field list */
		lineProgI = 0;
		while(line[lineProgI] != '\0'){
			while(!(line[lineProgI] == '\n' || line[lineProgI] == ',' 
				|| line[lineProgI] == '\0' || line[lineProgI] == '"')){
				/* Move through line when no interesting characters present. */
				lineProgI++;
			}
			if(line[lineProgI] == '"'){
				/* Use 1 lookahead */
				if(line[lineProgI + 1] == '"'){
					/* Quote. Jump over both. */
					lineProgI += 2;
				} else {
					/* Start/end quote. Quoted values have no whitespace, so  */
					/* 	we don't need to handle storage either way yet. */
					inQuote = ! inQuote;
					lineProgI++;
				}
			} else if (line[lineProgI] == ','){
				if(inQuote){
					lineProgI++;
				} else {
					lineProgE = lineProgI - 1;
					lineProgI++;
					addString();
				}
			} else if (line[lineProgI] == '\n' || line[lineProgI] == '\0'){
				/* 
					By construction we haven't allowed newlines in columns, so a
					newline which appears is not ignored in either state.
				*/
				lineProgE = lineProgI - 1;
				assert(line[lineProgI] != '\n');
				addString();
			}
		}
		/* Create data item */
		dataItem = createDataItem(fieldList, fieldCount);
		data = createEmptyData();
		/* Add data item. */
		addDataItem(dataItem, data);
		setDataKey(data, fieldList, fieldCount);
	}
	
	free(line);
	
	return data;
}

void freeDataProg(struct dataProg **dataProg){
	if(! *dataProg) return;
	if((*dataProg)->file){
		fclose((*dataProg)->file);
	}
	free(*dataProg);
	*dataProg = NULL;
}
