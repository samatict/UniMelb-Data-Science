/*
	Contains prototypes and definitions for creating and manipulating a file to
	read csv files into a set of data items and a key.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/
#include "data.h"

struct dataProg;

/* Creates an empty object to keep track of progress through a file. */
struct dataProg *createDataProg();

/* Load a file as given so its input can be processed line by line. */
void loadDataProg(struct dataProg **dataProg, char *inputFile);

/* Gets the next data item from the file in the prog data item if there is one 
	to get else returns NULL. */
struct data *getNextData(struct dataProg *dataProg);

/* 
	Free all the internal structures used for reading the file (and close the 
	file if it is open).
*/
void freeDataProg(struct dataProg **dataProg);
