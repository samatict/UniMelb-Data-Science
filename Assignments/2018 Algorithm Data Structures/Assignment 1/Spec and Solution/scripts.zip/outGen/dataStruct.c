struct dataItem {
	char **fields;
	int fieldCount;
	int linkCount;
	int errorQueryLine;
	int totalQueries;
};

struct data {
	struct dataItem **items;
	int count;
	char *key;
};
