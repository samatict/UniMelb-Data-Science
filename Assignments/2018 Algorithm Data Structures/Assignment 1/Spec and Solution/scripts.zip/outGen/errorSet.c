/*
	Contains implementation details for storing a list of errors.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/
#include <stdlib.h>
#include <assert.h>
#include "errorSet.h"
#include "testResultSet.h"
#include "settings.h"

struct errorSet {
	struct error *lexErrors;
	int lexErrorCount;
	struct error *parseErrors;
	int parseErrorCount;
	struct error *comparisonErrors;
	int comparisonErrorCount;
	struct error *wrongFileQueryErrors;
	int wrongFileQueryErrorCount;
	struct error *wrongFileDataErrors;
	int wrongFileDataErrorCount;
	struct error *missingQueryErrors;
	int missingQueryErrorCount;
	struct error *missingDataErrors;
	int missingDataErrorCount;
	struct error *extraErrors;
	int extraErrorCount;
};

struct error {
	void *errorData;
};

/* 
	Add the given error data to the given error array (resizing) and updating 
	the error count.
*/
void addErrorToSet(void *errorData, struct error **errorArray, int *errorCount);

struct errorSet *createErrorSet(){
	struct errorSet *returnErrorSet;
	returnErrorSet = (struct errorSet *) malloc(sizeof(struct errorSet));
	assert(returnErrorSet);
	
	returnErrorSet->lexErrors = NULL;
	returnErrorSet->lexErrorCount = 0;
	returnErrorSet->parseErrors = NULL;
	returnErrorSet->parseErrorCount = 0;
	returnErrorSet->comparisonErrors = NULL;
	returnErrorSet->comparisonErrorCount = 0;
	returnErrorSet->wrongFileQueryErrors = NULL;
	returnErrorSet->wrongFileQueryErrorCount = 0;
	returnErrorSet->wrongFileDataErrors = NULL;
	returnErrorSet->wrongFileDataErrorCount = 0;
	returnErrorSet->missingQueryErrors = NULL;
	returnErrorSet->missingQueryErrorCount = 0;
	returnErrorSet->missingDataErrors = NULL;
	returnErrorSet->missingDataErrorCount = 0;
	returnErrorSet->extraErrors = NULL;
	returnErrorSet->extraErrorCount = 0;
	
	return returnErrorSet;
}

void addErrorToSet(void *errorData, struct error **errorArray, int *errorCount){
	*errorArray = (void *) 
		realloc(*errorArray, (*errorCount + 1)*sizeof(void *));
	assert(*errorArray);
	((*errorArray)[*errorCount]).errorData = errorData;
	*errorCount = *errorCount + 1;
}

void addError(struct errorSet *errorSet, enum errorType errorType, 
	void *errorData){
	switch(errorType){
		case LEXERROR:
			addErrorToSet(errorData, &(errorSet->lexErrors),
				&(errorSet->lexErrorCount));
			break;
		case PARSEERROR:
			addErrorToSet(errorData, &(errorSet->parseErrors),
				&(errorSet->parseErrorCount));
			break;
		case COMPARISONERROR:
			addErrorToSet(errorData, &(errorSet->comparisonErrors),
				&(errorSet->comparisonErrorCount));
			break;
		case WRONGFILEQUERY:
			addErrorToSet(errorData, &(errorSet->wrongFileQueryErrors),
				&(errorSet->wrongFileQueryErrorCount));
			break;
		case WRONGFILEDATA:
			addErrorToSet(errorData, &(errorSet->wrongFileDataErrors),
				&(errorSet->wrongFileDataErrorCount));
			break;
		case MISSINGQUERYERROR:
			addErrorToSet(errorData, &(errorSet->missingQueryErrors),
				&(errorSet->missingQueryErrorCount));
			break;
		case MISSINGDATAERROR:
			addErrorToSet(errorData, &(errorSet->missingDataErrors),
				&(errorSet->missingDataErrorCount));
			break;
		case EXTRAERROR:
			addErrorToSet(errorData, &(errorSet->extraErrors),
				&(errorSet->extraErrorCount));
			break;
	}
}

void printErrors(struct errorSet *errorSet, enum errorType errorType){	
	void printErrorSet(void (*printOneError)(void *), struct error *errorArray,
		int errorCount){
		int i;
		/* Print up to MAXERRORS errors, with a message if any were hidden. */
		for(i = 0; i < MAXERRORS && i < errorCount; i++){
			printOneError((errorArray[i]).errorData);
		}
		if(i < errorCount){
			printf("\tErrors shown %d of %d\n", MAXERRORS, errorCount);
		}
	}
	
	switch(errorType){
		case LEXERROR:
			printErrorSet(&printLexError, errorSet->lexErrors, 
				errorSet->lexErrorCount);
			break;
		case PARSEERROR:
			printErrorSet(&printParseError, errorSet->parseErrors, 
				errorSet->parseErrorCount);
			break;
		case COMPARISONERROR:
			printErrorSet(&printComparisonError, errorSet->comparisonErrors, 
				errorSet->comparisonErrorCount);
			break;
		case WRONGFILEQUERY:
			printErrorSet(&printWrongFileQueryError, 
				errorSet->wrongFileQueryErrors, 
				errorSet->wrongFileQueryErrorCount);
			break;
		case WRONGFILEDATA:
			printErrorSet(&printWrongFileDataError, 
				errorSet->wrongFileDataErrors, 
				errorSet->wrongFileDataErrorCount);
			break;
		case MISSINGQUERYERROR:
			printErrorSet(&printMissingQueryError, errorSet->missingQueryErrors, 
				errorSet->missingQueryErrorCount);
			break;
		case MISSINGDATAERROR:
			printErrorSet(&printMissingDataError, errorSet->missingDataErrors, 
				errorSet->missingDataErrorCount);
			break;
		case EXTRAERROR:
			printErrorSet(&printExtraError, errorSet->extraErrors, 
				errorSet->extraErrorCount);
			break;
	}
}

int errorCount(struct errorSet *errorSet, enum errorType errorType){
	switch(errorType){
		case LEXERROR:
			return errorSet->lexErrorCount;
			break;
		case PARSEERROR:
			return errorSet->parseErrorCount;
			break;
		case COMPARISONERROR:
			return errorSet->comparisonErrorCount;
			break;
		case WRONGFILEQUERY:
			return errorSet->wrongFileQueryErrorCount;
			break;
		case WRONGFILEDATA:
			return errorSet->wrongFileDataErrorCount;
			break;
		case MISSINGQUERYERROR:
			return errorSet->missingQueryErrorCount;
			break;
		case MISSINGDATAERROR:
			return errorSet->missingDataErrorCount;
			break;
		case EXTRAERROR:
			return errorSet->extraErrorCount;
			break;
	}
	return 0;
}

