/*
	Contains prototypes and definitions for storing a list of errors.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

struct errorSet;

struct error;

/* A set of error types, used to group errors. */
#ifndef ERRORTYPEENUM
#define ERRORTYPEENUM
enum errorType {
	LEXERROR,
	PARSEERROR,
	COMPARISONERROR,
	WRONGFILEQUERY,
	WRONGFILEDATA,
	MISSINGQUERYERROR,
	MISSINGDATAERROR,
	EXTRAERROR
};
#endif

/* Creates an empty errors set. */
struct errorSet *createErrorSet();

/* Add an error to the given error set. */
void addError(struct errorSet *errorSet, enum errorType errorType, 
	void *errorData);
	
/* Print the list of all errors of the given type. */
void printErrors(struct errorSet *errorSet, enum errorType errorType);

/* Return the count of errors of the given type. */
int errorCount(struct errorSet *errorSet, enum errorType errorType);
