/* 
	Test program for COMP20003 Assignment 1 2018. Builds BST from CSV file and
	prints the expected results. Also utilises this to check results.
	
	Written by Grady Fitzpatrick (Staff: 110067, Student: 575753)
	
	Run using: 
		outGen infile outfile operationMode [extraInfo] [stage] < keyfile
	
	where 
		infile is the input file to be processed.
		outfile is the file to output to (or in extra mode e the output of the
			program to be tested).
		operationMode is one of [abcde]
		where
			In mode 'a', output is given for the tree where equality is 
				clustered with less than (overwrites outfile).
			In mode 'b', output is given for the tree where equality is
				clustered with greater than (overwrites outfile).
			in mode 'c', stdin is ignored and the infile is written to the 
				outfile (overwrite) with an additional carriage return before
				every new line.
			in mode 'd', the input file is written exactly as given, but a 
				single new line is also added to the end of the file.
			in mode 'e', the input given is matched against the output expected,
				the extraInfo argument is used as the checked stdout.
		stage is one of [12]
		where
			in stage '1', output is run against trees with greater than / less
				than paired with equality, this is the default behaviour.
			in stage '2', output is run against a tree with an additional branch
				for equality.
	
	CHECK mode:
		In check mode, results are matched by the result set order of the input
		to check presence. LE or ME tree status is checked, if both comparisons
		are equal, "both" is printed, otherwise the set which is closest to
		correct is printed.
		
		If errors occur in matching: 
			"missing" is printed if a data item in the LE tree is missing from
			the given data and no other errors are present. A description of the
			issue, a count of missing records and each missing record are 
			printed.
			
			"extra" is printed if all the data in the LE tree is present in the
			given data, but additional unmatched data is also present in the
			given data.
			
			"count" is printed if all data matches but the counts are off and
			no other errors are present. A note about the error as well as the
			differences between the tree types is printed.
			
			"me" is printed if both missing and extra issues are present, this
			is likely to occur on the space handling test if students have 
			failed to handle this correctly.
			
			"mc" is printed instead of "mec" if only missing and count issues
			are present, this is generally a genuine error.
			
			"ec" is printed if extra fields are present and the count is 
			incorrect.
			
			"mec" is printed instead of "me" if the counting issue is also 
			present, this is likely to occur in the same cases as "me".
			
			"me", "mc", "ec" and "mec" all print the additional diagnostic data
			about the nature of the issues found.
*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "bst.h"
#include "data.h"
#include "dataProg.h"
#include "testResultSet.h"
#include "resultSet.h"
#include "querySet.h"
#include "checkResult.h"

#define INFILEARG 1
#define OUTFILEARG 2
#define OPMODEARG 3
#define OPMODEEXTRAARG 4
#define STAGEARGNEXTRA 4
#define STAGEARGEXTRA 5

enum modes {
	LETREE,
	METREE,
	CRLFIN,
	EXTRANEWLINE,
	CHECK
};

/* Compares left and right strings given. */
int leCompare(void *left, void *right){
	return dataCompare((struct data *) left, (struct data *) right);
}

/* 
	Reverses order of leCompare, causing equal items to cluster on with greater 
	than items. This causes the tree to sort in reverse alphabetical order but
	the meaning of left and right in practical terms is arbitrary, so this is
	fine.
*/
int meCompare(void *left, void *right){
	return dataCompare((struct data *) right, (struct data *) left);
}

void *createEmptyDataV(void *item){
	struct data *emptyData = createEmptyData();
	char *key = getDataKey((struct data *) item);
	setDataKey(emptyData, &key - 1, 2);
	return (void *) emptyData;
};

void *mergeListsV(void *a, void *b){
	return (void *) mergeLists((struct data *) a, (struct data *) b);
};

void *noResultItem(){
	return (void *) createNoResultItem();
};

int main(int argc, char **argv){
	struct bst *leTree = NULL;
	struct bst *meTree = NULL;
	struct data *nextData = NULL;
	struct dataProg *dataProg = NULL;
	struct resultSet *leResults = NULL;
	struct resultSet *meResults = NULL;
	struct testResultSet *testingResults = NULL;
	struct querySet *searchQueries = NULL;
	struct checkResult *checkResult = NULL;
	
	char *line = NULL;
	size_t size = 0;
	enum modes mode = LETREE;
	enum treeType type = LTETREE;
	
	FILE *inFile;
	FILE *outFile;
	
	if(argc < 4){
		fprintf(stderr,"Received %d arguments, run in the form:\n\n",argc);
		fprintf(stderr,
			"outGen infile outfile operationMode [extraInfo] [stage] < keyfile"
			"\n\n");
		fprintf(stderr,"Where operationMode is one of the following:\n");
		fprintf(stderr,"a - output expected for <= > trees\n");
		fprintf(stderr,"b - output expected for < => trees\n");
		fprintf(stderr,"c - output given infile with CRLF line endings to\n");
		fprintf(stderr,"\tgiven outfile. (stdin ignored)\n");
		fprintf(stderr,"d - output given infile with additional line at\n");
		fprintf(stderr,"\tend of file to given outfile. (stdin ignored)\n");
		fprintf(stderr,"e - check outputfile contains all required fields\n");
		fprintf(stderr,"\tand that extraInfo file contains all required\n");
		fprintf(stderr,"\tcomparisons.\n");
		exit(1);
	}
	
	switch(argv[OPMODEARG][0]){
		case 'a':
			mode = LETREE;
			break;
		
		case 'b':
			mode = METREE;
			break;
		
		case 'c':
			mode = CRLFIN;
			break;
		
		case 'd':
			mode = EXTRANEWLINE;
			break;
		
		case 'e':
			mode = CHECK;
			break;
		
		
		
		default:
			/* Failed to get valid mode. */
			fprintf(stderr, "%d: Failed to get valid operation mode, valid \n",
				__LINE__);
			fprintf(stderr, "\tmodes are a,b,c,d,e.\n");
			exit(1);
			break;
	}
	
	/* Determine stage. */
	switch(mode){
		case LETREE:
		case METREE:
			if(argc > 4){
				switch(argv[STAGEARGNEXTRA][0]){
					case '2':
						type = LGETERNARY;
						break;
					
					case '1':
					default:
						type = LTETREE;
						break;
				}
			} else {
				type = LTETREE;
			}
			break;
		
		case CHECK:
			if(argc > 4){
				switch(argv[STAGEARGEXTRA][0]){
					case '2':
						type = LGETERNARY;
						break;
					
					case '1':
					default:
						type = LTETREE;
						break;
				}
			} else {
				type = LTETREE;
			}
			break;
		
		default:
			type = LTETREE;
			break;
	}
	
	/* Determine what we need to build and build it. */
	switch(mode){
		case CRLFIN:
		case EXTRANEWLINE:
			inFile = fopen(argv[INFILEARG],"r");
			assert(inFile);
			outFile = fopen(argv[OUTFILEARG],"w");
			assert(outFile);
			break;
		
		case CHECK:
			/* Check if we have enough arguments before constructing trees. */
			if(argc < 4){
				fprintf(stderr, 
					"Operation mode CHECK ('e') requires extraInfo\n");
				exit(1);
			}
		case LETREE:
		case METREE:
		/* Create trees. */
		if(mode == LETREE || mode == CHECK){
			leTree = createBST(&leCompare, &dataUnlink, &dataLink, 
				&createEmptyDataV, &mergeListsV, &noResultItem, type);
		}
		if(mode == METREE || mode == CHECK){
			meTree = createBST(&meCompare, &dataUnlink, &dataLink, 
				&createEmptyDataV, &mergeListsV, &noResultItem, type);
		}
		/* Construct tree from infile. */
		dataProg = createDataProg();
		loadDataProg(&dataProg, argv[INFILEARG]);
		while((nextData = getNextData(dataProg))){
			if(mode == LETREE || mode == CHECK){
				bstInsert(leTree, nextData);
			}
			if(mode == METREE || mode == CHECK){
				bstInsert(meTree, nextData);
			}
		}
		freeDataProg(&dataProg);
		
		/* Construct query set from stdin. */
		searchQueries = createQuerySet();
		constructQuerySet(&searchQueries, stdin);
		break;
		
		default:
			fprintf(stderr, 
				"%d: Implementation error, unexpected operation mode.\n", 
				__LINE__);
			break;
	}
	
	/* Build result sets if need be. */
	switch(mode){
		case CHECK:
			/* Build both trees' result sets, build source result set. */
			testingResults = createTestResultSet();
			leResults = createResultSet();
			meResults = createResultSet();
			constructResults(testingResults, argv[OPMODEEXTRAARG], 
				argv[OUTFILEARG], searchQueries);
			resetSearchQueries(searchQueries);
			findResults(&leResults, leTree, searchQueries);
			resetSearchQueries(searchQueries);
			findResults(&meResults, meTree, searchQueries);
			break;
		
		case LETREE:
			/* Build LE tree results. */
			leResults = createResultSet();
			findResults(&leResults, leTree, searchQueries);
			break;
		
		case METREE:
			/* Build ME tree results. */
			meResults = createResultSet();
			findResults(&meResults, meTree, searchQueries);
		
		case CRLFIN:
		case EXTRANEWLINE:
		default:
			break;
	}
	
	/* Compare and process data. */
	switch(mode){
		case CRLFIN:
			/* TODO: Refactor this into function. */
			while(getline(&line, &size, inFile) != -1){
				if(line[strlen(line) - 1] == '\n'){
					/* Get one extra character of space. */
					line = (char *) realloc(line, size + sizeof(char));
					size += 1;
					assert(line);
					/* Add extra termination character after old one. */
					line[strlen(line) + 1] = '\0';
					/* Overwrite Line Feed with Carriage Return. */
					line[strlen(line) - 1] = '\r';
					/* Overwrite old termination character with Line Feed. */
					line[strlen(line)] = '\n';
				}
				fprintf(outFile,"%s",line);
			}
			fclose(inFile);
			fclose(outFile);
			
			while(getline(&line, &size, stdin) != -1){
				if(line[strlen(line) - 1] == '\n'){
					/* Get one extra character of space. */
					line = (char *) realloc(line, size + sizeof(char));
					size += 1;
					assert(line);
					/* Add extra termination character after old one. */
					line[strlen(line) + 1] = '\0';
					/* Overwrite Line Feed with Carriage Return. */
					line[strlen(line) - 1] = '\r';
					/* Overwrite old termination character with Line Feed. */
					line[strlen(line)] = '\n';
				}
				fprintf(stdout,"%s",line);
			}
			break;

		case EXTRANEWLINE:
			while(getline(&line, &size, inFile) != -1){
				fprintf(outFile, "%s", line);
			}
			fprintf(outFile, "\n");
			while(getline(&line, &size, stdin) != -1){
				fprintf(stdout, "%s", line);
			}
			fprintf(stdout, "\n");
			fclose(inFile);
			fclose(outFile);
			break;
		
		case LETREE:
			printResults(leResults, argv[OUTFILEARG], &printData);
			break;
		
		case METREE:
			printResults(meResults, argv[OUTFILEARG], &printData);
			break;
		
		case CHECK:
			checkResult = checkResults(leResults, meResults, testingResults);
			printCheckResult(checkResult);
	}
	
	/* Clean up any memory. */
	if(checkResult){
		freeCheckResult(&checkResult);
	}
	if(testingResults){
		freeTestingResults(&testingResults);
	}
	if(leResults){
		freeResultSet(&leResults);
	}
	if(meResults){
		freeResultSet(&meResults);
	}
	if(leTree){
		/*freeTree(&leTree);*/
	}
	if(meTree){
		/*freeTree(&meTree);*/
	}
	if(searchQueries){
		freeQuerySet(&searchQueries);
	}
	if(line){
		free(line);
	}
	return 0;
}
