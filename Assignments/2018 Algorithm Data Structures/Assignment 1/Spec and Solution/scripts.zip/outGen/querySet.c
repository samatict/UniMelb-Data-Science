/*
	Contains implementation details for creating and using a set of queries.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "querySet.h"
#include "data.h"

#define DEFAULTQUERYCOUNT 8

struct query {
	struct data *data;
};

struct querySet {
	struct query *queries;
	int queryCount;
	int allocated;
	int progress;
};

struct querySet *createQuerySet(){
	struct querySet *returnSet = (struct querySet *) 
		malloc(sizeof(struct querySet));
	returnSet->queries = NULL;
	returnSet->queryCount = 0;
	returnSet->allocated = 0;
	returnSet->progress = 0;
	return returnSet;
}

void constructQuerySet(struct querySet **querySet, FILE *queryfile){
	if(!queryfile || !querySet) return;
	if(!*querySet){
		*querySet = createQuerySet();
	}
	size_t lineSize;
	char *line = NULL;
	while(getline(&line, &lineSize, queryfile) != -1){
		if(strlen(line) <= 0){
			continue;
		}
		if(line[strlen(line) - 1] == '\n'){
			line[strlen(line) - 1] = '\0';
		}
		/* Insert line into query set. */
		/* Ensure we've got space. */
		if(! (*querySet)->queries){
			(*querySet)->queries = (struct query *) 
				malloc(sizeof(struct query)*DEFAULTQUERYCOUNT);
			assert((*querySet)->queries);
			(*querySet)->allocated = DEFAULTQUERYCOUNT;
		} else if((*querySet)->queryCount + 1 > (*querySet)->allocated) {
			(*querySet)->allocated *= 2;
			(*querySet)->queries = (struct query *) 
				realloc((*querySet)->queries, 
					sizeof(struct query)*(*querySet)->allocated);
			assert((*querySet)->queries);
		}
		(((*querySet)->queries)[(*querySet)->queryCount]).data = 
			createKeyOnlyData(line);
		(*querySet)->queryCount = (*querySet)->queryCount + 1;
	}
	if(line){
		free(line);
	}
}

struct query *nextQuery(struct querySet *querySet){
	if(! querySet) return NULL;
	if(querySet->progress < querySet->queryCount){
		querySet->progress++;
		return &(querySet->queries[querySet->progress - 1]);
	} else {
		return NULL;
	}
}

void resetSearchQueries(struct querySet *querySet){
	if(querySet){
		querySet->progress = 0;
	}
}

void *getQueryData(struct query *query){
	return (void *) (query->data);
}

void freeQuerySet(struct querySet **querySet){
	int i;
	if(!querySet || !*querySet) return;
	for(i = 0; i < (*querySet)->queryCount; i++){
		dataUnlink(((*querySet)->queries)[i].data);
	}
	free((*querySet)->queries);
	free(*querySet);
	
	return;
}

char *getKey(struct query *query){
	return getDataKey(query->data);
}

