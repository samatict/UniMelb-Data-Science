/*
	Contains prototypes and definitions for creating and using a set of queries.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include <stdio.h>

struct querySet;

struct query;

/* 
	Create an empty set of queries and return it.
*/
struct querySet *createQuerySet();

/*
	Read each line of the given file as a query and store it in the given 
		querySet.
*/
void constructQuerySet(struct querySet **querySet, FILE *queryfile);

/*
	Get the next query from the query set.
*/
struct query *nextQuery(struct querySet *querySet);

/*
	Reset the progress through the query set.
*/
void resetSearchQueries(struct querySet *querySet);

/*
	Return the key pair from the given query.
*/
void *getQueryData(struct query *query);

/*
	Free all space allocated by query set.
*/
void freeQuerySet(struct querySet **querySet);

/*
	Retrieves the key from a given query.
*/
char *getKey(struct query *query);

