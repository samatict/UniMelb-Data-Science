/*
	Contains implementation details for running a batch of searches on a 
	bst.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include "resultSet.h"
#include "querySet.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

#define DEFAULTRESULTSIZE 8

#include "resultSetStruct.c"

struct resultSet *createResultSet(){
	struct resultSet *returnStruct = (struct resultSet *) 
		malloc(sizeof(struct resultSet));
	assert(returnStruct);
	returnStruct->results = NULL;
	returnStruct->used = 0;
	returnStruct->alloced = 0;
	return returnStruct;
}

struct resultSet *addResult(struct resultSet *resultSet, struct result *result){
	if(! resultSet) return resultSet;
	if(! resultSet->results){
		resultSet->results = (struct result **) 
			malloc(sizeof(struct result *)*DEFAULTRESULTSIZE);
		assert(resultSet->results);
		resultSet->alloced = DEFAULTRESULTSIZE;
	} else if(resultSet->used + 1 > resultSet->alloced){
		resultSet->alloced *= 2;
		resultSet->results = (struct result **) realloc(resultSet->results, 
			sizeof(struct result *)*resultSet->alloced);
		assert(resultSet->results);
	}
	resultSet->results[resultSet->used] = result;
	resultSet->used++;
	return resultSet;
}

void findResults(struct resultSet **resultSet, struct bst *tree, 
	struct querySet *querySet){
	struct query *query;
	
	if(!resultSet) return;
	if(!*resultSet){
		*resultSet = createResultSet();
	}
	
	while((query = nextQuery(querySet))){
		queryTree(tree, query, *resultSet);
	}
}

void freeResultSet(struct resultSet **resultSet){
	int i;
	if(!resultSet || ! *resultSet) return;
	if((*resultSet)->results){
		for(i = 0; i < (*resultSet)->used; i++){
			free(((*resultSet)->results)[i]);
		}
		free((*resultSet)->results);
	}
	free(*resultSet);
	*resultSet = NULL;
}

void printResults(struct resultSet *resultSet, char *outfile, 
	void (*printData)(struct query *, void *, FILE *)){
	int i, j;
	
	FILE *outputfp = fopen(outfile, "w");
	assert(outputfp);
	
	struct result *currentResult;
	
	for(i = 0; i < resultSet->used; i++){
		currentResult = (resultSet->results)[i];
		printf("%s --> %d\n", getKey(currentResult->query), 
			currentResult->comparisons);
		for(j = 0; j < currentResult->returnCount; j++){
			printData(currentResult->query, (currentResult->returnedData)[j],outputfp);
		}
	}
	
	fclose(outputfp);
}

