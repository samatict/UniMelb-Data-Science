/*
	Contains prototypes and definitions for running a batch of searches on a 
	bst.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include <stdio.h>

struct resultSet;

#ifndef BST
#define BST
#include "bst.h"
#endif
#include "querySet.h"


#ifndef RESULTTYPE
#define RESULTTYPE
enum resultType {
	PRECOMPUTED,
	FRESH
};
#endif

/*
	NOTE: I didn't quite get to this level. Splitting out the parsed tokens into
		comparable results would be very very good for decoupling what is 
		currently very tightly coupled, but decoupling takes time, so I haven't
		done it as of yet.
	comparisons should be the number of comparisons made in searching the query.
	query should be the query used to find the set of results.
	returnedData should be the list of data returned.
	returnCount should be the number of records returned.
	resultType should be PRECOMPUTED if the results come from a tested program's
		output and FRESH if not.
	if resultType is PRECOMPUTED,
		sourceFileStdin should be the name of the file standard input was taken
			from,
		sourceFileOutfile should be the name of the file standard output was 
			taken from,
		sourceLineStdin should be the line on which the query was found,
			TODO: Consider pulling this from the data list itself or dropping 
			entirely.
		sourceLineOutfile should be the line on which the result was found,
		sourceColOutfile should be the column in which the data items begin.
			TODO: Consider pulling this from the data list itself or dropping 
			entirely.
*/
#ifndef RESULTSTRUCT
#define RESULTSTRUCT
struct result {
	int comparisons;
	struct query *query;
	void **returnedData;
	int returnCount;
	enum resultType type;
	char *sourceFileStdin;
	char *sourceFileOutfile;
	int sourceLineStdin;
	int sourceLineOutfile;
	int sourceColOutfile;
};
#endif

/* Creates an empty result set to be added to. */
struct resultSet *createResultSet();

/* Adds a result to a given result set. */
struct resultSet *addResult(struct resultSet *resultSet, struct result *result);

/* 
	Searches all the queries given on the given tree and add them to the given
	result set. 
*/
void findResults(struct resultSet **resultSet, struct bst *tree, 
	struct querySet *querySet);

/* Frees any data result set is responsible for and result set itself. */
void freeResultSet(struct resultSet **resultSet);

/* 
	Print a set of results by running each data item through the given 
	function. And printing the expected data as per the specification to stdout.
	PrintData function should take the query and the file pointer to output to.
*/
void printResults(struct resultSet *resultSet, char *outfile, 
	void (*printData)(struct query *, void *, FILE *));
