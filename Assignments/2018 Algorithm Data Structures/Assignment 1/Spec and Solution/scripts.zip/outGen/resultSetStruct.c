struct resultSet{
	struct result **results;
	int used;
	int alloced;
};
