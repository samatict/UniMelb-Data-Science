/* 
	The maximum number of records which will be read from the results files 
	provided, this is to deal with broken programs which print too much input.
	
	NOT IMPLEMENTED.
*/
#define MAXTOKENS 20000

/*
	The maximum number of errors to print per section. All additional errors 
	will be turned into a summary count instead.
*/
#define MAXERRORS 5

/*
	The prefix for all error printed lines.
*/
#define ERRORLINEPREFIX "\t\t"
