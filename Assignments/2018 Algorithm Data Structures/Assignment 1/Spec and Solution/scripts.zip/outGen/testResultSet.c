/*
	Contains implementation details for creating and manipulating a pair of
	input and output files.
	
	Input is lexed and parsed and compiled into a test results object.

NNNNNNNNNNNNNNNMNNNNNNMNMMMMMMMMNMMMMNNMMMMMMMMMMNMNNNNNNMMMMMMMMMMMMMMMMMMMMMMM
NNNNNNNNNNNNNNNMNNNNNNMMMMNNNNNNNNNNNNMNNNNNNNMMMNMNNNNNNMMMMMMMMMMMMMMMMMMMMMMM
NNNNNNNNNNNNNNNMNNNNNMMNNNNNNNNNmNmmmmNNmmmNNNNNNNMNNNNNNMMMMMMMMMMMMMMMMMMMMMMM
NNNNNNNNNNNNNNNMNMNMNNNNNNNNNNmmmdmmmmmmmmdmNNNNNNNNMNNNMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNMNMMMMNNNNNNNNNNNNNNNNNNNN
MMMMMMMMMMMMMNmMMMNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNMMNMMmMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMydNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNMMNNmoMMMMMMMMMMMMMMNNNNN
MMMMMMMMMMMMM-hMMNNNNNmmNNNmmmNNNNNNNNNNNNNNNmmNNNmNNNNMMMN/:MMMMMMMMMMNMNMNNNNN
MMMMMMMMMMMMM.:dNNNNNdmmmmmmmmmmmmmmmmmmmNNmmmmmmmmdNNNNmh/ oMMMMMMMMNMNMNMNNNNN
MMMMMMMMMMMMM+`/oydmmmdmmmmmmmmmmmmmmmmmmmmmmmmmmmmhdo/::. .NMMMMMMMMNMNMNMNNNNN
MMMMMMMMMMMMMm.`...-:hhdmmmmmmmmmmmdmmmmmmmmmNmmdmdyy/`` `:mMMNMMMMMMNMNMNMNNNNN
NNNNNNNNNNMMMNd/`   +yyydmmmmmNmmmdhmmdmmmmNNNmmdmdyys.-+hmNNMNMMMMMMNMNMNMNNNNN
NNNNNNNNNNNNNmmmho:-yyyyddmmmdyNNNmmmmmmmmmNNydmmdyyyhdmNNmmmNNdyso++oshmNMNNNNN
NNNNNNNNNNNmmmmmmmNmyyyyyhddh/+NNNNNNNNNNNNNN+:dhyyyyyNmmmmmdo/------:://+hNNNNN
MMMMMMMMMMNNmmmmmNNhyyyyyyyo..+dNNNNNNNNNNNNNy-:yyyyyydNmmms:-...-:+ydmmmdyyNMMM
MMMMMMMMMMMMNNNmNNmhyyyyyyo::-.-oNNNNNNNNNNm/.``oyyyyyyNNd/...`.-:yNNMNMMNMNNNMM
MMMMMMMMMMMMNNNNNNmdhhhhyhhsymdo:+NNNNNNNNNs/oyshhhhhhhNd-.````-:hMMMMNMMNMMMMMM
MMMMMMMMMMMMMNNNNNNddddhhdy +NNdd:oNNNNNNNdhNmN.ymddddmN:``` `.-hMMMMMMNMNMMMMMM
MMNNNNNNNNNMMNNNNNNmhdddds+//dh:y `+NNNNmh-+hoy`odddmmN+.`````.+MMMMMMMMMNMMMMMM
MMNNNNNNNNNNNNNMNNNNyyhhdy`.---.`   /oo:-` `.---:mNNNNy.``  ``-hMMMMMMMMMMMMMMMM
MMNNNNNMMMysyyhdmNNNNdo+sy:```        ``      ``-NNNMN:.`   `.-NMMMMMMMMMMMMMMMM
MMNNNmdddmssyhmNdhNMMNNNNdo/s-..`      `      `-ymNNMm.``   ``:MMMMMMMMMMMMMMMMM
NmdhyyhhhddmNNNNNNNNNmmmmmddddddyo--`.``   `.:smNNNNNy--``.`//.NMNMMMMMMMMMMMMMM
NmmNMMNmydNmmmmmmNNNmmmmmmmdddddddddhyss+/oymNNNNNNNNmdNhydhmdsmNNMMMMMMMMMMMMMM
NMNMMNhymNNNNNNNNNNNNNNmNmmmmmmmddddddddddmmmmmNNNNNNNmmmddddddddNMMMMMMMMMMMMMM
MMNNNhdNNNNNNNNNNNNNNNNNhsyyyyyyhmmmmmmmmmmmmmmNNNNNNNmmmmmddddddNMMMMMMMMMMMMMM
MMNNmNMMNNNNNNNNMMNNNNmyo+-------:+sydmmNNmmNNNmmNMNNNNNmmmmmmmmmMMMMMMMMMMMMMMM
NNNNNMMMMNNNMMNNMMNNNyoo/------------+oomNNNNNNy+hNMNNNNNNNNNNNNNMMMMMMMMMMMMMMM
NNNNNMNNNNNMMNNNMMMMMh+-------------/:/+ymNNNNmh/:dMMMNNyo++sdNNMMMMMMMMMMMMMMMM
MMMMMMNNNNNMMNNMMNNNdy--------------/oooodmNNmdddy/NNNNNyo+osNMNNNNNNNNNNNNNNNNN
MMMMMMNNNNNMMNMMNhs++//:----------:--/:-dNNNNmmmmNdhNNMMMNmmNMMMMMMMMMMMMMMMMMMM
MMMMMMMNNNMMMNNy++///::---------://+/--yNNNNNNNNNNmyNNNMMmhhmMMMMMMMMMMMMMMMMMMM
NNNNNNNNNNNNmy++///::----------:+oo+/+:--:/+osmNNmmmmNNMNhyyhmMMMMMMMMMMMMMMMMMM
NNNNNNNNNNNNmso+///::--------/:-:/+/-.`  `.` `/NNNNmmhsyy:oo//NNNNNNNNNNNNNNNNNN
NNNNNNNNNNNNNmhysos+oo/--++shmh:-.`````-``/  `.hNNNNho...sss+:NMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMNdhysoyNmhmmmmmmmhy+--:.o+.--.`.o+NmNNmdhsoyo+hdMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMNmhdNNNNmmdddddNmoshmh+ss+sy+hymmMNNNNMMNsohMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMNNNmNNNNNNmymymhyyssshddhyssyhddyhNMNNNNMMMsohMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMNNNNNNNNmmm+.:.hyysssossssyyyyyssssyNNNNMMMMyshNMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMNNMMMMMMMMNh+   +yssssyssssssssssssssdMMMMMMMhyhNMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMNNMMMMMMNmhy````:+ooyyooooosysssssyssdNMMMMMmddNMMMMMMMMMMMMMMMMMM
NNNNNNNNNNNNNNNNNNMMMMNNNmo````:sodsoossssdsssssyyydNMMMMMNmmNMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMNNNNNMNMNNNMd:---:/+oo+oyysshyyyssooyMMMNMMh/-:/mMMNNNNNNNNNNNNNNN
MMMMMMMMMMMMMMNmmmmmNNMMNMd+/:-. ```.+NNh---:---.-yMNNNNNmdhhdmNNNNNNNNNNNNNNNNN
MMMMMMMMMMMMMMMmmmmmmNNMMMmmmdhys+:./NMMNo+///+sydNMMMNNNNmmmmmddmNNNNNNNNNNNNNN
MMMMMMMMMMMMMMMMNNNNNNNNMNmmddddmmmdNMMMMMNNNNNNNNNMMNNNmmmdddddddmNNNNNNNNNNNNN
NNNNNNNNNNNNNNNNNNNNNNNNMNmddddmmmNMMMMMMMNNNNNNNNNMMNNNmmmddddddddmMMMMMMMMMMMM
NNNNNNNNNNNNNNNNNNMMNNNNNNmdddmmmNMMMMMMMMMNNNNNNNNMNNNNNmmmmmmdmmmNMNNNNNNNNNNN
MMMMMMMMMMMMMMMMMMMMMNNMMmmddmmmNMMMMMNNNNNNNNNNNmNMMNNNNNdmNmyhmNNMNNNNNNNNNNNN
MMMMMMMMMMMMMMMMMMMMMMNMNmmmmmNNMMMMMMMMMMMMNNNNNmmMMMMhoo:/+o::+NMNNNNNNNNNNMMM
MMMMMMMMMMMMMMMMMMMMMMMNmdmNNNNMMMMMMMMMMMMMMNNNNNNMMMMd..`````.:NMMMMMMMMMMMMMM
NNNNNNNNNNNNNNNNNNNNNMNmmmmNNMMMMMMMMMMMMMMMMNNNNNNNMMMN:..`  `..yNNNNNNNNNNMMMM
NNNNNNNNNNNNNNNNNNNNNNmmmmNNMMMMMMMMMMMMMMMMMMNmmNNNNNMMs..`` ``./NMMMMMMNNNMMMM
MMMMMMMMMMMMMMMMMMMMMdsdNmmNMMMMMMMMMMMMMMMMMMNmmdmNmNMMN/..````..hMMMMNMNNNMMMM
MMMMMMMMMMMMMMMMMMMMMmyshdmMMMMMMMMMMMMMMMMMMMMNmmmdmMNMMm:...```.:hNMMNMNNNMMNN
MMMMMMMMMMMMMMMMMMMMMmyydmNMMMMMMMMMMNNNNNNNNNNNNmmmmNMNMMm/--.``.--+dNNMNNNNdhN
MMMMMMMMMMMMMMMMMMMMMmyymmMMMMMMMMMMMMMMMMMMMMNhymmmmmNNNMMNh/---...--/osyso+sNN
MMMMMMMMMMMMMMMMMMMMMdyhdmMMMMMMMMMMMMMMMMMMMMMmhmdmmmmdddNMNNy+::-------:/ymNMM
MMMMMMMMMMMMMMMMMMMMMdyyhhNNNNNNNNNNNNMMMMMMMMMMMMNmNNmmmmNNNNMMNdhysssydmNNNNMM
NNNNNNNNNNNNNNNNNNNNNmhhdmmNMMMMMMMMMMMMMMMMMMMMNNMMMNNMNMNNNNMMNMMNNMMNMNNNNNMM
NNNNNNNNNNNNNNNNNNNNNNNmmmNMMMMMMMMMMMMMMMMMMMMMNNMMMNNMNMNNNNMMNMMNNMMNMNNNNNMM
	
	Might be outsourcable to Bison and Flex (or possibly even happy/alex), but 
	this implementation should be able to be customised to handle some less 
	sensible deviations from the specification (I hope).
	
	Lexing & Parsing could be split as they usually are, but I'll probably think
	further on whether this is useful or not, for now I won't split for time's
	sake.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include <stdlib.h>
#include "testResultSet.h"
#include <assert.h>
#include <stdio.h>
#include "resultSet.h"
#include <string.h>
#include <ctype.h>
#include "settings.h"
#include "querySet.h"
/* 
	This can be replaced with .h, but a number of functions will be needed to 
	handle the difference in ability. This coupling is again for time-saving 
	purposes.
*/
#include "dataStruct.c"

#define PRESENT 1
#define NOTPRESENT -1
#define NOFREE -1
#define KEYFIELD 1

struct lexOut;
struct parsedOut;
struct lexToken;
struct parseToken;
enum lexProduction;
enum parseProduction;

struct lexErrorInfo;
struct parseErrorInfo;

enum tokenType {
	TERMINAL,
	NONTERMINAL
};

enum lexProduction {
	QUALIFIER,
	TEXT,
	ARROW,
	NONE
};

enum parseProduction {
	TQUERY,
	QUERY,
	CQUERY,
	FIELD,
	FIELDSET,
	PARSENONE
};

struct lexErrorInfo {
	char *line;
	int lineCol;
	int lineNum;
	char *errorText;
};

struct parseErrorInfo {
	char *errorText;
	struct parseToken *parseToken;
};

/* 
	Lex the given input file and store the given fileName and return the 
	object as a result. Errors are added to the given error set.
	Follows the following rules:
	[A-Za-z0-9]+:+ -> QUALIFIER
	[A-Za-z0-9]+   -> TEXT
	[->]+          -> ARROW
	[ \|\n,\"\r]+  -> _
	_              -> error(parse)
	
	Token origin is stored with each token.
*/
struct lexOut *resultLex(FILE *file, char *fileName, struct errorSet *errorSet);

/*
	Parse the given lexed output and copy across the given source file name.
	Parse errors are entered into the given error set.
	Follows the following rules:
	QUERY FIELDSET [CQUERY FIELDSET]  -> TQUERY
	[TEXT] ARROW                      -> QUERY
	QUALIFIER [TEXT]                  -> FIELD
	TEXT                              -> FIELD
	[FIELD]                           -> FIELDSET
	
	-- Extra Linguistic rule: if an arrow appears alone on a new line with no 
	proceeding TEXT, it is converted to a CQUERY, representing a continued query
	this could be formally codified by treating a new line as a special 
	whitespace token, but this check is simpler for the time being.
	
	-- Extra Linguistic rule: to allow for multi-word query strings, query arrow
	text is always parsed from the start of a new line. This unfortunately 
	requires unbounded lookahead and text metadata (though the latter can be 
	formally codified).
	
	Could be expanded to be a bit more agnostic about token type, but terminal
	and non-terminal phases are currently disjoint, so this isn't an issue.
*/
struct parsedOut *resultParse(struct lexOut *lexedOut, 
	struct errorSet *errorSet);

/* 
	Takes a parsed set of results paired and puts them in the object allocated
	at testingResults;
*/
void buildResults(struct testResultSet **testingResults, 
	struct parsedOut *parsedOut, struct parsedOut *parsedStdOut);

struct testResultSet {
	int resultCount;
	struct result *results;
	struct parsedOut *outfileOutput;
	struct errorSet *outfileParseErrors;
	struct parsedOut *stdOutput;
	struct errorSet *stdOutputParseErrors;
	/* Stores -1s or indices of each item present. */
	int **tQueryMatchesQ;
	int **tQueryMatchesD;
	
	/* Next known free space. Set to -1 if all items have been matched. */
	int jumpLookupQi;
	int jumpLookupQj;
	int jumpLookupDi;
	int jumpLookupDj;
};

struct lexToken {
	char *tokenContents;
	enum lexProduction type;
	int sourceLine;
	int sourceCol;
};

struct lexOut {
	char *sourceFileName;
	struct lexToken **tokens;
	int tokenCount;
};

struct tQueryToken {
	struct queryToken *queryToken;
	struct fieldSetToken *fieldSetToken;
	struct cQueryToken **cQueryTokens;
	struct fieldSetToken **extraResults;
	int extraQueriesCount;
};

struct queryToken {
	struct lexToken **text;
	int textTokenCount;
	struct lexToken *arrow;
};

struct cQueryToken {
	struct lexToken *arrow;
};

struct fieldToken {
	/* Optional */
	struct lexToken *qualifier;
	/* NOTE: these will always be a single token for simplicity's sake. */
	struct lexToken **textTokens;
	int textTokenCount;
};

struct fieldSetToken {
	struct fieldToken **fields;
	int fieldTokenCount;
};

struct parseToken {
	union {
		struct tQueryToken tQueryToken;
		struct queryToken queryToken;
		struct cQueryToken cQueryToken;
		struct fieldToken fieldToken;
		struct fieldSetToken fieldSetToken;
	};
	enum parseProduction type;
};

struct parsedOut {
	char *sourceFileName;
	struct parseToken **tokens;
	int tokenCount;
};

struct comparisonErrorData {
	struct lexToken **query;
	int textCount;
	int expectedComparisons;
	int actualComparisons;
};

/* 
	Returns 0 if data fields in data item match words in field set token.
	Fields in field set are not tied to any field, but must occur in the
	same order as the data item (this is for my sanity, not because we
	don't have the technology). Returns -1 otherwise.
*/
int compareTokenData(struct fieldSetToken *fst, struct dataItem *data);

/* Allocates space for the relevant token, set everything up and return it. */
struct parseToken *createParseTokenQUERY   (struct lexOut *lexedOut, 
	int startToken, int endToken);
struct parseToken *createParseTokenFIELD   (struct lexOut *lexedOut, 
	int startToken, int endToken);
struct parseToken *createParseTokenCQUERY  (struct lexOut *lexedOut, 
	int startToken, int endToken);

/* 
	Allocates space for a new field token and copies over the values in the 
	fields of the given token.
*/
struct fieldToken *duplicateFieldToken(struct fieldToken *fieldToken);

/* 
	Allocates space for a new query token and copies over the values in the 
	fields of the given token.
*/
struct queryToken *duplicateQueryToken(struct queryToken *queryToken);
/* 
	Allocates space for a new continued query token and copies over the values 
	in the fields of the given token.
*/
struct cQueryToken *duplicateCQueryToken(struct cQueryToken *cQueryToken);
/* 
	Allocates space for a new field set token and copies over the values in the 
	fields of the given token.
*/
struct fieldSetToken *duplicateFieldSet(struct fieldSetToken *fieldSetToken);

/* Allocates space for the relevant token, set everything up and return it. */
struct parseToken *reduceParseTokenFIELDSET(struct parsedOut *parsedOut, 
	int startToken, int endToken);
struct parseToken *reduceParseTokenTQUERY  (struct parsedOut *parsedOut, 
	int startToken, int endToken);

/* Create a lexed token of the given prod type, with the token string as 
	parameter, and store start column and line as metadata. */
struct lexToken *constructLexToken(char *tokenString, enum lexProduction prod, 
	int startCol, int line);

/* Print a single Field Set Token. Prepends with record statistics. */
void printFSToken(struct fieldSetToken *fsToken);

struct lexToken *constructLexToken(char *tokenString, enum lexProduction prod, 
	int startCol, int line){
	struct lexToken *returnToken = (struct lexToken *) 
		malloc(sizeof(struct lexToken));
	assert(returnToken);
	
	returnToken->tokenContents = tokenString;
	returnToken->type = prod;
	returnToken->sourceLine = line;
	returnToken->sourceCol = startCol;
	
	return returnToken;
}

struct lexOut *resultLex(FILE *file, char *fileName, struct errorSet *errorSet){
	struct lexOut *returnLexOut;
	
	size_t lineSize = 0;
	char *line = NULL;
	/* Used to limit string allocation in heavy erroring case. */
	char *lastLineCopy = NULL;
	
	/* File progress for token identification. */
	int lineProgress;
	int startLineProgress;
	int lineCount = 0;
	
	enum lexProduction status = NONE;
	
	returnLexOut = (struct lexOut *) malloc(sizeof(struct lexOut));
	assert(returnLexOut);
	returnLexOut->sourceFileName = fileName;
	returnLexOut->tokens = NULL;
	returnLexOut->tokenCount = 0;
	
	void error(char *line, int lineProgress, int lineCount, char *errorT){
		if(! lastLineCopy || strcmp(lastLineCopy, line) != 0){
			lastLineCopy = strdup(line);
		}
		struct lexErrorInfo *lei;
		lei = (struct lexErrorInfo *) malloc(sizeof(struct lexErrorInfo));
		assert(lei);
		lei->line      = lastLineCopy;
		lei->lineCol   = lineProgress;
		lei->lineNum   =    lineCount;
		lei->errorText =       errorT;
		addError(errorSet, LEXERROR, (void *) lei);
	}
	
	void convert(enum lexProduction prod){
		char *tokenString;
		/* lineProgress always looking at next character in input. */
		int length = lineProgress - startLineProgress;
		tokenString = (char *) malloc(sizeof(char) * (length + 1));
		assert(tokenString);
		int i;
		for(i = 0; i < length; i++){
			tokenString[i] = line[i + startLineProgress];
		}
		tokenString[i] = '\0';
		
		returnLexOut->tokens = (struct lexToken **) 
			realloc(returnLexOut->tokens, 
				sizeof(struct lexToken *)*(returnLexOut->tokenCount + 1));
		assert(returnLexOut->tokens);
		
		(returnLexOut->tokens)[returnLexOut->tokenCount] = 
			constructLexToken(tokenString, prod, startLineProgress, lineCount);
		(returnLexOut->tokenCount)++;
	}
	
	while(getline(&line, &lineSize, file) != -1){
		/* Update line statistics. */
		lineProgress = 0;
		startLineProgress = lineProgress;
		lineCount++;
		
		for(lineProgress = 0; lineProgress < (strlen(line) + 1); 
			lineProgress++){
			if(line[lineProgress] == ' ' || line[lineProgress] == '\n' 
				|| line[lineProgress] == ',' || line[lineProgress] == '|' 
				|| line[lineProgress] == '"' || line[lineProgress] == '\0' 
				|| line[lineProgress] == '\r'){
				/* 
					In FOLLOW set for all tokens. Blank production begins 
					producing nothing. 
				*/
				if(status == TEXT){
					/* TEXT without following ':', commit to TEXT conversion. */
					convert(TEXT);
				} else if(status == ARROW){
					/* 
						ARROW with following whitespace (or end of string),
						commit to ARROW.
					*/
					convert(ARROW);
				} else if(status == QUALIFIER){
					/* 
						QUALIFIER without following text, commit to QUALIFIER.
					*/
					convert(QUALIFIER);
				}
				/* No productions begin with "whitespace". */
				status = NONE;
				/* Start line progress on next character. */
				startLineProgress = lineProgress + 1;
			} else if(isalnum(line[lineProgress])){
				if(status == QUALIFIER){
					/* Accept no-white space split too. */
					convert(QUALIFIER);
				} else if(status == NONE){
					startLineProgress = lineProgress;
					status = TEXT;
				} else if(status == ARROW){
					/* Commit to arrow. */
					convert(ARROW);
					startLineProgress = lineProgress;
					status = TEXT;
				} else {
					/* (status == TEXT) */
					/* Keep going.      */
				}
			} else if(line[lineProgress] == ':'){
				if(status == ARROW || status == NONE){
					error(line, lineProgress, lineCount, 
						"LEX: Encountered lone ':' without preceding TEXT \n"
						"\t\ttoken, should have either dropped this character \n"
						"\t\tfrom output or something else is wrong.\n");
				} else if(status == TEXT || status == QUALIFIER){
					status = QUALIFIER;
				}
			} else if(line[lineProgress] == '-' || line[lineProgress] == '>'){
				if(status == ARROW){
					/* Keep going. */
				} else if(status == QUALIFIER){
					/* 
						Assumed case: Multi-record return. Commit to 
						qualifier and begin arrow.
					*/
					convert(QUALIFIER);
					status = ARROW;
					startLineProgress = lineProgress;
				} else if(status == TEXT){
					/* Commit to text and begin arrow. */
					convert(TEXT);
					status = ARROW;
					startLineProgress = lineProgress;
				} else if(status == NONE) {
					/* Arrow after whitespace. */
					status = ARROW;
					startLineProgress = lineProgress;
				}
			} else {
				switch(status){
					case QUALIFIER:
						error(line, lineProgress, lineCount, 
							"LEX: Encountered unexpected character, was \n"
							"\t\tconstructing qualifier token, expected \n"
							"\t\t':' or next text string to begin, or   \n"
							"\t\tsomething else is wrong.\n"
							"\t\tConverting token and ignoring character.\n");
						convert(QUALIFIER);
						status = NONE;
						/* Start line progress on next character. */
						startLineProgress = lineProgress + 1;
						break;
					
					case TEXT:
						error(line, lineProgress, lineCount, 
							"LEX: Encountered unexpected character, was \n"
							"\t\tconstructing text token, expected preceeding\n"
							"\t\ttext to continue or a ':', or arrow to being\n"
							"\t\tusing - or >, or something else is wrong.\n"
							"\t\tignoring character and converting.\n");
						convert(TEXT);
						status = NONE;
						/* Start line progress on next character. */
						startLineProgress = lineProgress + 1;
						break;
					
					case ARROW:
						error(line, lineProgress, lineCount, 
							"LEX: Encountered unexpected character, was \n"
							"\t\tconstructing arrow token, expected \n"
							"\t\tarrow to continue, a space or a text token \n"
							"\t\t to begin, or something else is wrong.\n"
							"\t\tConverting prior token.\n");
						convert(ARROW);
						status = NONE;
						/* Start line progress on next character. */
						startLineProgress = lineProgress + 1;
						break;
						
					case NONE:
					default:
						error(line, lineProgress, lineCount, 
							"LEX: Encountered unhandled character.\n");
						/* Start line progress on next character. */
						startLineProgress = lineProgress + 1;
						break;
				}
			}
		}
	}
	
	if(line){
		free(line);
	}
	
	return returnLexOut;
};

struct parseToken *createParseTokenQUERY(struct lexOut *lexedOut, 
	int startToken, int endToken){
	int i;
	struct parseToken *returnToken;
	returnToken = (struct parseToken *) malloc(sizeof(struct parseToken));
	assert(returnToken);
	returnToken->type = QUERY;
	
	/* Text token count is endToken - startToken + 1 - 1 */
	returnToken->queryToken.textTokenCount = (endToken - startToken);
	returnToken->queryToken.text = (struct lexToken **) 
		malloc(sizeof(struct lexToken *) * 
			returnToken->queryToken.textTokenCount);
	assert(returnToken->queryToken.text);
	
	for(i = startToken; i <= (endToken - 1); i++){  
		(returnToken->queryToken.text)[i - startToken] = 
			(lexedOut->tokens)[i];
	}
	
	/* Arrow is last item. */
	returnToken->queryToken.arrow = (lexedOut->tokens)[endToken];
	
	return returnToken;
}

struct parseToken *createParseTokenFIELD(struct lexOut *lexedOut, 
	int startToken, int endToken){
	int i;
	struct parseToken *returnToken;
	returnToken = (struct parseToken *) malloc(sizeof(struct parseToken));
	assert(returnToken);
	returnToken->type = FIELD;
	
	if(((lexedOut->tokens)[startToken])->type == QUALIFIER){
		returnToken->fieldToken.qualifier = (lexedOut->tokens)[startToken];
		/* Push start token forward one for ease of work later. */
		startToken += 1;
	} else {
		returnToken->fieldToken.qualifier = NULL;
	}
	
	/* Allocate space, qualifier handled earlier by modifying startToken. */
	returnToken->fieldToken.textTokenCount = endToken - startToken + 1;
	returnToken->fieldToken.textTokens = (struct lexToken **) 
		malloc(sizeof(struct lexToken *)
			* returnToken->fieldToken.textTokenCount);
	assert(returnToken->fieldToken.textTokens);
	
	for(i = startToken; i <= endToken; i++){
		(returnToken->fieldToken.textTokens)[i - startToken] = 
			(lexedOut->tokens)[i];
	}
	
	return returnToken;
}

struct parseToken *createParseTokenCQUERY(struct lexOut *lexedOut, 
	int startToken, int endToken){
	struct parseToken *returnToken;
	returnToken = (struct parseToken *) malloc(sizeof(struct parseToken));
	assert(returnToken);
	returnToken->type = CQUERY;
	
	returnToken->cQueryToken.arrow = (lexedOut->tokens)[startToken];
	
	return returnToken;
}

struct fieldToken *duplicateFieldToken(struct fieldToken *fieldToken){
	struct fieldToken *returnFieldToken;
	
	returnFieldToken = (struct fieldToken *) malloc(sizeof(struct fieldToken));
	assert(returnFieldToken);
	
	returnFieldToken->qualifier = fieldToken->qualifier;
	returnFieldToken->textTokens = fieldToken->textTokens;
	returnFieldToken->textTokenCount = fieldToken->textTokenCount;
	
	return returnFieldToken;
}

struct queryToken *duplicateQueryToken(struct queryToken *queryToken){
	struct queryToken *returnQueryToken;
	
	returnQueryToken = (struct queryToken *) malloc(sizeof(struct queryToken));
	assert(returnQueryToken);
	
	returnQueryToken->text = queryToken->text;
	returnQueryToken->textTokenCount = queryToken->textTokenCount;
	returnQueryToken->arrow = queryToken->arrow;
	
	return returnQueryToken;
}

struct cQueryToken *duplicateCQueryToken(struct cQueryToken *cQueryToken){
	struct cQueryToken *returnCQueryToken;
	
	returnCQueryToken = (struct cQueryToken *) 
		malloc(sizeof(struct cQueryToken));
	assert(returnCQueryToken);
	
	returnCQueryToken->arrow = cQueryToken->arrow;
	
	return returnCQueryToken;
}

struct fieldSetToken *duplicateFieldSet(struct fieldSetToken *fieldSetToken){
	struct fieldSetToken *returnFieldSetToken;
	
	returnFieldSetToken = (struct fieldSetToken *) 
		malloc(sizeof(struct fieldSetToken));
	assert(returnFieldSetToken);
	
	returnFieldSetToken->fields = fieldSetToken->fields;
	returnFieldSetToken->fieldTokenCount = fieldSetToken->fieldTokenCount;
	
	return returnFieldSetToken;
}

struct parseToken *reduceParseTokenFIELDSET(struct parsedOut *parsedOut, 
	int startToken, int endToken){
	int i;
	struct parseToken *returnToken;
	returnToken = (struct parseToken *) malloc(sizeof(struct parseToken));
	assert(returnToken);
	returnToken->type = FIELDSET;
	
	returnToken->fieldSetToken.fieldTokenCount = endToken - startToken + 1;
	returnToken->fieldSetToken.fields = (struct fieldToken **) 
		malloc(sizeof(struct fieldToken *)
			* returnToken->fieldSetToken.fieldTokenCount);
	assert(returnToken->fieldSetToken.fields);
	
	for(i = startToken; i <= endToken; i++){
		(returnToken->fieldSetToken.fields)[i - startToken] =
			duplicateFieldToken(&(((parsedOut->tokens)[i])->fieldToken));
		/* No longer need wrapper around spent parseToken. */
		free((parsedOut->tokens)[i]);
	}
	
	return returnToken;
}

struct parseToken *reduceParseTokenTQUERY(struct parsedOut *parsedOut, 
	int startToken, int endToken){
	int i;
	struct parseToken *returnToken;
	returnToken = (struct parseToken *) malloc(sizeof(struct parseToken));
	assert(returnToken);
	returnToken->type = TQUERY;
	
	/* Unwrap query token. */
	returnToken->tQueryToken.queryToken = 
		duplicateQueryToken(&((parsedOut->tokens)[startToken])->queryToken);
	/* Throw away wrapper. */
	free((parsedOut->tokens)[startToken]);
	/* Unwrap fieldSet token. */
	returnToken->tQueryToken.fieldSetToken = 
		duplicateFieldSet(&((parsedOut->tokens)[startToken + 1])->fieldSetToken);
	/* Throw away the wrapper. */
	free((parsedOut->tokens)[startToken + 1]);
	
	/* Work out if we need any extra tokens. */
	returnToken->tQueryToken.extraQueriesCount = endToken - startToken - 2 + 1;
	if(returnToken->tQueryToken.extraQueriesCount <= 0){
		returnToken->tQueryToken.extraResults = NULL;
	} else {
		returnToken->tQueryToken.cQueryTokens = (struct cQueryToken **)
			malloc(sizeof(struct cQueryToken *)
				* (returnToken->tQueryToken.extraQueriesCount));
		assert(returnToken->tQueryToken.cQueryTokens);
		returnToken->tQueryToken.extraResults = (struct fieldSetToken **)
			malloc(sizeof(struct fieldSetToken *)
				* (returnToken->tQueryToken.extraQueriesCount));
		assert(returnToken->tQueryToken.extraResults);
		for(i = startToken + 2; i <= endToken; i += 2){
			/* Unwrap continuing query token (the arrow). */
			(returnToken->tQueryToken.cQueryTokens)[i - startToken - 2] =
				duplicateCQueryToken(&((parsedOut->tokens)[i])->cQueryToken);
			/* Throw away the wrapper. */
			free((parsedOut->tokens)[i]);
			/* Unwrap fieldSetToken */
			(returnToken->tQueryToken.extraResults)[i - startToken - 1] =
				duplicateFieldSet(&((parsedOut->tokens)[i + 1])->fieldSetToken);
			/* Throw away the wrapper. */
			free((parsedOut->tokens)[i + 1]);
		}
	}
	
	return returnToken;
}

struct parsedOut *resultParse(struct lexOut *lexedOut, 
	struct errorSet *errorSet){
	struct parsedOut *returnParseOut;
	int lexProg = 0;
	int lexStart = 0;
	int parseProg = 0;
	int parseStart = 0;
	int parseSuccess;
	
	returnParseOut = (struct parsedOut *) malloc(sizeof(struct parsedOut));
	assert(returnParseOut);
	returnParseOut->sourceFileName = lexedOut->sourceFileName;
	returnParseOut->tokens = NULL;
	returnParseOut->tokenCount = 0;
	
	void error(char *errorT, struct parseToken *parseToken){
		if(errorT == NULL || parseToken == NULL){
			fprintf(stderr, "Unspecified parse error - caught %d.\n",__LINE__);
		} else {
			struct parseErrorInfo *pei = (struct parseErrorInfo *) 
				malloc(sizeof(struct parseErrorInfo));
			assert(pei);
			pei->errorText = errorT;
			pei->parseToken = parseToken;
			
			addError(errorSet, PARSEERROR, pei);
		}
	}
	
	int addParsedLexToken(enum parseProduction production, int startLexToken, 
		int endLexToken){
		returnParseOut->tokens = (struct parseToken **) 
			realloc(returnParseOut->tokens, 
				sizeof(struct parseToken *)*(returnParseOut->tokenCount + 1));
		assert(returnParseOut->tokens);
		switch(production){
			case QUERY:
				(returnParseOut->tokens)[returnParseOut->tokenCount] = 
					createParseTokenQUERY(lexedOut, startLexToken, endLexToken);
				(returnParseOut->tokenCount)++;
				break;
				
			case FIELD:
				(returnParseOut->tokens)[returnParseOut->tokenCount] = 
					createParseTokenFIELD(lexedOut, startLexToken, endLexToken);
				(returnParseOut->tokenCount)++;
				break;
				
			case CQUERY:
				(returnParseOut->tokens)[returnParseOut->tokenCount] = 
					createParseTokenCQUERY(lexedOut, startLexToken, 
						endLexToken);
				(returnParseOut->tokenCount)++;
				break;
			
			default:
				/* Others not implemented. Reaching here is a programming 
					error. */
				error(NULL, NULL);
				break;
		}
		return endLexToken - startLexToken + 1;
	}
	
	void reduceParsedParseToken(enum parseProduction production, int startParseToken,
		int endParseToken){
		int i;
		switch(production){
			case FIELDSET:
				(returnParseOut->tokens)[startParseToken] = 
					reduceParseTokenFIELDSET(returnParseOut, startParseToken, 
						endParseToken);
				break;
			
			case TQUERY:
				(returnParseOut->tokens)[startParseToken] = 
					reduceParseTokenTQUERY(returnParseOut, startParseToken, 
						endParseToken);
				break;
			
			default:
				/* Others not implemented. Reaching here is a programming
					error. Do no reduction. */
				error(NULL, NULL);
				return;
				break;
		}
		/* Drop tokens from startParseToken + 1 to endParseToken by 
			overwriting everything back that many items. */
		if(endParseToken - startParseToken > 0){
			for(i = endParseToken + 1; i < returnParseOut->tokenCount; i++){
				(returnParseOut->tokens)[i - (endParseToken - startParseToken)]
					= (returnParseOut->tokens)[i];
			}
			/* Update size. */
			returnParseOut->tokenCount -= (endParseToken - startParseToken);
		}
	}
	
	/* Returns number of matched tokens if successful. */
	int tryParseTerm(enum parseProduction attempt){
		int i;
		lexStart = lexProg;
		int arrowIndex = -1;
		switch(attempt){
			case FIELD:
				if(((lexedOut->tokens)[lexStart])->type != TEXT){
					return 0;
				}
				/* OK! */
				return addParsedLexToken(FIELD, lexStart, lexStart);
				break;
			
			case QUERY:
				/* Find index of arrow. */
				for (i = lexStart; i < lexedOut->tokenCount; i++){
					if(((lexedOut->tokens)[i])->type == ARROW){
						arrowIndex = i;
						break;
					}
				};
				
				/* Check if line matches start lex token. Fail match if it 
					doesn't (CQUERY handles no TEXT case). */
				if(arrowIndex > 0){
					if(((lexedOut->tokens)[lexStart])->type != TEXT 
						|| ((lexedOut->tokens)[lexStart])->sourceLine !=
							((lexedOut->tokens)[arrowIndex])->sourceLine){
						return 0;						
					}
				} else {
					/* No pre-arrow text item to check. */
					return 0;
				}
				
				/* Check all pre-arrow tokens are TEXT. */
				for(i = lexStart; i < arrowIndex; i++){
					if(((lexedOut->tokens)[i])->type != TEXT){
						return 0;
					}
				}
				
				/* OK! */
				return addParsedLexToken(QUERY, lexStart, arrowIndex);
				
				break;
			
			case CQUERY:
				if(((lexedOut->tokens)[lexProg])->type == ARROW){
					/* OK! */
					return addParsedLexToken(ARROW, lexStart, lexStart + 1);
				} else {
					return 0;
				}
				break;
			
			case FIELDSET:
			case TQUERY:
			case PARSENONE:
			default:
				fprintf(stderr, "%d: Program error: Attempted to parse "
								"terminals for non-terminal tokens\n",__LINE__);
				return 0;
				break;
		}
	}
	
	int tryParse(enum parseProduction attempt){
		parseStart = parseProg;
		int i;
		int matchedFields;
		switch(attempt){
			case FIELDSET:
				/* Queries will already have been consumed, so we just need   */
				/* consume as many fields as we can. */
				matchedFields = 0;
				for(i = parseStart; i < returnParseOut->tokenCount; i++){
					if(((returnParseOut->tokens)[i])->type != FIELD){
						break;
					} else {
						matchedFields++;
					}
				}
				if(matchedFields > 0){
					/* Reduce matchedFields tokens beginning from parseStart to
						a single token. */
					reduceParsedParseToken(FIELDSET, parseStart, 
						parseStart + matchedFields - 1);
					return 1;
				} else {
					return 0;
				}
				
				break;

			case TQUERY:
				matchedFields = 0;
				if(((returnParseOut->tokens)[parseStart])->type != QUERY){
					/* Failed match. */
					return 0;
				} else {
					matchedFields++;
				}
				if((parseStart + 1) >= returnParseOut->tokenCount
					|| (((returnParseOut->tokens)[parseStart + 1])->type 
						!= FIELDSET)){
					/* Failed match, student output error. */
					error(NULL, NULL);
					return 0;
				} else {
					matchedFields++;
				}
				/* 
					Encode second condition into for loop condition so we don't
					need to check a second time.
				*/
				for(i = parseStart + 2; i < (returnParseOut->tokenCount - 1); 
					i += 2){
					if(((returnParseOut->tokens)[i])->type != CQUERY){
						break;
					} else {
						matchedFields++;
					}
					if(((returnParseOut->tokens)[i])->type != FIELDSET){
						/* We have failed parsing here. Salvage what we can to 
							recover. */
						error("Expected FIELDSET but found different token.\n",
							((returnParseOut->tokens)[i]));
						matchedFields--;
						break;
					}
				}
				/* Reduce. */
				reduceParsedParseToken(TQUERY, parseStart, 
					parseStart + matchedFields - 1);
				return 1;
				break;
			
			case QUERY:
			case CQUERY:
			case FIELD:
			case PARSENONE:
			default:
				/* Anything reaching here is a programming error. */
				error(NULL, NULL);
				return 0;
				break;
		}
	}
	
	for(lexProg = 0; lexProg < lexedOut->tokenCount; lexProg++){
		/* Parse for query. */
		parseSuccess = tryParseTerm(QUERY);
		if(!parseSuccess && (lexProg - 1) > 0 && 
			((lexedOut->tokens)[lexProg - 1])->sourceLine < 
			((lexedOut->tokens)[lexProg])->sourceLine){
			/* Try parsing for continued query if ARROW token begins new 
				line. */
			parseSuccess = tryParseTerm(CQUERY);
		}
		if(!parseSuccess){
			/* Parse for field */
			parseSuccess = tryParseTerm(FIELD);
		}
		if(parseSuccess > 0){
			/* 
				Skip over lexed tokens so we don't get double paired queries.
				Prioritising halting assurance over elegance, so one less than
				parseSuccess subtracted to allow the assurance always move 
				forwards.
			*/
			lexProg += (parseSuccess - 1);
		}
	}
	
	/* Parse for FIELDSET production. */
	for(parseProg = 0; parseProg < returnParseOut->tokenCount; parseProg++){
		/* OK to fail. */
		tryParse(FIELDSET);
	}
	
	/* Parse for TQUERY production. */
	for(parseProg = 0; parseProg < returnParseOut->tokenCount; parseProg++){
		/* Should always succeed. */
		parseSuccess = tryParse(TQUERY);
		if(! parseSuccess){
			error(NULL, NULL);
		}
	}
	
	return returnParseOut;
}

struct testResultSet *createTestResultSet(){
	struct testResultSet *returnSet = (struct testResultSet *) 
		malloc(sizeof(struct testResultSet));
	assert(returnSet);
	returnSet->resultCount = 0;
	returnSet->results = NULL;
	returnSet->outfileOutput = NULL;
	returnSet->outfileParseErrors = NULL;
	returnSet->stdOutput = NULL;
	returnSet->stdOutputParseErrors = NULL;
	returnSet->tQueryMatchesQ = NULL;
	returnSet->tQueryMatchesD = NULL;
	returnSet->jumpLookupQi = 0;
	returnSet->jumpLookupQj = 0;
	returnSet->jumpLookupDi = 0;
	returnSet->jumpLookupDj = 0;
	
	return returnSet;
}

struct testResultSet *constructResults(struct testResultSet *testingResults, 
	char *stdoutFileName, char *outfileName, 
	struct querySet *querySet){
	FILE *stdoutFile;
	FILE *outfile;
	struct lexOut *lexedOut;
	struct lexOut *lexedStdout;
	struct parsedOut *parseOut;
	struct parsedOut *parseStdout;
	
	outfile = fopen(outfileName,"r");
	assert(outfile);
	stdoutFile = fopen(stdoutFileName,"r");
	assert(stdoutFile);
	
	testingResults->stdOutputParseErrors = createErrorSet();
	lexedStdout = resultLex(stdoutFile, stdoutFileName, 
		testingResults->stdOutputParseErrors);
	fclose(stdoutFile);
	testingResults->outfileParseErrors = createErrorSet();
	lexedOut = resultLex(outfile, outfileName,
		testingResults->outfileParseErrors);
	fclose(outfile);
	
	parseStdout = resultParse(lexedStdout, 
		testingResults->stdOutputParseErrors);
	parseOut = resultParse(lexedOut, testingResults->outfileParseErrors);
	
	buildResults(&testingResults, parseOut, parseStdout);
	
	return testingResults;
}

void buildResults(struct testResultSet **testingResults, 
	struct parsedOut *parsedOut, struct parsedOut *parsedStdOut){
	struct testResultSet *returnResult;
	
	if(! *testingResults){
		returnResult = (struct testResultSet *) 
			malloc(sizeof(struct testResultSet));
		assert(returnResult);
	}
	
	(*testingResults)->outfileOutput = parsedOut;
	(*testingResults)->stdOutput = parsedStdOut;
	
	return;
}

void freeTestingResults(struct testResultSet **testResultSet){
	/* Not implemented */
	if(!testResultSet || !*testResultSet) return;
	/* int i; */
	if((*testResultSet)->results){
		/* Should also free strings in results. */
		free((*testResultSet)->results);
	}
}

void resetProgress(struct testResultSet *testResultSet){
	if(! testResultSet) return;
	int i;
	if(! testResultSet->tQueryMatchesQ){
		/* Allocate space for set of queries. */
		if(testResultSet->stdOutput->tokenCount > 0){
			testResultSet->tQueryMatchesQ = (int **) malloc(sizeof(int *)*
				(testResultSet->stdOutput->tokenCount));
			assert(testResultSet->tQueryMatchesQ);
			testResultSet->jumpLookupQi = 0;
			testResultSet->jumpLookupQj = 0;
		} else {
			testResultSet->jumpLookupQi = NOFREE;
			testResultSet->jumpLookupQj = NOFREE;
		}
		if(testResultSet->outfileOutput->tokenCount > 0){
			testResultSet->tQueryMatchesD = (int **) malloc(sizeof(int *)*
				(testResultSet->outfileOutput->tokenCount));
			assert(testResultSet->tQueryMatchesD);
			testResultSet->jumpLookupDi = 0;
			testResultSet->jumpLookupDj = 0;
		} else {
			testResultSet->jumpLookupDi = NOFREE;
			testResultSet->jumpLookupDj = NOFREE;
		}
		for(i = 0; i < testResultSet->stdOutput->tokenCount; i++){
			(testResultSet->tQueryMatchesQ)[i] = NULL;
		}
		for(i = 0; i < testResultSet->outfileOutput->tokenCount; i++){
			(testResultSet->tQueryMatchesD)[i] = NULL;
		}
	} else {
		if(testResultSet->stdOutput->tokenCount > 0){
			testResultSet->jumpLookupQi = 0;
			testResultSet->jumpLookupQj = 0;
		} else {
			testResultSet->jumpLookupQi = NOFREE;
			testResultSet->jumpLookupQj = NOFREE;
		}
		if(testResultSet->outfileOutput->tokenCount > 0){
			testResultSet->jumpLookupDi = 0;
			testResultSet->jumpLookupDj = 0;
			
		} else {
			testResultSet->jumpLookupDi = NOFREE;
			testResultSet->jumpLookupDj = NOFREE;
		}
		for(i = 0; i < testResultSet->stdOutput->tokenCount; i++){
			if(testResultSet->tQueryMatchesQ){
				free(testResultSet->tQueryMatchesQ);
			}
			(testResultSet->tQueryMatchesQ)[i] = NULL;
		}
		for(i = 0; i < testResultSet->outfileOutput->tokenCount; i++){
			if(testResultSet->tQueryMatchesD){
				free(testResultSet->tQueryMatchesD);
			}
			(testResultSet->tQueryMatchesD)[i] = NULL;
		}
	}
}

/* Returns the number of data tokens in the ith query token. */
int queryTokenCount(struct parsedOut *parsedOut, int i){
	if(((parsedOut->tokens)[i])->type == TQUERY){
		struct tQueryToken *tQ = &(((parsedOut->tokens)[i])->tQueryToken);
		
		if(tQ->fieldSetToken){
			return (1 + tQ->extraQueriesCount);
		}
	}
	
	return 0;
}

/* Returns the jth field set token in the ith query set in. */
struct fieldSetToken *findFSToken(int i, int j, 
	struct parsedOut *parsedOut){
	if(((parsedOut->tokens)[i])->type == TQUERY){
		struct tQueryToken *tQ = &(((parsedOut->tokens)[i])->tQueryToken);
		
		if(j == 0){
			return tQ->fieldSetToken;
		} else {
			return (tQ->extraResults)[j - 1];
		}
	}
	return NULL;
}

void addMissingErrors(struct testResultSet *testingResults, 
	struct errorSet *errorSet){
	int i, j;
	
	void addMissingErrors(struct parsedOut *parsedOut, int jumpI, int jumpJ,
		int **tQueryMatches){
		for(i = jumpI; i < parsedOut->tokenCount; i++){
			for(j = jumpJ; j < queryTokenCount(parsedOut, i); j++){
				if(tQueryMatches[i] == NULL || 
					tQueryMatches[i][j] == NOTPRESENT){
					addError(errorSet, EXTRAERROR, findFSToken(i, j, 
						parsedOut));
				}
			}
			jumpJ = 0;
		}
	}
	
	if(testingResults->jumpLookupQi != NOFREE){
		/* Non-matched items present at least here. */
		addMissingErrors(testingResults->stdOutput, 
			testingResults->jumpLookupQi, testingResults->jumpLookupQj, 
			testingResults->tQueryMatchesQ);
	}
	if(testingResults->jumpLookupDi != NOFREE){
		/* Non-matched items present at least here. */
		addMissingErrors(testingResults->outfileOutput, 
			testingResults->jumpLookupDi, testingResults->jumpLookupDj,
			testingResults->tQueryMatchesD);
	}
}

/* 
	Returns 0 if data fields in data item match words in field set token.
	Fields in field set are not tied to any field, but must occur in the
	same order as the data item (this is for my sanity, not because we
	don't have the technology). Returns -1 otherwise.
*/
int compareTokenQuery(struct queryToken *qt, char *query){
	int i;
	int queryToken = 0;
	int queryTokenProgress = 0;
	int stringLen;
	int queryLen;
	char *currentQueryString;
	
	if(qt->textTokenCount > queryToken){
		currentQueryString = ((qt->text)[queryToken])->tokenContents;
		queryLen = strlen(currentQueryString);
	} else {
		/* We know the data token count should be > 0 */
		return -1;
	}
	
	stringLen = strlen(query);
	for(i = 0; i < stringLen; i++){
		if(!isalnum(query[i])){
			continue;
		}
		
		if(currentQueryString[queryTokenProgress] != query[i]){
			return -1;
		} else {
			queryTokenProgress++;
			/* 
				Terminate at NULL character if query doesn't match, so don't 
				get next string if final string. Deals with any whitespace.
			*/
			if(queryTokenProgress == queryLen && 
				(queryToken + 1) < (qt->textTokenCount)){
				/* Get next string. */
				queryToken += 1;
				queryTokenProgress = 0;
				
				currentQueryString = ((qt->text)[queryToken])->tokenContents;
				
				queryLen = strlen(currentQueryString);
			}
		}
	}
	if(currentQueryString[queryTokenProgress] == query[i]){
		/* Both strings ended at the same time. */
		return 0;
	} else {
		return -1;
	}
}

/* 
	Returns 0 if data fields in data item match words in field set token.
	Fields in field set are not tied to any field, but must occur in the
	same order as the data item (this is for my sanity, not because we
	don't have the technology). Returns -1 otherwise.
*/
int compareTokenData(struct fieldSetToken *fst, struct dataItem *data){
	int i, j;
	int fstFieldi = 0;
	int fstProgress = 0;
	int stringLen;
	int fstLen;
	char *currentDataString;
	char *currentFSTString;
	
	if(fst->fieldTokenCount > fstFieldi && 
		(fst->fields)[fstFieldi]->textTokenCount > 0){
		currentFSTString = 
			((((fst->fields)[fstFieldi])->textTokens)[0])->tokenContents;
		fstLen = strlen(currentFSTString);
	} else {
		/* We know the data token count should be > 0 */
		return -1;
	}
	
	for(i = 0; i < data->fieldCount; i++){
		if(i == KEYFIELD){
			/* Skip over keyfield. */
			i++;
		}
		currentDataString = (data->fields)[i];
		stringLen = strlen(currentDataString);
		for(j = 0; j < stringLen; j++){
			if(!isalnum(currentDataString[j])){
				continue;
			}
			if(currentDataString[j] != currentFSTString[fstProgress]){
				return -1;
			} else {
				fstProgress++;
				if(fstProgress == fstLen && 
					fstFieldi + 1 < fst->fieldTokenCount){
					/* Get next string. */
					fstFieldi += 1;
					fstProgress = 0;
					currentFSTString = 
							((((fst->fields)[fstFieldi])->textTokens)[0])->
								tokenContents;
					fstLen = strlen(currentFSTString);
				}
			}
		}
	}
	if(currentDataString[j] == currentFSTString[fstProgress]){
		return 0;
	} else {
		/* currentFSTString is longer */
		return -1;
	}
}

/*
                                                                         s      
  /:s                                                                  s:-      
  +--\s                                                              o/--/      
 ss+--.`\s                  o+/::------://:::::://+o              o:``--/s+     
 s:+o:`   .\s         s+:.`                          `.:+      +-`    :o+:+     
  o::+\:`   `      o:`                                    .+  o    `///::o      
 o/o+- `     \   +-/-                                -+:`   /o`       -+o//     
  \:\o\:      `+o+:`                                   .\+:+:       :/+/-/s     
   so\.`      .+:                                        `\+`       `.+os       
   o:\+\-    /+`/`                                   `     .o.     .:/::+       
     o+\-::.o:.o. `:        +-             o.        o-     `o- .//:/os         
        o.`+:.o`  o-       `s              //        .o      `s.```+            
           +`s`  -+        //              -+         o-      - :::.\           
         /s.+-   o.        +-              -o         -+       o-    `\s        
       +``s.s   `s     `--:s/.            `/s:/::-.   `s       -o       .+      
     s.  -soo   `s   --..``:o::           -++`   `.-.  o:.--::/+          `o    
    +    :soo    o/::///////+//////////////++////////::oo+++++++ .          \   
   +     :s+s/+o/:-..:o/:::s:..```````````-:s/::oo///:.+o+++++++ .           +  
   `    -ss++++s.```/+++  sos s-`````````.:o soos  ///.+o+++++++ +/\:.`      `  
  s   .s   ++++o+```   `s.`.`:s``````````  s-`.``: `  `+o+++++++ .  `.:\o\.   + 
   - /     +++++s-``   -/`:+:`o`````````` `o`:+/``o`  `s++++++++s/+-    -  s: / 
   s+      o+++++s.``  -/`-/-`+`````````` `+`-/:``o`  ` +++++++o+``o-    :   ss 
           s+++++os``  `o.```.+``````````` +-````-o  `- +++++++s-``+/     \     
            ++++++s-``  ./:::/.`````````````::://:` ``/o+++++++s``-o`      .    
            o+++++s:....```````````````````````````...s+++++++s/-+/`        \   
            s+++++s/````````````````````````````````.:s+++++++ /-`           o  
             o+++++s:``````````````````````````..````oo++++++s-    :-        :  
             soooooo +/:.``/++/.-:--///..+++o+o++o-/+ oooooos+:-    -+\`     :  
              oooooos  .//+s/::+s:/o/+++o:-:+:--:os`:soooooos. -///:-.-s-    o  
              oooooo `  +:- o:-----::-----------:so /sooooo . `    /     -  +   
               ooooo :-/ s`-s:-:+:--:/---:+/::+o+o -+soooos:  s-   :      -s    
                sooos      /soosssos  sooso-::.   `oo oooos`+   \ -             
                  ooo       :o-ooosss+sss+s..+      + soosos     s              
                    ss    s.`s  `:  . s o-`  o-      -s s                       
                        o:  :+  :oo+  - s/`  .s        -ss+/::\s                
                      /`    +-  /+o/  `soo.   /:        -s+s::+                 
                    /o+`  .+/`                `s     .:++so/+s                  
                     s/o++o++/:-.``-++.``.--:/+s/-/+++o+ooo+---:/s              
                    sos s:----/+/+++::++o+/::-/ sossoss+++oo--/oos              
                         o+:-/s:--------/s:----+s++ oo:::::----:+               
                              o++////////so+ooooso:-----------/sos              
                              s////++s   +//::::o+--+:----:s+++s                
                               /:::::s   +::::::o+--+o-----/                    
                               +:::::s   s::::::oo:-: s+:---o                   
                               s:::::s    /:::::o  os     ss                    
                                /::::s    o:::::s                               
                                soo++      oo+//s                               
                                sssss       ssss                                
yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy
*/
int checkResult(struct result *lResult, struct result *mResult, 
	struct errorSet *lErrors, struct errorSet *mErrors, 
	struct errorSet **parseErrStdout, struct errorSet **parseErrOutfile,
	struct testResultSet *testingResults){
	int queryComparisons;
	struct tQueryToken *foundQueryToken = NULL;
	struct fieldSetToken *foundFSToken = NULL;
	struct fieldSetToken *queryFSToken = NULL;
	int queryMatch = -1;
	int loci, locj;
	int i, j;
	struct comparisonErrorData *ced;
	
	/*
		Add errors to lResult and mResult.
	*/
	void addErrorsBoth(enum errorType errorType, void *errorData){
		addError(lErrors, errorType, errorData);
		if(mErrors){
			addError(mErrors, errorType, errorData);
		}
	};
	
	/* 
		Search for the given query in the given parsed token set with the given.
		Only searches for/finds queries. Puts found location in loci or 
		NOTPRESENT in loci.
	*/
	void searchForQuery(char *query, struct parsedOut *tokenSet, 
		int firstUncheckedi, int **tQueryMatches){
		int i, j;
		int found = NOTPRESENT;
		int fieldCount;
		struct fieldSetToken *fsToken;
		
		loci = NOTPRESENT;
		
		if(firstUncheckedi == NOFREE){
			/* Exhausted all items to check. Abort. */
			return;
		}
		
		for(i = firstUncheckedi; i < tokenSet->tokenCount; i++){
			if(((tokenSet->tokens)[i])->type == TQUERY){
				/* 
					Look for the query, and ONLY find query when field set is a
					number of some kind. Don't refind old queries.
				*/
				if(compareTokenQuery(
					((tokenSet->tokens)[i])->tQueryToken.queryToken, query) 
					== 0){
					fieldCount = queryTokenCount(tokenSet, i);
					for(j = 0; j < fieldCount; j++){
						fsToken = findFSToken(i, j, tokenSet);
						
						if(fsToken->fieldTokenCount == 1 &&
							isdigit(((fsToken->fields[0])->textTokens[0])->
								tokenContents[0]) && 
							(tQueryMatches[i] == NULL)){
							found = i;
							loci = i;
							locj = j;
							/* 
								When we just have a query token, it just has a single
								field, so mark it as some non-zero value.
								
								This won't be done here, but is here as a note for 
								later because I had to rethink this a few times.
							*/
							/* tQueryMatchesQ[loci] = PRESENT; */
						}
					}
				}
			}
			if(found != NOTPRESENT){
				break;
			}
		}
	}
	
	/* 
		Mark (and possibly allocate and initialise) loci, locj on the given 2D
		array.
	*/
	void mark2(int ** tQueryMatches, struct parsedOut *parsedOut){
		int i;
		if(! tQueryMatches[loci]){
			int size = queryTokenCount(parsedOut, loci);
			/* Allocate and initialise. */
			tQueryMatches[loci] = (int *) malloc(sizeof(int)*size);
			assert(tQueryMatches[loci]);
			for(i = 0; i < size; i++){
				tQueryMatches[loci][i] = NOTPRESENT;
			}
		}
		tQueryMatches[loci][locj] = locj;
	}
	
	/* 
		Try to find the given query and then check its fields match the data 
		item given. loci is set to NOTPRESENT if no matching data is found.
	*/
	void searchForResult(char *query, struct parsedOut *parsedOut, 
		int jumpLookupi, int jumpLookupj, struct dataItem *dataItem, 
		int **tQueryMatches){
		int i, j;
		int firstLoop = 1;
		int jTokens;
		struct fieldSetToken *dataToken;
		for(i = jumpLookupi; i < parsedOut->tokenCount; i++){
			jTokens = queryTokenCount(parsedOut, i);
			for(j = jumpLookupj; j < jTokens; j++){
				dataToken = findFSToken(i, j, parsedOut);
				/* Only find the token if not marked present. */
				if((tQueryMatches[i] == NULL || 
					tQueryMatches[i][j] == NOTPRESENT) && 
					compareTokenData(dataToken, dataItem) == 0){
					loci = i;
					locj = j;
					return;
				}
			}
			if(firstLoop){
				/* Local jumpLookupj no longer applies.  */
				jumpLookupj = 0;
				firstLoop = 0;
			}
		}
		
		loci = NOTPRESENT;
	};
	
	/* 
		Push the i and j jump lookup along until they point at a NULL or -1 item
		in the tQueryMatches item. 
	*/
	void pushJumpLookup(int **tQueryMatches, int *jumpLookupi, 
		int *jumpLookupj, struct parsedOut *parsedOut){
		int i, j, querySize;
		/* 
			Check current pointing position. If off end of file, we're done, 
			set NOFREE flag in jumpLookupi and j. Otherwise, check if j off end
			of current i token, if so, push i forward one and reset j. If this
			pushes us off the end of the file, we're done. If off neither axis,
			check if current location is empty, either by i row being NULL or
			i,j being NOTPRESENT. If it is not, continue pushing and repeating
			the prior process until either the end of file is hit or we reach
			such a point.
		*/
		if(*jumpLookupi == NOFREE){
			return;
		}
		
		for(i = *jumpLookupi; i < parsedOut->tokenCount; i++){
			querySize = queryTokenCount(parsedOut, i);
			for(j = *jumpLookupj; j < querySize; j++){
				if(tQueryMatches[i] == NULL 
					|| tQueryMatches[i][j] == NOTPRESENT){
					*jumpLookupi = i;
					*jumpLookupj = j;
					/* RETURN, so we don't just set the values to NOFREE 
						anyway. */
					return;
				}
			}
			/* Pushed to next. */
			*jumpLookupj = 0;
		}
		*jumpLookupi = NOFREE;
		*jumpLookupj = NOFREE;
	}
	
	searchForQuery(getKey(lResult->query), testingResults->stdOutput, 
		testingResults->jumpLookupQi, testingResults->tQueryMatchesQ);
	if(loci != NOTPRESENT){
		/* Found query, so mark it in query set. */
		mark2(testingResults->tQueryMatchesQ, testingResults->stdOutput);
		foundQueryToken = 
			&(((testingResults->stdOutput->tokens)[loci])->tQueryToken);
		queryFSToken = findFSToken(loci, locj, testingResults->stdOutput);
	} else {
		/* Attempt to search in other file. */
		searchForQuery(getKey(lResult->query), testingResults->outfileOutput, 
			testingResults->jumpLookupDi, testingResults->tQueryMatchesD);
		if(loci != NOTPRESENT){
			foundQueryToken = 
				&(((testingResults->outfileOutput->tokens)[loci])->tQueryToken);
			queryFSToken = findFSToken(loci, locj, 
				testingResults->outfileOutput);
			addErrorsBoth(WRONGFILEQUERY, (void *) queryFSToken);
			mark2(testingResults->tQueryMatchesD, 
				testingResults->outfileOutput);
		}
	}
	
	/* Failed to find query. */
	if(loci == NOTPRESENT){
		addErrorsBoth(MISSINGQUERYERROR, (void *) lResult->query);
		queryMatch = 0;
	} else {
		/* Check comparisons. */
		queryComparisons = atoi((((queryFSToken->fields)[0])->textTokens[0])->
			tokenContents);
		if(queryComparisons == lResult->comparisons){
			queryMatch = -1;
		} else {
			ced = (struct comparisonErrorData *) 
				malloc(sizeof(struct comparisonErrorData));
			assert(ced);
			ced->query = foundQueryToken->queryToken->text;
			ced->textCount = foundQueryToken->queryToken->textTokenCount;
			ced->expectedComparisons = lResult->comparisons;
			ced->actualComparisons = queryComparisons;
		
			addError(lErrors, COMPARISONERROR, (void *) ced);
			queryMatch = 0;
		}
		if(queryComparisons == mResult->comparisons){
			queryMatch += 1;
		} else {
			if(mErrors){
				ced = (struct comparisonErrorData *) 
					malloc(sizeof(struct comparisonErrorData));
				assert(ced);
				ced->query = foundQueryToken->queryToken->text;
				ced->textCount = foundQueryToken->queryToken->textTokenCount;
				ced->expectedComparisons = mResult->comparisons;
				ced->actualComparisons = queryComparisons;
				
				addError(mErrors, COMPARISONERROR, (void *) ced);
			}
		}
	}
	
	/* Search for all result items. */
	struct data *dataSet;
	for(i = 0; i < lResult->returnCount; i++){
		dataSet = (struct data *)((lResult->returnedData)[i]);
		for(j = 0; j < dataSet->count; j++){
			searchForResult(getKey(lResult->query), 
				testingResults->outfileOutput, testingResults->jumpLookupDi, 
				testingResults->jumpLookupDj, 
				(struct dataItem *) ((dataSet->items)[j]), 
				testingResults->tQueryMatchesD);
			if(loci != NOTPRESENT){
				/* Found loci & locj, mark. */
				mark2(testingResults->tQueryMatchesD, 
					testingResults->outfileOutput);
			} else {
				/* Try stdout. */
				searchForResult(getKey(lResult->query), 
					testingResults->stdOutput, 
					testingResults->jumpLookupQi, testingResults->jumpLookupQj, 
					(struct dataItem *) ((dataSet->items)[j]),
					testingResults->tQueryMatchesQ);
				if(loci != NOTPRESENT){
					/* Found loci & locj, mark. */
					foundFSToken = findFSToken(loci, locj, 
						testingResults->stdOutput);
					mark2(testingResults->tQueryMatchesQ, 
						testingResults->stdOutput);
					addErrorsBoth(WRONGFILEDATA, (void *) foundFSToken);
				} else {
					/* Didn't find data item. */
					addErrorsBoth(MISSINGDATAERROR, 
						(void *) (dataSet->items)[j]);
				}
			}
		}
	}
	
	/* push jumpLookup[QD][ij] ahead if possible */
	pushJumpLookup(testingResults->tQueryMatchesQ, 
		&(testingResults->jumpLookupQi), &(testingResults->jumpLookupQj), 
		testingResults->stdOutput);
	pushJumpLookup(testingResults->tQueryMatchesD, 
		&(testingResults->jumpLookupDi), &(testingResults->jumpLookupDj), 
		testingResults->outfileOutput);
	
	*parseErrStdout = testingResults->outfileParseErrors;
	*parseErrOutfile = testingResults->stdOutputParseErrors;
	
	return queryMatch;
}

void printLexError(void *error){
	struct lexErrorInfo *errorTyped = (struct lexErrorInfo *) error;
	int i;
	
	printf(ERRORLINEPREFIX"[%d:%d]%s\n", errorTyped->lineNum, 
		errorTyped->lineCol, errorTyped->errorText);
	printf(ERRORLINEPREFIX"%s\n",errorTyped->line);
	/* Primitive line context, doesn't handle tabspaces and the like. */
	printf(ERRORLINEPREFIX);
	for(i = 0; i < errorTyped->lineCol; i++){
		printf(" ");
	}
	printf("^\n");
}

char *stringForParseType(enum parseProduction pp){
	switch(pp){
		case TQUERY:
			return "TQUERY";
			break;
			
		case QUERY:
			return "QUERY";
			break;
			
		case CQUERY:
			return "CQUERY";
			break;
			
		case FIELD:
			return "FIELD";
			break;
			
		case FIELDSET:
			return "FIELDSET";
			break;
			
		case PARSENONE:
			return "PARSENONE";
			break;
		
		default:
			return "(not found)";
	}
}

void printParseError(void *error){
	struct parseErrorInfo *errorTyped = (struct parseErrorInfo *) error;
	
	printf(ERRORLINEPREFIX"%s\n", errorTyped->errorText);
	/* This could be much nicer, but parse errors are going to be messy 
		anyway. */
	printf(ERRORLINEPREFIX"Token type was: %s, should have been FIELDSET.\n",
		stringForParseType(errorTyped->parseToken->type));
}

void printComparisonError(void *error){
	int i;
	struct comparisonErrorData *errorTyped = 
		(struct comparisonErrorData *) error;
	printf(ERRORLINEPREFIX"[%d:%d]Incorrect comparison count in query:[",
		(errorTyped->query[0])->sourceLine, (errorTyped->query[0])->sourceCol);
	for(i = 0; i < errorTyped->textCount; i++){
		if(i != (errorTyped->textCount - 1)){
			printf("%s ",(errorTyped->query[i])->tokenContents);
		} else {
			printf("%s",(errorTyped->query[i])->tokenContents);
		}
	}
	printf(	"][%d instead of %d]\n", errorTyped->actualComparisons, 
		errorTyped->expectedComparisons);
}

void printWrongFileQueryError(void *error){
	struct fieldSetToken *errorTyped = (struct fieldSetToken *) error;
	/* Could also fairly easily add query info, but no real need for now. */
	printf(ERRORLINEPREFIX"Query found in wrong file (outfile)\n");
	printFSToken(errorTyped);
	printf("\n");
}

void printWrongFileDataError(void *error){
	struct fieldSetToken *errorTyped = (struct fieldSetToken *) error;
	printf(ERRORLINEPREFIX"Data item found in wrong file (stdout)\n");
	printFSToken(errorTyped);
	printf("\n");
}

void printMissingQueryError(void *error){
	struct query *errorTyped = (struct query *) error;
	char *key = getKey(errorTyped);
	printf(ERRORLINEPREFIX"Failed to find query [%s]\n",key);
}

void printMissingDataError(void *error){
	struct dataItem *errorTyped = (struct dataItem *) error;
	int i;
	printf(ERRORLINEPREFIX"Failed to find data item [");
	for(i = 0; i < errorTyped->fieldCount; i++){
		if(i != (errorTyped->fieldCount - 1)){
			printf("%s ",(errorTyped->fields)[i]);
		} else {
			printf("%s",(errorTyped->fields)[i]);
		}
	}
	printf("]\n");
}

void printFSToken(struct fieldSetToken *fsToken){
	/* Get stats. */
	int fieldCount = fsToken->fieldTokenCount;
	int fieldsLength = 0;
	int maxFieldLength = 0;
	int tokenLineStart = -1;
	int tokenColStart = -1;
	int nextQLength;
	int nextFLength;
	int i;
	if(fieldCount > 0){
		if(((fsToken->fields)[0])->qualifier){
			tokenLineStart = ((fsToken->fields)[0])->qualifier->sourceLine;
			tokenColStart  = ((fsToken->fields)[0])->qualifier->sourceCol;
		} else {
			tokenLineStart = (((fsToken->fields)[0])->textTokens[0])->sourceLine;
			tokenColStart  = (((fsToken->fields)[0])->textTokens[0])->sourceCol;
		}
	}
	for(i = 0; i < fieldCount; i++){
		if(((fsToken->fields)[i])->qualifier){
			nextQLength = 
				strlen(((fsToken->fields)[i])->qualifier->tokenContents);
		} else {
			nextQLength = 0;
		}
		nextFLength = 
			strlen((((fsToken->fields)[i])->textTokens[0])->tokenContents);
		if(nextFLength > maxFieldLength){
			maxFieldLength = nextFLength;
		}
		fieldsLength += nextFLength;
		fieldsLength += nextQLength;
	}
	printf(ERRORLINEPREFIX"[%d:%d-%d,TotalFieldSize:%d,MaxFieldLength:%d]\n", 
		tokenLineStart, tokenColStart, tokenColStart + fieldsLength, 
		fieldsLength, maxFieldLength);
	printf(ERRORLINEPREFIX);
	
	for(i = 0; i < fieldCount; i++){
		if(((fsToken->fields)[i])->qualifier){
			printf("%s ",((fsToken->fields)[i])->qualifier->tokenContents);
		}
		if(i == (fieldCount - 1)){
			printf("%s",(((fsToken->fields)[i])->textTokens[0])->tokenContents);
		} else {
			printf("%s ",
				(((fsToken->fields)[i])->textTokens[0])->tokenContents);
		}
	}
}

void printExtraError(void *error){
	struct fieldSetToken *errorTyped = (struct fieldSetToken *) error;
	printf(ERRORLINEPREFIX"Extra data record found: \n");
	printFSToken(errorTyped);
	printf("\n");
}

