/*
	Contains prototypes and definitions for creating and manipulating a pair of
	input and output files.
	
	Input is lexed and parsed and compiled into a test results object.
	
	Written by Grady Fitzpatrick (Staff 110067, Student 575753) for COMP20003.
*/

#include "querySet.h"
#include "resultSet.h"
#include "errorSet.h"

struct testResultSet;

/* Create an empty set to hold read results. */
struct testResultSet *createTestResultSet();

/* 
	Builds a test result set from the given stdoutFile and outfile which should
	contain output from running a test.
*/
struct testResultSet *constructResults(struct testResultSet *testingResults, 
	char *stdoutFileName, char *outfileName, 
	struct querySet *querySet);

/*
	Frees all memory handled by testing results.
*/
void freeTestingResults(struct testResultSet **testResultSet);

/*
	Reset testing structure to having no results found.
*/
void resetProgress(struct testResultSet *testResultSet);

/*
	Add missing errors for all rows present in the testing result set which have
	not been marked as found.
*/
void addMissingErrors(struct testResultSet *testingResults, 
	struct errorSet *errorSet);

/*
	Checks if the given data and queries are in the testing results, returns 0
	if query is not present in resultSet or comparison counts both match [or 
	both are wrong].
	
	Returns -1 if comparison only matches lResult's comparison count, and 1 if
	comparison only matches mResult's comparison count.
	
	Regardless of whether a comparison matches the other or not, errors are 
	added to the error sets when matches fail. 
	Failure can occur on three bases:
	- MISSING query.
	- MISSING data.
	- INCORRECT comparison count.
	
	Puts parsing results into provided positions.
	
	For sanity's sake, I have assumed no queries occur more than once in the 
	search file. Though if they do, I think everything still works.
*/
int checkResult(struct result *lResult, struct result *mResult, 
	struct errorSet *lErrors, struct errorSet *mErrors, 
	struct errorSet **parseErrStdout, struct errorSet **parseErrOutfile,
	struct testResultSet *testingResults);

/* 
	Prints a Lex error using the given data object (converting it to the relevant 
	type. 
*/ 
void printLexError(void *error);

/* 
	Prints a Parse error using the given data object (converting it to the relevant 
	type. 
*/ 
void printParseError(void *error);

/* 
	Prints a Comparison error using the given data object (converting it to the relevant 
	type. 
*/ 
void printComparisonError(void *error);

/* 
	Prints a WrongFileQuery error using the given data object (converting it to the relevant 
	type. 
*/ 
void printWrongFileQueryError(void *error);

/* 
	Prints a WrongFileData error using the given data object (converting it to the relevant 
	type. 
*/ 
void printWrongFileDataError(void *error);

/* 
	Prints a MissingQuery error using the given data object (converting it to the relevant 
	type. 
*/ 
void printMissingQueryError(void *error);

/* 
	Prints a MissingData error using the given data object (converting it to the relevant 
	type. 
*/ 
void printMissingDataError(void *error);

/* 
	Prints a Extra error using the given data object (converting it to the relevant 
	type. 
*/ 
void printExtraError(void *error);

