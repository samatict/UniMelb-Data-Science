function runTest
{
	dataFile=$TESTDIRECTORY$1
	keyFile=$TESTDIRECTORY$2
	echo $keyFile
	

	if [[ $FIRST != "" ]]
		then
		
		if [[ -z "$3" ]]
			then
			echo
			echo "timeout -t 300 $FIRST $dataFile _results.txt < $keyFile > _comparisons.txt"
			timeout -t 30 $FIRST $dataFile _results.txt < $keyFile > _comparisons.txt
		else
			echo
			echo "timeout -t 30 valgrind $FIRST $dataFile _results.txt < $keyFile > _comparisons.txt 2> $VALGOUT"
			timeout -t 30 valgrind $FIRST $dataFile _results.txt < $keyFile > _comparisons.txt 2> $VALGOUT
		fi

		if [[ $? -eq 0 ]]
			then
			
			# Store raw results in _testResults.txt
			cat _results.txt >> _testResults.txt
			printf "\n" >> _testResults.txt
			
			# Test accuracy.
			echo "-------------------------------------------------------"
			echo "-------------------------------------------------------"
			echo
			echo "$OUTGENLOCATION $dataFile _results.txt e _comparisons.txt 1 < $keyFile"
			$OUTGENLOCATION $dataFile _results.txt e _comparisons.txt 1 < $keyFile
			
			
			trimFiles
			
			
			echo >> $REGOUT
			echo "-------------------------------------------------------" >> $REGOUT
			echo "-------------------------------------------------------" >> $REGOUT
			echo 
			echo "cat _results.txt" >> $REGOUT
			cat _results.txt >> $REGOUT

			echo >> $REGOUT
			echo "cat _comparisons.txt" >> $REGOUT
			cat _comparisons.txt >> $REGOUT
			
			rm _results.txt _comparisons.txt
			
			echo >> $REGOUT
			echo "-------------------------------------------------------" >> $REGOUT
			echo "-------------------------------------------------------" >> $REGOUT
			
			# Append Valgrind output.
			echo >> $FULLVALGOUT
			echo "-------------------------------------------------------" >> $FULLVALGOUT
			echo "$FIRST $dataFile - $keyFile - VG" >> $FULLVALGOUT
			echo "-------------------------------------------------------" >> $FULLVALGOUT
			cat $VALGOUT >> $FULLVALGOUT
			
			
			echo >> $FULLVALGOUT
			echo "-------------------------------------------------------" >> $FULLVALGOUT
			echo "-------------------------------------------------------" >> $FULLVALGOUT
		else
			echo "Exit code != 0"
		fi
	fi

	if [[ $SECOND != "" ]]
		then
		
		if [[ -z "$3" ]]
			then
			echo
			echo "timeout -t 300 $SECOND $dataFile _results.txt < $keyFile > _comparisons.txt"
			timeout -t 30 $SECOND $dataFile _results.txt < $keyFile > _comparisons.txt
		else
			echo
			echo "timeout -t 30 valgrind $SECOND $dataFile _results.txt < $keyFile > _comparisons.txt 2> $VALGOUT"
			timeout -t 30 valgrind $SECOND $dataFile _results.txt < $keyFile > _comparisons.txt 2> $VALGOUT
		fi

		if [[ $? -eq 0 ]]
			then
			
			# Store raw results in _testResults.txt
			cat _results.txt >> _testResults.txt
			printf "\n" >> _testResults.txt
			
			# Test accuracy.
			echo "-------------------------------------------------------"
			echo "-------------------------------------------------------"
			echo
			echo "$OUTGENLOCATION $dataFile _results.txt e _comparisons.txt 2 < $keyFile"
			$OUTGENLOCATION $dataFile _results.txt e _comparisons.txt 2 < $keyFile
			
			
			trimFiles
			
			
			echo >> $REGOUT
			echo "-------------------------------------------------------" >> $REGOUT
			echo "-------------------------------------------------------" >> $REGOUT
			echo 
			echo "cat _results.txt" >> $REGOUT
			cat _results.txt >> $REGOUT

			echo >> $REGOUT
			echo "cat _comparisons.txt" >> $REGOUT
			cat _comparisons.txt >> $REGOUT
			
			rm _results.txt _comparisons.txt
			
			echo >> $REGOUT
			echo "-------------------------------------------------------" >> $REGOUT
			echo "-------------------------------------------------------" >> $REGOUT
			
			# Append Valgrind output.
			echo >> $FULLVALGOUT
			echo "-------------------------------------------------------" >> $FULLVALGOUT
			echo "$SECOND $dataFile - $keyFile - VG" >> $FULLVALGOUT
			echo "-------------------------------------------------------" >> $FULLVALGOUT
			cat $VALGOUT >> $FULLVALGOUT
			
			
			echo >> $FULLVALGOUT
			echo "-------------------------------------------------------" >> $FULLVALGOUT
			echo "-------------------------------------------------------" >> $FULLVALGOUT
		else
			echo "Exit code != 0"
		fi
	fi

	echo
	echo "-------------------------------------------------------"
	echo "-------------------------------------------------------"
}

function trimFiles
{
	if [[ `wc -l _results.txt | awk '{print $1}'` -gt 100 ]]
		then
		echo
		echo "Warning: truncating _results.txt to 100 lines!"
		echo "Line count was: $(wc -l _results.txt | awk '{print $1}')"
		sed -i '100,$ d' _results.txt
	fi

	if [[ `wc -L _results.txt | awk '{print $1}'` -gt 128 ]]
		then
		echo
		echo "Warning: truncating _results.txt to a line length of 128!"
		echo "Longest line length was: $(wc -L _results.txt | awk '{print $1}')"
		cut -c 1-128 _results.txt > _results.txt.tmp
		mv _results.txt.tmp _results.txt
	fi

	if [[ `wc -l _comparisons.txt | awk '{print $1}'` -gt 100 ]]
		then
		echo
		echo "Warning: truncating _comparisons.txt to 100 lines!"
		echo "Line count was: $(wc -l _comparisons.txt | awk '{print $1}')"
		sed -i '100,$ d' _comparisons.txt
	fi

	if [[ `wc -L _comparisons.txt | awk '{print $1}'` -gt 128 ]]
		then
		echo
		echo "Warning: truncating _comparisons.txt to a line length of 128!"
		echo "Longest line length was: $(wc -L _comparisons.txt | awk '{print $1}')"
		cut -c 1-128 _comparisons.txt > _comparisons.txt.tmp
		mv _comparisons.txt.tmp _comparisons.txt
	fi
}

function runMassifTest
{
	dataFile=$TESTDIRECTORY$1.data
	keyFile=$TESTDIRECTORY$1.keys
	echo $keyFile
	

	if [[ $FIRST != "" ]]
		then
		echo
		echo "timeout -t 30 valgrind --tool=massif --massif-out-file=_massifout.txt $FIRST $dataFile _results.txt < $keyFile &> _stdout.txt"
		timeout -t 30 valgrind --tool=massif --massif-out-file=_massifout.txt $FIRST $dataFile _results.txt < $keyFile &> _stdout.txt

		if [[ $? -eq 0 ]]
			then
			
			echo "First 50 lines of massif output:"
			echo "ms_print _massifout.txt | head -n 50"
			ms_print _massifout.txt | head -n 50
			
			rm _results.txt _stdout.txt _massifout.txt
		else
			echo "Exit code != 0"
		fi
	fi

	if [[ $SECOND != "" ]]
		then
		
		echo "timeout -t 30 valgrind --tool=massif --massif-out-file=_massifout.txt $SECOND $dataFile _results.txt < $keyFile &> _stdout.txt"
		timeout -t 30 valgrind --tool=massif --massif-out-file=_massifout.txt $SECOND $dataFile _results.txt < $keyFile &> _stdout.txt

		if [[ $? -eq 0 ]]
			then
			
			echo "First 50 lines of massif output:"
			echo "ms_print _massifout.txt | head -n 50"
			ms_print _massifout.txt | head -n 50
			
			rm _results.txt _stdout.txt _massifout.txt
		else
			echo "Exit code != 0"
		fi
	fi

	echo
	echo "-------------------------------------------------------"
	echo "-------------------------------------------------------"
}

function runSuite
{
	echo "        CCCCCCCCCCCCCHHHHHHHHH     HHHHHHHHHEEEEEEEEEEEEEEEEEEEEEE"
	echo "     CCC::::::::::::CH:::::::H     H:::::::HE::::::::::::::::::::E"
	echo "   CC:::::::::::::::CH:::::::H     H:::::::HE::::::::::::::::::::E"
	echo "  C:::::CCCCCCCC::::CHH::::::H     H::::::HHEE::::::EEEEEEEEE::::E"
	echo " C:::::C       CCCCCC  H:::::H     H:::::H    E:::::E       EEEEEE"
	echo "C:::::C                H:::::H     H:::::H    E:::::E             "
	echo "C:::::C                H::::::HHHHH::::::H    E::::::EEEEEEEEEE   "
	echo "C:::::C                H:::::::::::::::::H    E:::::::::::::::E   "
	echo "C:::::C                H:::::::::::::::::H    E:::::::::::::::E   "
	echo "C:::::C                H::::::HHHHH::::::H    E::::::EEEEEEEEEE   "
	echo "C:::::C                H:::::H     H:::::H    E:::::E             "
	echo " C:::::C       CCCCCC  H:::::H     H:::::H    E:::::E       EEEEEE"
	echo "  C:::::CCCCCCCC::::CHH::::::H     H::::::HHEE::::::EEEEEEEE:::::E"
	echo "   CC:::::::::::::::CH:::::::H     H:::::::HE::::::::::::::::::::E"
	echo "     CCC::::::::::::CH:::::::H     H:::::::HE::::::::::::::::::::E"
	echo "        CCCCCCCCCCCCCHHHHHHHHH     HHHHHHHHHEEEEEEEEEEEEEEEEEEEEEE"
	echo "        CCCCCCCCCCCCCKKKKKKKKK    KKKKKKK"
	echo "     CCC::::::::::::CK:::::::K    K:::::K"
	echo "   CC:::::::::::::::CK:::::::K    K:::::K"
	echo "  C:::::CCCCCCCC::::CK:::::::K   K::::::K"
	echo " C:::::C       CCCCCCKK::::::K  K:::::KKK"
	echo "C:::::C                K:::::K K:::::K   "
	echo "C:::::C                K::::::K:::::K    "
	echo "C:::::C                K:::::::::::K     "
	echo "C:::::C                K:::::::::::K     "
	echo "C:::::C                K::::::K:::::K    "
	echo "C:::::C                K:::::K K:::::K   "
	echo " C:::::C       CCCCCCKK::::::K  K:::::KKK"
	echo "  C:::::CCCCCCCC::::CK:::::::K   K::::::K"
	echo "   CC:::::::::::::::CK:::::::K    K:::::K"
	echo "     CCC::::::::::::CK:::::::K    K:::::K"
	echo "        CCCCCCCCCCCCCKKKKKKKKK    KKKKKKK"
	echo "testing 1-vistest.data  1-vistest.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  1-vistest.data  1-vistest.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 2-vistest.data  2-vistest.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  2-vistest.data  2-vistest.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 3-2node.data  3-2node.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  3-2node.data  3-2node.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 4-3node.data  4-3node.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  4-3node.data  4-3node.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 5-3node-reversed.data  5-3node-reversed.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  5-3node-reversed.data  5-3node-reversed.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 6-multichar.data  6-multichar.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  6-multichar.data  6-multichar.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 7-leftlean.data  7-leftlean.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  7-leftlean.data  7-leftlean.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 8-rightlean.data  8-rightlean.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  8-rightlean.data  8-rightlean.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 9-notfound.data  9-notfound.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  9-notfound.data  9-notfound.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 10-rlsearch.data  10-rlsearch.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  10-rlsearch.data  10-rlsearch.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 11-tricky-rlr.data  11-tricky-rlr.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  11-tricky-rlr.data  11-tricky-rlr.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 12-tricky-lrl.data  12-tricky-lrl.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  12-tricky-lrl.data  12-tricky-lrl.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 13-rstick.data  13-rstick.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  13-rstick.data  13-rstick.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 14-balanced.data  14-balanced.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  14-balanced.data  14-balanced.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 15-multi-word.data  15-multi-word.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  15-multi-word.data  15-multi-word.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 16-127-key.data  16-127-key.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  16-127-key.data  16-127-key.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 17-128-key.data  17-128-key.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  17-128-key.data  17-128-key.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 18-memory-50.data  18-memory-50.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  18-memory-50.data  18-memory-50.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 19-memory-100.data  19-memory-100.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  19-memory-100.data  19-memory-100.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 20-llrl-dup.data  20-llrl-dup.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  20-llrl-dup.data  20-llrl-dup.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 21-rrlr-dup.data  21-rrlr-dup.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  21-rrlr-dup.data  21-rrlr-dup.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 22-dup1.data  22-dup1.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  22-dup1.data  22-dup1.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 22-dup2.data  22-dup2.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  22-dup2.data  22-dup2.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 22-dup1000.data  22-dup1000.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  22-dup1000.data  22-dup1000.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 23-511-line.data  23-511-line.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  23-511-line.data  23-511-line.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 24-512-line.data  24-512-line.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  24-512-line.data  24-512-line.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 25-big-data.data  25-big-data.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  25-big-data.data  25-big-data.keys valgrind
	echo
	echo "-------------------------------------------------------------"

	echo "testing 26-big-key.data  26-big-key.keys valgrind"
	echo "-------------------------------------------------------------"
	echo "-------------------------------------------------------------"
	runTest  26-big-key.data  26-big-key.keys valgrind
	echo
	echo "----------------------------------------------------------------------"
	echo "MMMMMMMM               MMMMMMMM               AAA               "
	echo "M:::::::M             M:::::::M              A:::A              "
	echo "M::::::::M           M::::::::M             A:::::A             "
	echo "M:::::::::M         M:::::::::M            A:::::::A            "
	echo "M::::::::::M       M::::::::::M           A:::::::::A           "
	echo "M:::::::::::M     M:::::::::::M          A:::::A:::::A          "
	echo "M:::::::M::::M   M::::M:::::::M         A:::::A A:::::A         "
	echo "M::::::M M::::M M::::M M::::::M        A:::::A   A:::::A        "
	echo "M::::::M  M::::M::::M  M::::::M       A:::::A     A:::::A       "
	echo "M::::::M   M:::::::M   M::::::M      A:::::AAAAAAAAA:::::A      "
	echo "M::::::M    M:::::M    M::::::M     A:::::::::::::::::::::A     "
	echo "M::::::M     MMMMM     M::::::M    A:::::AAAAAAAAAAAAA:::::A    "
	echo "M::::::M               M::::::M   A:::::A             A:::::A   "
	echo "M::::::M               M::::::M  A:::::A               A:::::A  "
	echo "M::::::M               M::::::M A:::::A                 A:::::A "
	echo "MMMMMMMM               MMMMMMMMAAAAAAA                   AAAAAAA"
	echo "   SSSSSSSSSSSSSSS    SSSSSSSSSSSSSSS IIIIIIIIIIFFFFFFFFFFFFFFFFFFFFFF"
	echo " SS:::::::::::::::S SS:::::::::::::::SI::::::::IF::::::::::::::::::::F"
	echo "S:::::SSSSSS::::::SS:::::SSSSSS::::::SI::::::::IF::::::::::::::::::::F"
	echo "S:::::S     SSSSSSSS:::::S     SSSSSSSII::::::IIFF::::::FFFFFFFFF::::F"
	echo "S:::::S            S:::::S              I::::I    F:::::F       FFFFFF"
	echo "S:::::S            S:::::S              I::::I    F:::::F             "
	echo " S::::SSSS          S::::SSSS           I::::I    F::::::FFFFFFFFFF   "
	echo "  SS::::::SSSSS      SS::::::SSSSS      I::::I    F:::::::::::::::F   "
	echo "    SSS::::::::SS      SSS::::::::SS    I::::I    F:::::::::::::::F   "
	echo "       SSSSSS::::S        SSSSSS::::S   I::::I    F::::::FFFFFFFFFF   "
	echo "            S:::::S            S:::::S  I::::I    F:::::F             "
	echo "            S:::::S            S:::::S  I::::I    F:::::F             "
	echo "SSSSSSS     S:::::SSSSSSSS     S:::::SII::::::IIFF:::::::FF           "
	echo "S::::::SSSSSS:::::SS::::::SSSSSS:::::SI::::::::IF::::::::FF           "
	echo "S:::::::::::::::SS S:::::::::::::::SS I::::::::IF::::::::FF           "
	echo " SSSSSSSSSSSSSSS    SSSSSSSSSSSSSSS   IIIIIIIIIIFFFFFFFFFFF           "
	echo "----------------------------------------------------------------------"
	echo "======================================================================"
	echo "Test 18 - size 50 key"
	echo "----------------------------------------------------------------------"
	runMassifTest 18-memory-50
	echo "======================================================================"
	echo "Test 19 - size 100 key (should appear different to Test 18's "
	echo "allocation steps)"
	echo "----------------------------------------------------------------------"
	runMassifTest 19-memory-100
	echo "======================================================================"
	echo "----------------------------------------------------------------------"
	echo "Test 25 - 100 big data items (should see allocation steps)"
	echo "----------------------------------------------------------------------"
	runMassifTest 25-big-data
	echo "----------------------------------------------------------------------"
	echo "Test 26 - 100 big key items (should see allocation steps)"
	echo "----------------------------------------------------------------------"
	runMassifTest 26-big-key
	echo "----------------------------------------------------------------------"
	echo "Test 22 - 3-part test [1 DUP, 2 DUP, 1000 DUP data]"
	echo "[T22] 1 data item"
	echo "----------------------------------------------------------------------"
	runMassifTest 22-dup1
	echo "----------------------------------------------------------------------"
	echo "[T22] 2 data items"
	echo "----------------------------------------------------------------------"
	runMassifTest 22-dup2
	echo "----------------------------------------------------------------------"
	echo "[T22] 1000 data items"
	echo "----------------------------------------------------------------------"
	runMassifTest 22-dup1000
	echo "----------------------------------------------------------------------"
	echo "----------------------------------------------------------------------"
}

function prepareAdjust
{
	if [[ $INADJUSTINGFOLDER -eq 0 ]] ; then
		echo "Searching for adjustment folder."
		if [[ -z `find . -maxdepth 1 -iname ${ADJUSTING_FOLDER_NAME%/}` ]]
			then
			echo "Creating adjustment folder."
			# Create working copy to modify.
			mkdir "$ADJUSTING_FOLDER_NAME"
			if [[ -z `find . -maxdepth 1 -iname ${ADJUSTING_FOLDER_NAME%/}` ]]
				then
				echo "ERROR: Failed to create adjusted folder."
				exit
			fi
			
			FILESTOCOPY=`find . -maxdepth 1 -type f -regextype posix-egrep -iregex '.*\.c$|.*\.h|.*makefile.*' | wc -l`
			
			find . -maxdepth 1 -type f -regextype posix-egrep -iregex '.*\.c$|.*\.h|.*makefile.*' -exec cp {} ./$ADJUSTING_FOLDER_NAME \;
			
			cd "$ADJUSTING_FOLDER_NAME"
			
			if [[ `find . -maxdepth 1 -type f -regextype posix-egrep -iregex '.*\.c$|.*\.h|.*makefile.*' | wc -l` -ne $FILESTOCOPY ]]
				then
				echo "Failed to copy files successfully."
				exit
			else
				echo "Successfully copied files"
			fi
			
			# Return to parent directory, as next command will handle changing 
			# into folder.
			cd ..
		fi
		
		if [[ -z `find . -maxdepth 1 -iname ${ADJUSTING_FOLDER_NAME%/}` ]]
			then
			echo "Critical failure, folder appears to have been successfully "
			echo "created, but cannot be found."
			exit
		else
			cd "$ADJUSTING_FOLDER_NAME"
			INADJUSTINGFOLDER=1
		fi
	fi
}

function buildMakefile
{
	# Prepare adjustment folder if not already prepared.
	prepareAdjust
	
	# Check if a file with a name like makefile is present
	if [[ `find . -maxdepth 1 -type f -regextype posix-egrep -iregex '.*makefile.*' | wc -l` -ne 0 ]]
		then
		FOUNDMAKELIKE=`find . -maxdepth 1 -type f -regextype posix-egrep -iregex '.*makefile.*'`
		echo "Found make-like named files: $FOUNDMAKELIKE"
		
		export -f tryRenameMake
		export -f tryMake
		
		find . -maxdepth 1 -type f -regextype posix-egrep -iregex '.*makefile.*' -exec bash -c 'tryRenameMake $0' {} \;
		
	fi
	
	echo "====================================================================="
	echo "Finished attempted simple repair"
	echo "====================================================================="
	# Check if successfully completed.
	if [[ -z `find . -maxdepth 1 -iname makefile` ]]
		then
		# No usable makefile found.
		# Construct makefile from scratch.
		# Add note about generated status.
		echo "# This file was generated by the testing script as a makefile in " >> makefile
		echo "# a usable format was not detected. " >> makefile
		
		# Add variables
		# Assume c99 flag not required, if it is, we'll resolve this later.
		echo "CFLAGS = -g -Wall" >> makefile
		echo "CC = gcc" >> makefile
		printf "\n" >> makefile
		
		# Add dict1 and dict2 targets to makefile
		addTargets
		
		printf "\n" >> makefile
		
		# Construct expected dependencies from c files present.
		export -f addDeps
		find . -maxdepth 1 -type f -regextype posix-egrep -iregex '.*\.c$' -exec bash -c 'echo addDeps $0 $@' {} +
		find . -maxdepth 1 -type f -regextype posix-egrep -iregex '.*\.c$' -exec bash -c 'addDeps $0 $@' {} +
		echo "====================================================================="
		echo "Finished building makefile"
		echo "====================================================================="
		
	else
		# Return, calling part of code will then proceed to check tryMake 
		# success.
		return
		#echo "Ensuring required variables are set."
		#tryMake
	fi
	
	
}

function addDeps
{
	gcc -M "$@" | \
		sed -e 's/\/usr\/[^ ]*//g' | sed -E -e 's/ {2,}/ /g' | \
		sed -E -e 's/ \\//g' | sed '/^$/d'  | \
		awk 'BEGIN {ORS="";} NR==1 { print;next; } /^[^:]*:/ { print "\n"; print; next; } { print; }' >> makefile
	printf "\n" >> makefile
}

function addTargets
{
	# Check for multiple main functions, in the event of two main functions,
	# assume one is for the first executable and one is for the second 
	# executable.
	# Clean space.
	rm -f tags
	# Grab all functions from all .c files.
	ctags *.c
	FIRSTMAIN=""
	SECONDMAIN=""
	if [[ `cat tags | awk '/^main/ {print $2}' | sort -u | wc -l` -ge 2 ]]
		then
		# Possibly more than two main functions identified, use first two.
		echo "Identified mains in files:"
		echo `cat tags | awk '/^main/ {print $2}' | sort -u | wc -l`
		
		FIRSTMAIN=`cat tags | awk '/^main/ {print $2}' | sort -u | head -n 1`
		SECONDMAIN=`cat tags | awk '/^main/ {print $2}' | sort -u | head -n 2 | tail -n 1`
		
		echo "Using $FIRSTMAIN and $SECONDMAIN as main files."
	else
		if [[ `cat tags | awk '/^main/ {print $2}' | sort -u | wc -l` -eq 1 ]]
			then
			FIRSTMAIN=`cat tags | awk '/^main/ {print $2}' | sort -u | head -n 1`
			
			echo "Using $FIRSTMAIN as main file."
		else
			echo "ERROR: Failed to find main in any files, possible file malformation."
			exit
		fi
	fi
	
	# Pass all .c files with functions in them to program to guess what should
	# go where. Program places shared files in _guessShared, first executable 
	# files in _guess1 and second executable files in _guess2
	cat tags | awk '/^!/ {next;} {print $2}' | sort -u | `$FILECATPROG > /dev/null`
	# Use quick analysis by splitting files which have similar names.
	
	echo "_guessshared found as:"
	cat _guessShared
	printf "\n"
	echo "_guess1 found as:"
	cat _guess1
	printf "\n"
	
	EXE1DEPS=`printf " " | cat _guessShared - _guess1 | awk 'BEGIN {ORS=" ";} {print; next;}' | sed -e 's/\.c/\.o/g'`
	EXE2DEPS=""
	echo "$FALLBACKFIRST: $EXE1DEPS" >> makefile
	echo '	$(CC) $(CFLAGS) -o '"$FALLBACKFIRST"' '"$EXE1DEPS" >> makefile
	if [[ -z `find . -maxdepth 1 -iname _guess2` ]]
		then
		echo "Guess found no files for second executable."
	else
		echo "_guess2 found as:"
		cat _guess2
		echo " "
		
		EXE2DEPS=`printf " " | cat _guessShared - _guess2 |  awk 'BEGIN {ORS=" ";} {print; next;}' | sed -e 's/\.c/\.o/g'`
		
		printf "\n" >> makefile
		
		echo "$FALLBACKSECOND: $EXE2DEPS" >> makefile
		echo '	$(CC) $(CFLAGS) -o '"$FALLBACKSECOND"' '"$EXE2DEPS" >> makefile
	fi
	
	
	
}

function tryRenameMake
{
	if [[ -z `find . -maxdepth 1 -iname makefile` ]]
		then 
		echo "================================================================="
		echo "Treating $1 as a makefile"
		cp $1 makefile
		
		if tryMake
			then
			# Succeeded
			echo "$1 succeeded as makefile."
		else
			echo "Checking/fixing broken references to makefile name"
			# Check if file contains word "Makefile", if so, change to lower 
			# case.
			if [[ `grep 'Makefile' -i makefile | wc -l` -ne 0 ]]
				then
				sed -i -e 's/makefile/makefile/g' makefile
			fi
			
			NODIRMAKEFILE=${1/\.\//}
			
			# Check if file contains the original filename of the makefile, if 
			# so, change to "makefile".
			if [[ `grep "$NODIRMAKEFILE" -i makefile | wc -l` -ne 0 ]]
				then
				echo "Fixing references to old file."
				sed -i -e 's/'$NODIRMAKEFILE'/makefile/gi' makefile
				cat makefile
			fi
			
			# Try again.
			if tryMake
				then
				#Succeeded
				echo "$1 succeeded as makefile."
			else			
				# Failed to make any targets, remove in case other makefiles 
				# exist.
				rm makefile
			fi
		fi
		
		exit
	else
		# A makefile already exists, this means an earlier makefile managed to
		# make something.
		exit
	fi
}

function tryMake
{
	echo "Attempting to make targets"
	
	MAKE_OPTIONS=("dict" "dict1" "dcit" "dcit1" "ditc" "ditc1" "dict2" "ditc2" "bst" "bst1")

	for option in "${MAKE_OPTIONS[@]}"; do
		echo
		echo "Running 'make -B $option'"
		make -B $option
	done

	echo
	echo "Looking for first executable..."
	
	FIRST_OPTIONS=("./dict" "./dict1" "./dcit" "./dcit1" "./ditc" "./ditc1" "./bst" "./bst1")

	for option in "${FIRST_OPTIONS[@]}"; do
		if [[ -f $option ]]
			then
			echo "$option found"
			FIRST=$option
			break
		fi
	done

	if [[ $FIRST == "" ]]
		then
		echo "Nothing found! Not running tests on Stage 1."
	fi

	echo
	echo "Looking for second executable..."
	
	SECOND_OPTIONS=("./dict2" "./ditc2" "./bst2")

	for option in "${SECOND_OPTIONS[@]}"; do
		if [[ -f $option ]]
			then
			echo "$option found"
			SECOND=$option
			break
		fi
	done

	if [[ $SECOND == "" ]]
		then
		if [[ $FIRST == "" ]]
			then
			echo "No executable found! Not running tests."
			
			return 1
		else
			echo "Nothing found! Not running tests on Stage 2."
		fi
	fi
	
	# Succeeded.
	return 0
}

function switchToC99GNU
{
	echo "====================================================================="
	echo "Switching makefile to gnu99."
	echo "====================================================================="
	# Slightly messies makefile, but solves issue consistently and quickly. 
	MAKEFILELOC=`find . -maxdepth 1 -iname makefile`
	sed -i -e 's/gcc/gcc -std=gnu99/gi' "$MAKEFILELOC"
}

function checkDebugging
{
	if [[ $FIRST != "" ]]
		then
		file "$FIRST" > _debugcheck
		if [[ -z `objdump --syms "$FIRST" | grep debug` ]]
			then
			return 1
		fi
	fi
	
	if [[ $SECOND != "" ]]
		then
		file "$SECOND" > _debugcheck
		if [[ -z `objdump --syms "$SECOND" | grep debug` ]]
			then
			return 1
		fi
	fi
	
	return 0
}

function recompileWithDebugSymbols
{
	echo "==============================="
	echo "Recompiling with debug symbols."
	echo "==============================="
	# Slightly messies makefile, but solves issue consistently and quickly. 
	MAKEFILELOC=`find . -maxdepth 1 -iname makefile`
	sed -i -e 's/gcc/gcc -g/gi' "$MAKEFILELOC"
	tryMake
	echo "==============================="
}

function checkPresent
{
	# Create keyfile if one does not already exist
	if [[ -z `find $TESTDIRECTORY -maxdepth 1 -iname _searchkeys` ]]
		then
		echo "Building search key list"
		
		SEARCHKEYFILE=$TESTDIRECTORY/_searchkeys
		echo "Building $SEARCHKEYFILE"
		
		# All we're looking for is one pair of correct results missing no queries, so key search alone will do.
		find $TESTDIRECTORY -maxdepth 1 -type f -regextype posix-egrep -iregex '3-2.*\.keys$' -exec bash -c 'cat $0 $@ >> '$SEARCHKEYFILE';printf "\n" >> '$SEARCHKEYFILE {} \;
		#find $TESTDIRECTORY -maxdepth 1 -type f -regextype posix-egrep -iregex '3-2.*\.data$' -exec bash -c 'printf "\n" | cat $0 $@ - | awk -F "," '"'"'{print $2}'"'"' >> '$SEARCHKEYFILE';printf "\n" >> '$SEARCHKEYFILE {} \;
		
		cat $TESTDIRECTORY/_searchkeys | sort -u > $TESTDIRECTORY/_searchkeys_tmp
		mv $TESTDIRECTORY/_searchkeys_tmp $TESTDIRECTORY/_searchkeys
		
		echo "$SEARCHKEYFILE built"
	fi
	
	#cat $TESTDIRECTORY/_searchkeys
	# Check each key/value appears in results.
	while read line
	do
		if [[ -z `grep "$line" $DIAGNOSTICFILE` ]]
			then
			echo grep "$line" $DIAGNOSTICFILE
			echo "Failed to find $line"
			return 1
		fi
	done < "$TESTDIRECTORY/_searchkeys"
	
	return 0
}

function runTestSelectDiagnostic
{
	echo "Running diagnostic with 3-2node.data 3-2node.keys"
	runTest 3-2node.data 3-2node.keys
}

# The file for full valgrind output
FULLVALGOUT=_valgrind.txt
# The file for temp valgrind output
VALGOUT=_valgrind_temp.txt
# The file for regular program output.
REGOUT=_regOut.txt
# The output for full test output
FILEDEBUGEXTRA=_fullOut.txt
# The output for summary test output
FILESUMMARY=_testing.txt
# The output for single-test stdout
FILETESTSTDOUT=_stdout.txt
# The output for single-test fileoutput
FILETESTOUT=_out.txt
# The output file for the diagnostic
DIAGNOSTICFILE=_lineDiagnostic.txt

# Program to send list of .c files which should be sorted into two sets.
FILECATPROG=~/testing/catProg/catProg
#FILECATPROG=cat

# Program to test output with.
OUTGENLOCATION=~/testing/outGen/outGen

# Directories for test data, initial is used for first test, if all is clear, 
# it is used as the result, otherwise secondary test data is used, which is 
# likely to resolve most problems which aren't fundamental coding errors.
INITIAL_TEST_DIR=~/testing/
# Second tests have an empty line at the end of each file, for those who may
# not have done sufficient testing on the provided data.
SECOND_TEST_DIR=~/testing2/
# A third set of tests end in \r\n to catch those who developed on windows
# without looking at the provided data, or used an unofficial standard which
# they found on the web.
THIRD_TEST_DIR=~/testing3/
# A fourth set of tests end in \r\n and have an empty line at the end of the 
# file, to catch those who made both of the above mistakes when developing their
# program.
FOURTH_TEST_DIR=~/testing4/
# A fifth set of tests which look for a query without \r on a set of data with
# \r included, to catch those who tested with the provided data on Windows in a
# way which was inconsistent with the format of the file they were working on.
FIFTH_TEST_DIR=~/testing5/

TEST_SUITES=($INITIAL_TEST_DIR $SECOND_TEST_DIR $THIRD_TEST_DIR
	$FOURTH_TEST_DIR $FIFTH_TEST_DIR)

# The folder name within which student programs will be modified to correct for
# common errors, or to enable more robust testing functionality during the file
# building. This will be inside the original working directory.
ADJUSTING_FOLDER_NAME="CORRECTION/"
INADJUSTINGFOLDER=0


echo "Setting test directory directory for initial test suite."
TESTDIRECTORY=$INITIAL_TEST_DIR

echo
echo "Cleaning up..."
rm -f *.o dict1 dict2

echo
echo "Looking for makefile..."

# Marks targets which are usable.
FIRST=""
SECOND=""
# Fallback names for created make file.
FALLBACKFIRST="dict1"
FALLBACKSECOND="dict2"


if [[ -z `find . -maxdepth 1 -iname makefile` ]]
    then 
    echo "No makefile found! Attempting to work around."
	buildMakefile
	# Just in case.
	if [[ -z `find . -maxdepth 1 -iname makefile` ]]
		then
		echo "Critical failure: failed to create makefile, this should not have happened."
		exit
	fi
	echo "====================================================================="
	echo "Finished makefile build/repair."
	echo "====================================================================="
fi

echo "Makefile found."

echo
echo "Running 'make'"
make

if tryMake
	then
	echo "Made at least one target successfully."
else
	echo "Failed to make any targets using makefile."
	echo "Attempting C99 switch repair."
	# Try c99gnu mode
	prepareAdjust
	tryMake 2> _trymakeres
	# Check if C99 error appeared
	if [[ -n `grep 'C99 mode' _trymakeres` ]]
		then
		switchToC99GNU
	else
		echo "No C99 error detected in make errors."
	fi
	echo "Reattempting build."
	if tryMake
		then
		echo "Succeeded in building at least one executable"
	else
		echo "Failed to build."
		exit
	fi
fi

echo "Attempting to find best fit test."
for testdir in "${TEST_SUITES[@]}"; do
	echo "---------------------------------------------------------------------"
	echo "---------------------------------------------------------------------"
	echo "------------------------------$testdir----------------------------"
	TESTDIRECTORY=$testdir
	cat $TESTDIRECTORY/description.txt
	echo "---------------------------------------------------------------------"
	
	# Clean raw results file.
	echo "" > _testResults.txt
	# Clean full valgrind output.
	echo "" > $FULLVALGOUT
	
	runTestSelectDiagnostic
	
	if checkPresent
		then
		echo "Test result: keys present"
		echo "Test set to use is $testdir"
		cat $TESTDIRECTORY/description.txt
		break
	else
		echo "Diagnostic result: expected key(s) missing, setting directory to"
		echo "most likely: $SECOND_TEST_DIR [This is to handle complete failure"
		echo "to match]"
		TESTDIRECTORY=$SECOND_TEST_DIR
	fi

	echo "---------------------------------------------------------------------"
done

echo
echo "Running tests..."

echo "---------------------------------------------------------------------"
echo "---------------------------------------------------------------------"
echo "------------------------------$TESTDIRECTORY----------------------------"
echo "---------------------------------------------------------------------"

# Clean raw results file.
echo "" > _testResults.txt
# Clean full valgrind output.
echo "" > $FULLVALGOUT

runSuite

echo
echo "VVVVVVVV           VVVVVVVV   AAA               LLLLLLLLLLL                                      "
echo "V::::::V           V::::::V  A:::A              L:::::::::L                                      "
echo "V::::::V           V::::::V A:::::A             L:::::::::L                                      "
echo "V::::::V           V::::::VA:::::::A            LL:::::::LL                                      "
echo " V:::::V           V:::::VA:::::::::A             L:::::L                                        "
echo "  V:::::V         V:::::VA:::::A:::::A            L:::::L                                        "
echo "   V:::::V       V:::::VA:::::A A:::::A           L:::::L                                        "
echo "    V:::::V     V:::::VA:::::A   A:::::A          L:::::L                                        "
echo "     V:::::V   V:::::VA:::::A     A:::::A         L:::::L                                        "
echo "      V:::::V V:::::VA:::::AAAAAAAAA:::::A        L:::::L                                        "
echo "       V:::::V:::::VA:::::::::::::::::::::A       L:::::L                                        "
echo "        V:::::::::VA:::::AAAAAAAAAAAAA:::::A      L:::::L         LLLLLL                         "
echo "         V:::::::VA:::::A             A:::::A   LL:::::::LLLLLLLLL:::::L                         "
echo "          V:::::VA:::::A               A:::::A  L::::::::::::::::::::::L                         "
echo "           V:::VA:::::A                 A:::::A L::::::::::::::::::::::L                         "
echo "            VVVAAAAAAA                   AAAAAAALLLLLLLLLLLLLLLLLLLLLLLL                         "
echo "        GGGGGGGGGGGGGRRRRRRRRRRRRRRRRR   IIIIIIIIIINNNNNNNN        NNNNNNNNDDDDDDDDDDDDD  	   "
echo "     GGG::::::::::::GR::::::::::::::::R  I::::::::IN:::::::N       N::::::ND::::::::::::DDD      "
echo "   GG:::::::::::::::GR::::::RRRRRR:::::R I::::::::IN::::::::N      N::::::ND:::::::::::::::DD    "
echo "  G:::::GGGGGGGG::::GRR:::::R     R:::::RII::::::IIN:::::::::N     N::::::NDDD:::::DDDDD:::::D   "
echo " G:::::G       GGGGGG  R::::R     R:::::R  I::::I  N::::::::::N    N::::::N  D:::::D    D:::::D  "
echo "G:::::G                R::::R     R:::::R  I::::I  N:::::::::::N   N::::::N  D:::::D     D:::::D "
echo "G:::::G                R::::RRRRRR:::::R   I::::I  N:::::::N::::N  N::::::N  D:::::D     D:::::D "
echo "G:::::G    GGGGGGGGGG  R:::::::::::::RR    I::::I  N::::::N N::::N N::::::N  D:::::D     D:::::D "
echo "G:::::G    G::::::::G  R::::RRRRRR:::::R   I::::I  N::::::N  N::::N:::::::N  D:::::D     D:::::D "
echo "G:::::G    GGGGG::::G  R::::R     R:::::R  I::::I  N::::::N   N:::::::::::N  D:::::D     D:::::D "
echo "G:::::G        G::::G  R::::R     R:::::R  I::::I  N::::::N    N::::::::::N  D:::::D     D:::::D "
echo " G:::::G       G::::G  R::::R     R:::::R  I::::I  N::::::N     N:::::::::N  D:::::D    D:::::D  "
echo "  G:::::GGGGGGGG::::GRR:::::R     R:::::RII::::::IIN::::::N      N::::::::NDDD:::::DDDDD:::::D   "
echo "   GG:::::::::::::::GR::::::R     R:::::RI::::::::IN::::::N       N:::::::ND:::::::::::::::DD    "
echo "     GGG::::::GGG:::GR::::::R     R:::::RI::::::::IN::::::N        N::::::ND::::::::::::DDD      "
echo "        GGGGGG   GGGGRRRRRRRR     RRRRRRRIIIIIIIIIINNNNNNNN         NNNNNNNDDDDDDDDDDDDD         "
echo
echo "-------------------------------------------------------------------------------------------------"
cat $FULLVALGOUT
echo "-------------------------------------------------------------------------------------------------"
